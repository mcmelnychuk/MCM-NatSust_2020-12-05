## Part of MCM-Science submission, figures 1B and S3
## CM: 15/01/2020
##

## load the data

load("list management history by region.RData")

## median U and B
medianU_reg <- read.csv("medianU-by-region_RAM-mdl_mgt.csv")
medianB_reg <- read.csv("medianB-by-region_RAM-mdl_mgt.csv")

### make total stock and national/international -level management intensity
## stock
tmp <- with(impl_list, survey + assess + hcr + quota + iq)
tmp1 <- t(apply(tmp, 1, function(x){x / 5}))
impl_list$totstock <- tmp1
## national-international level
tmp <- with(impl_list, eez + fao + nat)
tmp1 <- t(apply(tmp, 1, function(x){x / 3}))
impl_list$totnatintl <- tmp1

library(reshape)
## check full names
names_df <- data.frame(abbrv = c("underreb", "survey", "assess", "hcr", "quota", "iq",
                                 "eez", "fao", "nat", "totstock", "totnatintl"),
                       full = c("Rebuilding plan", "Scientific survey", "Stock assessment",
                                "Harvest control rule", "Fleet-wide catch limit", "Individual quotas",
                                "EEZ declaration", "UN CA/FSA ratification", "National/international policy", "Stock-level\nmanagement intensity", "National/international-level\nmanagement intensity"),
                       stringsAsFactors = FALSE)
names_df


## change some of the region names as per Mike's other figures
names(nstocks) <- gsub(" coast", " Coast", names(nstocks))
names(nstocks)[names(nstocks) == "Europe-non-EU Atlantic"] <- "Europe(non-EU) NE Atl"
names(nstocks)[names(nstocks) == "Europe-EU Atlantic/Baltic"] <- "Europe(EU) NE Atl"
names(nstocks)[names(nstocks) == "Europe-Mediterranean"] <- "Europe-Med/Black Sea"

for(i in 1:length(impl_list)){
    colnames(impl_list[[i]]) <- gsub(" coast", " Coast", colnames(impl_list[[i]]))
    colnames(impl_list[[i]])[colnames(impl_list[[i]]) == "Europe-non-EU Atlantic"] <- "Europe(non-EU) NE Atl"
    colnames(impl_list[[i]])[colnames(impl_list[[i]]) == "Europe-EU Atlantic/Baltic"] <- "Europe(EU) NE Atl"
    colnames(impl_list[[i]])[colnames(impl_list[[i]]) == "Europe-Mediterranean"] <- "Europe-Med/Black Sea"
}

## function to make a dataframe
get_df <- function(name){
    mat <- t(impl_list[[name]])
    ## check nstocks is ordered the same
    if(!(all(rownames(mat) == names(nstocks)))){
        stop("Names not matching")
    }
    ns <- as.vector(nstocks)
    prop <- mat / ns
    wide <- cbind(region = paste0(rownames(prop), " (", ns, ")"),
                  measure = names_df$full[names_df$abbrv == name],
                  nstocks = ns,
                  as.data.frame(prop))
    long <- melt(wide, id.vars = c("region", "measure", "nstocks"))
    long$year <- as.numeric(as.character(long$variable))
    long$variable <- NULL
    names(long)[names(long) == "value"] <- "proportion"
    return(long)
}

all_df <- NULL
for(name in names_df$abbrv){
    tmp <- get_df(name)
    all_df <- rbind(all_df, tmp)
    rm(tmp)
}

## order the measures for the panels
all_df$measure <- factor(as.character(all_df$measure),
                           levels = c(
                               "Rebuilding plan", "Stock-level\nmanagement intensity", "National/international-level\nmanagement intensity",
                               "Scientific survey", "Stock assessment", "EEZ declaration",
                               "Fleet-wide catch limit", "Harvest control rule", "UN CA/FSA ratification",
                               "Individual quotas", "National/international policy"))

## create a re-scaled variable for colours
national <- c("EEZ declaration", "UN CA/FSA ratification", "National/international policy", "National/international-level\nmanagement intensity")

## re-scale the different categories for using different palettes
## make zeros NA so that they can be a different colour
##all_df$proportion[all_df$proportion == 0] <- NA
all_df$proportion1 <- all_df$proportion
## stock-level
all_df$proportion1[!all_df$measure %in% c("Rebuilding plan", national)] <- all_df$proportion[!all_df$measure %in% c("Rebuilding plan", national)] + 1000
## national-level
all_df$proportion1[all_df$measure %in% national] <- all_df$proportion[all_df$measure %in% national] + 2000
## set up the colour gradients
## see: https://stackoverflow.com/questions/13016022/ggplot2-heatmaps-using-different-gradients-for-categories
gradientends <- c(sapply(c(0, 1000, 2000), function(z){z + c(0, seq(1e-6, 1, length = 5))}))

## if in doubt change white to red here to check
colorends <- c(
    ## rebuilding purples
    c(rep("#ffffff", 1), colorRampPalette(c("#f3d3f9", "#b670c1", "#9a36a9"))(5)),
    ## stock-level blues
    c(rep("#ffffff", 1), colorRampPalette(c("#dfecf6", "#b2d2ec", "#7bb3e1", "#2172b4"))(5)),
    ## nationa/international level oranges
    c(rep("#ffffff", 1), c(colorRampPalette(c("#fbe4ce", "#f6d4b2", "#d2691e"))(5))))

library(ggplot2); theme_set(theme_minimal())
library(scales)


## make all possible orderings
region_order_df <- merge(medianU_reg, medianB_reg)


## include management intensity orderings
imat <- (impl_list[[2]] + impl_list[[3]] + impl_list[[4]] + impl_list[[5]] +
         impl_list[[6]] + impl_list[[7]] + impl_list[[8]] + impl_list[[9]]) / 8
reg.av.mgt <- colMeans(imat) / nstocks
## get in same order as region_order_df$reg2
region_order_df$reg.av.mgt <- as.numeric(reg.av.mgt[as.character(region_order_df$reg2)])

reg.last.mgt <- imat[row.names(imat) == 2016, ] / nstocks
region_order_df$reg.last.mgt <- as.numeric(reg.last.mgt[as.character(region_order_df$reg2)])

## include number of stocks
tmp <- nstocks[as.character(region_order_df$reg2)]
region_order_df$region <- paste0(names(tmp), " (", as.numeric(tmp), ")")

## for the stock-level find the year at which 50% implemented per region
regions <- unique(all_df$region)

year_50_df <- NULL

for(i in levels(all_df$measure)){
    tmp <- subset(all_df, measure == i)
    for(j in levels(tmp$region)){
        tmp1 <- subset(tmp, region == j)
        if(all(tmp1$proportion %in% c(0, 1))){
            year_50 <- tmp1$year[which(tmp1$proportion == 1)[1]]
        }else{
            year_50 <- ifelse(all(tmp1$proportion < 0.5),
                              NA,
                              tmp1$year[which.min(abs(tmp1$proportion - 0.5))[1]]
                              )
        }
        year_50_df <- rbind(year_50_df,
                            data.frame(measure = i, region = j, year = year_50))
        rm(list = c("tmp1", "year_50"))
    }
    rm(tmp)
}

plot_reg_order <- function(name, title = TRUE, subset = NULL){
    ## name is the name of the order vector
    ord <- order(region_order_df[, name], decreasing = TRUE)
    reg_order <- as.character(region_order_df$region[ord])
    if(!is.null(subset)){
        all_df <- subset(all_df, measure %in% subset)
    }
    all_df$region <- factor(as.character(all_df$region), levels = reg_order)
    p <- ggplot(all_df, aes(x = year, y = region)) +
        geom_tile(aes(fill = proportion1)) +
        facet_wrap(~ measure, ncol = 3) +
        scale_fill_gradientn("Number of stocks",
                             colours = colorends,
                             values = rescale(gradientends)) +
                             ##na.value = "white") +
        ##scale_fill_gradientn("Number of stocks", colours = colorends, values = rescale(gradientends)) +
        ##geom_point(data = year_50_df, pch = 21, fill = "white", stroke = 0.2) +
        theme(legend.position = "none",
              panel.grid.major = element_blank(),
              panel.grid.minor = element_blank(),
              text = element_text(size=11),
              axis.ticks.x = element_line(size = 0.1),
              strip.text.x = element_text(margin = margin(0,0,0.05,0, "cm"))) +
        scale_x_continuous(limits = range(all_df$year), expand = c(0, 0)) +
        ylab("") +
        xlab("") +
        geom_hline(yintercept = seq(0.5, 17.5, by = 1), colour = "lightgrey", size = 0.05)
    if(title){
        p <- p +
            ggtitle(paste("Regions ordered by", name, "(high at bottom to low at top)"))
    }
    print(p)
}

order_names <- names(region_order_df)[!names(region_order_df) %in% c("reg2", "region")]

date <- format(Sys.Date(), "%m_%d_%Y")

## pdf(paste0("figures/fig1_alternatives_", date, ".pdf"), height = 12, width = 10)
## for(i in order_names){
##     plot_reg_order(name = i)
## }
## dev.off()

## png
png(paste0("figures/fig_S3_", date, ".png"), height = 9, width = 6.5, res = 400, units = "in")
plot_reg_order(name = "medianU_last5", title = FALSE)
dev.off()

## TOP ROW
## name is the name of the order vector
ord <- order(region_order_df[, "medianU_last5"], decreasing = TRUE)
reg_order <- as.character(region_order_df$region[ord])
all_df$region <- factor(as.character(all_df$region), levels = reg_order)

subset <- c("Rebuilding plan", "Stock-level\nmanagement intensity", "National/international-level\nmanagement intensity")
sub_df <- subset(all_df, measure %in% subset)

## get the legends
## using proportion instead of proportion1 to get the scales [0,1]
## rebuilding plan
p <- ggplot(subset(sub_df, measure == "Rebuilding plan"), aes(x = year, y = region)) +
    geom_tile(aes(fill = proportion)) +
    scale_fill_gradientn("",
                         colours = colorends[1:6],
                         values = rescale(gradientends[1:6]),
                         breaks = seq(0, 1, by = 0.25)) +
                         ##na.value = "white") +
    theme(legend.position = "top",
          text = element_text(size=11),
          legend.key.height=unit(0.2,"cm")) +
    xlab("") + ylab("")
tmp <- ggplot_gtable(ggplot_build(p))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
rb_legend <- tmp$grobs[[leg]]

## stock-level
p <- ggplot(subset(sub_df, measure == "Stock-level\nmanagement intensity"), aes(x = year, y = region)) +
    geom_tile(aes(fill = proportion)) +
    scale_fill_gradientn("",
                         colours = colorends[7:12],
                         values = rescale(gradientends[1:6]),
                         breaks = seq(0, 1, by = 0.25)) +
                         ##na.value = "white") +
    theme(legend.position = "top",
          text = element_text(size=11),
          legend.key.height=unit(0.2,"cm")) +
    xlab("") + ylab("")
tmp <- ggplot_gtable(ggplot_build(p))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
sl_legend <- tmp$grobs[[leg]]

## national/international
p <- ggplot(subset(sub_df, measure == "National/international-level\nmanagement intensity"), aes(x = year, y = region)) +
    geom_tile(aes(fill = proportion)) +
    scale_fill_gradientn("",
                         colours = colorends[13:18],
                         values = rescale(gradientends[1:6]),
                         breaks = seq(0, 1, by = 0.25)) +
                         ##na.value = "white") +
    theme(legend.position = "top",
          text = element_text(size=11),
          legend.key.height=unit(0.2,"cm")) +
    xlab("") + ylab("")
tmp <- ggplot_gtable(ggplot_build(p))
leg <- which(sapply(tmp$grobs, function(x) x$name) == "guide-box")
intl_legend <- tmp$grobs[[leg]]

## real plot
p <- ggplot(sub_df, aes(x = year, y = region)) +
    geom_tile(aes(fill = proportion1)) +
    facet_wrap(~ measure, ncol = 3) +
    scale_fill_gradientn("Number of stocks",
                         colours = colorends,
                         values = rescale(gradientends)) +
                         ##na.value = "white") +
    ##geom_point(data = year_50_df, pch = 21, fill = "white", stroke = 0.2) +
    theme(legend.position = "none",
          panel.grid.major = element_blank(),
          panel.grid.minor = element_blank(),
          text = element_text(size=11),
          axis.ticks.x = element_line(size = 0.1),
          strip.text.x = element_text(margin = margin(0,0,0.05,0, "cm"))) +
    scale_x_continuous(limits = range(all_df$year), expand = c(0, 0)) +
    ylab("") +
    xlab("") +
    geom_hline(yintercept = seq(0.5, 17.5, by = 1), colour = "lightgrey", size = 0.05)

library(grid)
library(gridExtra)
blank <- grid.rect(gp=gpar(col="white"))

png(paste0("figures/fig_1B_", date, ".png"), height = 3, width = 6.5, res = 400, units = "in")
grid.arrange(
    blank, rb_legend, sl_legend, intl_legend, p,
    heights = c(1/9, 4/9, 4/9),
    layout_matrix = rbind(1:4,
                          rep(5, 4),
                          rep(5, 4))
)
dev.off()
