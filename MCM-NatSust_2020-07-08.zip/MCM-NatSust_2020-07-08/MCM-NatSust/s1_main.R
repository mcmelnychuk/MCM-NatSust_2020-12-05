################################################################################
### README: This file is part of a R-project 'MCM-NatSust'.
###         Copy diretory 'MCM-NatSust' to your preferred directory on your
###         local machine, and then run RStudio from that directory.
###         (First, see instructions under 'LOAD PACKAGES' about one package
###         requiring manual installation, which in turn requires Rtools.)
###         All script files (including this) are contained in the root directory.
###         Input data, and output data & figures are contained in sub-directories.
###         Constructed with R version 3.6.3, checked with 4.0.0
###         all code by MCM, uploaded to GitHub July 8, 2020.
################################################################################


###############################
### Main file
###############################
### specifies options, loads packages, loads data, merges datasets, sources other files
### dependencies: none
### calls: "s0_conv-fun.R", "s2_filter.R", "s3_wrangle.R", "s4_plot-explore.R",
###        "s5_plot-arima.R", s6_analyze-arima.R"
###############################


################################################################################
### README: Select user options below, and then source this file.
################################################################################


#. specify RAM Legacy database type to use:
    ramtype <- "mdl"  # version with model fits; base run
    # ramtype <- "asmt"    # assessment-only version; sensitivity run 1

#. specify preferred type of biological reference points to use:
    vtype <- "mgt"  # target-based reference points preferred
    # vtype <- "msy"  # MSY-based reference points preferred

#. select single or multiple datasets for analysis
    # dns <- "matBU"  # mature fishery phase
    # dns <- "fullts"  # full time series (use only for equilibrium analysis)
    dns <- c("matBU", "fullts")  # run both

#. specify weighting scheme
    # wts <- "eq"  # stocks equally-weighted
    # wts <- "lv"  # stocks weighted by maximum sustainable landed value
    wts <- c("eq", "lv")  # run both

#. specify first and last years to include in analysis
    fy <- 1950
    ly <- 2016

#. specify minimum number of years per stock per phase for inclusion
    minyts <- 10  # base run
    # minyts <- 20  # sensitivity run 2

#. specify order of differencing
    dif <- 1  # 1 used throughout

#. specify correlation structure for nlme (p, q)
    corlab <- "ARMA(1,1)"  # base run
    # corlab <- "ARMA(0,0)"  # sensitivity run 3a
    # corlab <- "ARMA(1,0)"  # sensitivity run 3b
    # corlab <- "ARMA(2,0)"  # sensitivity run 3c
    # corlab <- "ARMA(0,1)"  # sensitivity run 3d

#. specify if warnings should be disabled for select code blocks
    dis.sel.warn <- TRUE

#. default options for other warnings
    options(warn = 0, nwarnings = 10000, showErrorCalls = TRUE, showWarnCalls = TRUE)


################################################################################
### README: After selecting user options above, then source this file.
################################################################################



# LOAD PACKAGES ----------------------------------------------------------------

packages <- c("nlme", "forecast", "coda", "MASS", "reshape", "reshape2", "tidyr",
              "stringr", "ggplot2", "GGally", "lattice", "coefplot2")

#. note coefplot2 must be installed separately, and after installing Rtools.
#. try one of:
# install.packages("coefplot2", repos = "http://www.math.mcmaster.ca/bolker/R",
#                  type = "source")
# remotes::install_github("palday/coefplot2", subdir = "pkg")
#. Some package dependencies may also need installing first.

#. check if packages already installed, and if not, install
InstallPackages <- function(pkg) {
  new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if (length(new.pkg))  install.packages(new.pkg, dependencies = TRUE)
  sapply(pkg, library, character.only = TRUE, logical.return = TRUE)
}
InstallPackages(packages)

rm(packages, InstallPackages)



# LOAD DATASETS ----------------------------------------------------------------

vers <- "v2019-07-07"  # version of management input files to use

#. RAM Legacy data
if (ramtype == "asmt")  ramvers <- "[asmt][v4.491]"
if (ramtype == "mdl")  ramvers <- "[mdl][v4.491]"
load(paste0("./in-data/DBdata", ramvers, ".RData"))

#. management attributes data
mdat <- read.csv(
  file = paste0("./in-data/stock-attributes_", vers, ".csv"),
  header = TRUE, stringsAsFactors = FALSE)

#. matrix of years under rebuilding
rmat <- read.csv(
  file = paste0("./in-data/stock-rebuilding-years_", vers, ".csv"),
  header = TRUE, stringsAsFactors = FALSE)

#. years of national-level policy interventions
ndat <- read.csv(
  file = paste0("./in-data/stock-national-policies_", vers, ".csv"),
  header = TRUE, stringsAsFactors = FALSE)

#. predicted ex-vessel prices linked to RAM stocks
pdat <- read.csv(
  file = paste0("./in-data/pred-obs-exv-price-ts-ram-stocks_", vers, ".csv"),
  header = TRUE, stringsAsFactors = FALSE)

#. price taxa and regions used for predictions
ppreds <- read.csv(
  file = paste0("./in-data/price-taxa-and-regions-ram-stocks_", vers, ".csv"),
  header = TRUE, stringsAsFactors = FALSE)

rm(area, assessment, assessmethod, assessor, biometrics, cadv.data, cdivmsy.data,
   cdivmeanc.data, cpair.data, cpue.data, diver.data, diver.mgt.data, divf.data,
   divf.mgt.data, divssb.data, divssb.mgt.data, divtb.data, divtb.mgt.data,
   divtn.data, divtn.mgt.data, divbpref.data, divbpref.mgt.data, divupref.data,
   divupref.mgt.data, effort.data, er.data, erbest.data, f.data, management,
   metadata, r.data, recc.data, ssb.data, stock, survb.data, tac.data, taxonomy,
   tb.data, tbbest.data,  tc.data, tcbest.data, tl.data, tn.data, tsmetrics,
   bioparams, bioparams_assessments_views, bioparams_ids_views,
   bioparams_sources_views, bioparams_units_views, timeseries_assessments_views,
   timeseries_notes_views, timeseries_sources_views, timeseries_units_views,
   timeseries_years_views, vers, ramvers)


#. create subdirectories to save results
suppressWarnings(dir.create("out-data/"))
suppressWarnings(dir.create("out-plots/"))



# SOURCE FILES -----------------------------------------------------------------

source("./s0_conv-fun.R")  # convenience functions
source("./s2_filter.R")  # filter, manipulate, and merge data
source("./s3_wrangle.R")  # prepare time series analyses
source("./s4_plot-explore.R")  # plot exploratory time series figures
source("./s5_plot-arima.R")  # load time series figure functions
source("./s6_analyze-arima.R")  # conduct time series analyses and plot


if (dis.sel.warn == TRUE) {
  print.noquote("warnings (after disabling select warnings):")
} else { print.noquote("warnings:") }
print(summary(warnings()))
