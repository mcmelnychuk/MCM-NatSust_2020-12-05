###############################
### Convenience functions used in other files
###
### This file is sourced from s1_main.R before any other files are sourced.
###############################



# CONVENIENCE FUNCTIONS FOR PLOTTING -------------------------------------------

CurlyBraces <- function(x0, x1, y0, y1, pos = 1, direction = 1, depth = 1,
                        col = grey(0.5), lwd = 1) {
  a = c(1, 2, 3, 48, 50)  # set flexion point for spline
  b = c(0, 0.2, 0.28, 0.7, 0.8)  # set depth for spline flexion point
  curve = spline(a, b, n = 50, method = "natural")$y * depth
  curve = c(curve, rev(curve))
  if (pos == 1) {
      a_sequence = seq(x0, x1, length = 100)
      b_sequence = seq(y0, y1, length = 100)
  }
  if (pos == 2) {
      b_sequence = seq(x0, x1,length = 100)
      a_sequence = seq(y0, y1,length = 100)
  }
  if (direction == 1)  a_sequence = a_sequence + curve
  if (direction == 2)  a_sequence = a_sequence - curve
  if (pos == 1)  lines(a_sequence, b_sequence, lwd = lwd, col = col, xpd = NA) # vertical
  if (pos == 2)  lines(b_sequence, a_sequence, lwd = lwd, col = col, xpd = NA) # horizontal
}



# SET UP LABELS FOR PLOTTING ---------------------------------------------------

SwitchLabs <- function(x) {
  switch(x,
    logUdiv1 = "1-diff log(U/Umsy)",
    logBdiv1 = "1-diff log(B/Bmsy)",
    s.logUdiv1 = "Scaled, 1-diff log(U/Umsy)",
    s.logBdiv1 = "Scaled, 1-diff log(B/Bmsy)",
    uu = "U/Umsy",
    bb = "B/Bmsy",
    s_bb = "B/Bmsy",
    s_cm = "Catch/MSY",

    `(Intercept)` = "Overall intercept",
    txg3 = "Aggregated taxonomic group",
    txg3demfish = "Demersal fish",
    txg3pelfish = "Pelagic fish",
    txg3invert = "Invertebrates",
    reg2 = "Region",
    single_mix = "Single/mixed-species fishery",
    single_mixmixed = "Mixed-species fishery",
    single_mixsingle = "Single-species fishery",
    s.Lmax = "Maximum length",
    s.age50mat = "Age at 50% maturity",
    s.natM = "Natural mortality",
    s.troph = "Trophic level",
    s.mprice = "Mean price",
    s.MSYbest = "MSY",
    s.msymcmt = "MSY",
    s.mslv = "Landed value (MSLV)",
    sprice.obs = "Ex-vessel price",
    natint = "National management intensity",
    mgtint = "Stock management intensity",
    underreb = "Under rebuilding plan",
    underreb1 = "Rebuilding plan (immediate)",
    lag1underreb = "Rebuilding plan (persistent)",
    survey = "Scientific survey",
    assess = "Stock assessment",
    hcr = "Harvest control rule",
    quota = "Fleet-wide catch limit",
    iq = "Individual quotas",
    eez = "EEZ declaration",
    fao = "UN CA/FSA ratification",
    nat = "National/international policy",

    mdf.full = "Full dataset",
    mdf.matBU = "Mature phase",

    mU1_linp_lv_nw_ag = "1-diff log(U/Umsy) vs. scld, cntr; equal wt; agg mgt",
    mU1_linp_lv_w_ag = "1-diff log(U/Umsy) vs. scld, cntr; wt-by-MSLV; agg mgt",
    mU1_linp_lv_nw_sep = "1-diff log(U/Umsy) vs. scld, cntr; equal wt; sep mgt",
    mU1_linp_lv_w_sep = "1-diff log(U/Umsy) vs. scld, cntr; wt-by-MSLV; sep mgt",
    mB1_linp_lv_nw_ag = "1-diff log(B/Bmsy) vs. scld, cntr; equal wt; agg mgt",
    mB1_linp_lv_w_ag = "1-diff log(B/Bmsy) vs. scld, cntr; wt-by-MSLV; agg mgt",
    mB1_linp_lv_nw_sep = "1-diff log(B/Bmsy) vs. scld, cntr; equal wt; sep mgt",
    mB1_linp_lv_w_sep = "1-diff log(B/Bmsy) vs. scld, cntr; wt-by-MSLV; sep mgt",
  )
}
