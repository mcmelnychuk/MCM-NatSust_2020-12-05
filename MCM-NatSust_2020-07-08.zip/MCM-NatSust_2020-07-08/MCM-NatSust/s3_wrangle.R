###############################
### Data wrangling for time series intervention analysis
###############################
### merges data and prepares time series of attributes and response variables
### dependencies: "s1_main.R", "s2_filter.R"
### calls: none
###############################



# PREPARE STATIC VARIABLES -----------------------------------------------------

#. exclude stocks with no RAM data
mdat <- mdat[!is.na(mdat$stockid), ]

#. extract select predictor attributes
pred.att <- mdat[, c("stockid", "reg2", "txg2", "txg3", "single_mix", "age50mat", "Lmax")]
pred.att <- pred.att[order(pred.att$stockid), ]

#. proportions of regional weights for prices
ppreds <- melt(data = ppreds, variable.name = "p_reg", value.name = "prop_p_reg",
               id.vars = c("stockid", "taxgroup", "isscaap", "tC", "tO", "tF",
                           "tG", "tS"), na.rm = TRUE)
ppreds <- ppreds[order(ppreds$prop_p_reg, decreasing = TRUE), ]

#. MSY values and notes
msy <- bioparams_values_views[, c("stockid", "MSYbest")]
msyid <- bioparams_notes_views[, c("stockid", "MSYbest")]
names(msyid) <- c("stockid", "MSYbest_id")
msy <- merge(x = msy, y = msyid, by = "stockid", all = TRUE, sort = FALSE)

rm(bioparams_values_views, bioparams_notes_views)



# PREDICTOR & RESPONSE TIME SERIES DATAFRAME -----------------------------------

## TIME SERIES VALUES AND IDENTIFIERS =======================================

if (vtype == "msy") {
  mdf <- timeseries_values_views[, c("stockid", "stocklong", "year", "UdivUmsypref",
                                     "BdivBmsypref", "CdivMSY", "CdivMEANC")]
  BUids <- timeseries_ids_views[, c("stockid", "stocklong", "UdivUmsypref",
                                    "BdivBmsypref", "CdivMSY", "CdivMEANC")]
}
if (vtype == "mgt") {
  mdf <- timeseries_values_views[, c("stockid", "stocklong", "year", "UdivUmgtpref",
                                     "BdivBmgtpref", "CdivMSY", "CdivMEANC")]
  BUids <- timeseries_ids_views[, c("stockid", "stocklong", "UdivUmgtpref",
                                    "BdivBmgtpref", "CdivMSY", "CdivMEANC")]
}
names(mdf)[names(mdf) == "UdivUmsypref" | names(mdf) == "UdivUmgtpref"] <- "Udiv"
names(mdf)[names(mdf) == "BdivBmsypref" | names(mdf) == "BdivBmgtpref"] <- "Bdiv"


## ASSEMBLE CATCH OR LANDINGS TIME SERIES FROM ALL ASSESSMENTS ==============

cts <- timeseries[timeseries$tsid %in% c(
  "TCbest-MT", "TC-MT", "TC-1-MT", "TC-2-MT", "TC-3-MT",  "TC-A1-MT", "TC-A2-MT",
  "TC-mwc-MT", "TL-MT", "TL-1-MT", "TL-2-MT", "TL-3-MT", "TL-A1-MT", "TL-A2-MT",
  "TL-A3-MT", "TL-A4-MT", "TL-A5-MT"), ]
ctsm <- melt(data = cts[, c("stockid", "tsyear", "assessid", "tsid", "tsvalue")],
             id.vars = c("stockid", "tsyear", "assessid", "tsid"),
             measure.vars = "tsvalue")
cts2 <- suppressWarnings(cast(
  data = ctsm[, c("stockid", "tsyear", "variable", "value")],
  formula = stockid + tsyear ~ variable, fun.aggregate = "max", na.rm = TRUE))
cts2[!is.na(cts2$tsvalue) & (cts2$tsvalue == "Inf" | cts2$tsvalue == "-Inf"),
     "tsvalue"] <- NA
cts2 <- cts2[!is.na(cts2$tsvalue), ]
names(cts2) <- c("stockid", "year", "tcmt")

#. compile piece-wise catch ts by stockid & year, drawing from several sources:
#.   first preference = max value in most recent assessment (in views table)
#.   second preference = max value in older assessments (timeseries table)
c.tab <- timeseries_values_views[, c("stockid", "year", "TCbest", "TC", "TL")]
c.units <- timeseries_ids_views[, c("stockid", "TCbest", "TC", "TL")]
names(c.units) <- c("stockid", "units_TCbest", "units_TC", "units_TL")
c.tab <- merge(x = c.tab, y = c.units, by = "stockid",
               all.x = TRUE, all.y = FALSE, sort = FALSE)
c.tab[!is.na(c.tab$units_TC) & c.tab$units_TC == "TC-E00", "TC"] <- NA
c.tab[!is.na(c.tab$units_TL) & c.tab$units_TL == "TL-E00", "TL"] <- NA
c.tab$tcmt <- NA
for (i in 1:nrow(c.tab)) {
  c.tab[i, "tcmt"] <- suppressWarnings(max(
    c.tab[i, "TCbest"], c.tab[i, "TC"], c.tab[i, "TL"], na.rm = TRUE))
}
c.tab[!is.na(c.tab$tcmt) & (c.tab$tcmt == "Inf" | c.tab$tcmt == "-Inf"), "tcmt"] <- NA
c.tab <- c.tab[!is.na(c.tab$tcmt), ]
c.tab <- c.tab[, c("stockid", "year", "tcmt")]
ctab2 <- merge(x = c.tab[, c("stockid", "year")], y = cts2,
               by = c("stockid", "year"), all = TRUE, sort = FALSE)
for (i in 1:nrow(c.tab)) {
  ctab2[ctab2$stockid == c.tab[i, "stockid"] &
        ctab2$year == c.tab[i, "year"], "tcmt"] <- c.tab[i, "tcmt"]
}
mdf <- merge(x = mdf, y = ctab2, by = c("stockid", "year"),
             all.x = TRUE, all.y = FALSE, sort = FALSE)
mdf <- mdf[order(mdf$stockid, mdf$year), ]


## CALCULATE MEAN CATCH (t) WITH LEADING ZEROS REMOVED ======================

ctab2 <- ctab2[order(ctab2$stockid, ctab2$year), ]
for (i in unique(ctab2$stockid)) {
  syrs <- unique(ctab2[ctab2$stockid == i, "year"])
  miny <- min(syrs, na.rm = TRUE)
  j <- 1
  if (ctab2[ctab2$stockid == i & ctab2$year == miny, "tcmt"] == 0) {
    while (ctab2[ctab2$stockid == i & ctab2$year == miny, "tcmt"] == 0) {
      ctab2[ctab2$stockid == i & ctab2$year == miny, "tcmt"] <- NA
      j <- j + 1
      miny <- syrs[j]
    }
  }
}
ctab2 <- ctab2[!is.na(ctab2$tcmt), ]
meanc <- aggregate(formula = tcmt ~ stockid, data = ctab2, FUN = "mean")
names(meanc) <- c("stockid", "meancmt")
msymc <- merge(x = meanc, y = msy, by = "stockid", all = TRUE, sort = TRUE)
msymc$msymcmt <- msymc$MSYbest
msymc[is.na(msymc$MSYbest), "msymcmt"] <- msymc[is.na(msymc$MSYbest), "meancmt"]
pred.att <- merge(x = pred.att, y = msymc[, c("stockid", "msymcmt")],
                  by = "stockid", all.x = TRUE, all.y = FALSE, sort = FALSE)

mdf <- merge(x = mdf, y = msymc[, c("stockid", "msymcmt")],
             by = "stockid", all.x = TRUE, all.y = FALSE, sort = FALSE)
mdf$tcdivmsymc <- mdf$tcmt / mdf$msymcmt
mdf$msymcmt <- NULL
mdf[!is.na(mdf$CdivMEANC), "tcdivmsymc"] <- mdf[!is.na(mdf$CdivMEANC), "CdivMEANC"]
mdf[!is.na(mdf$CdivMSY), "tcdivmsymc"] <- mdf[!is.na(mdf$CdivMSY), "CdivMSY"]

rm(timeseries, cts, ctsm, cts2, c.tab, ctab2, c.units, meanc, msy, msyid, syrs, miny)


## IDENTIFY STOCKS WITH MISSING U OR B VALUES IN TIME SERIES ================

stk <- data.frame(unique(mdf$stockid), NA, NA, NA, NA)
names(stk) <- c("stockid", "nrows", "yrange", "nUdiv", "nBdiv")

if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
  for (i in stk$stockid) {
    stk[stk$stockid == i, "nrows"] <- length(
      mdf[mdf$stockid == i & (!is.na(mdf$Udiv) | !is.na(mdf$Bdiv)), "year"])
    stk[stk$stockid == i, "yrange"] <- 1 + max(
      mdf[mdf$stockid == i & (!is.na(mdf$Udiv) | !is.na(mdf$Bdiv)), "year"],
      na.rm = TRUE) - min(
        mdf[mdf$stockid == i & (!is.na(mdf$Udiv) | !is.na(mdf$Bdiv)), "year"],
        na.rm = TRUE)
    stk[stk$stockid == i, "nUdiv"] <- length(
      mdf[mdf$stockid == i & !is.na(mdf$Udiv), "year"])
    stk[stk$stockid == i, "nBdiv"] <- length(
      mdf[mdf$stockid == i & !is.na(mdf$Bdiv), "year"])
  }
if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

stk[stk$yrange == "-Inf", "yrange"] <- 0
stk <- stk[stk$stockid %in% pred.att$stockid, ]
print.noquote("stocks without any Udiv values:")
print.noquote(stk[stk$nUdiv == 0, "stockid"])
print.noquote("stocks without any Bdiv values:")
print.noquote(stk[stk$nBdiv == 0, "stockid"])
stk <- stk[stk$yrange != stk$nrows, ]
print.noquote("stocks needing interpolated U or B:")
print(stk$stockid)

#. interpolate years with missing biomass for two Russian pollock stocks
sts1 <- as.ts(mdf[mdf$stockid == "WPOLLWBS", c("year", "Bdiv")])
sts2 <- as.ts(mdf[mdf$stockid == "WPOLLNAVAR", c("year", "Bdiv")])
sts1 <- as.numeric(na.interp(sts1[1:45, 2]))  # 4 missing values
sts2 <- as.numeric(na.interp(sts2[11:30, 2]))  # 3 missing values
mdf[mdf$stockid == "WPOLLWBS" & mdf$year %in% 1970:2014, "Bdiv"] <- sts1
mdf[mdf$stockid == "WPOLLNAVAR" & mdf$year %in% 1994:2013, "Bdiv"] <- sts2

rm(sts1, sts2, stk)

#. interpolate years with missing biomass (and U) for two Med pelagic stocks
if (ramtype == "mdl") {
  sts1 <- as.ts(mdf[mdf$stockid == "ANCHMEDGSA7", c("year", "Udiv")])
  sts2 <- as.ts(mdf[mdf$stockid == "ANCHMEDGSA7", c("year", "Bdiv")])
  sts3 <- as.ts(mdf[mdf$stockid == "SARDMEDGSA7", c("year", "Bdiv")])
  sts1 <- as.numeric(na.interp(sts1[1:19, 2]))  # 1 missing value
  sts2 <- as.numeric(na.interp(sts2[1:20, 2]))  # 1 missing value
  sts3 <- as.numeric(na.interp(sts3[1:20, 2]))  # 1 missing value
  mdf[mdf$stockid == "ANCHMEDGSA7" & mdf$year %in% 1993:2011, "Udiv"] <- sts1
  mdf[mdf$stockid == "ANCHMEDGSA7" & mdf$year %in% 1993:2012, "Bdiv"] <- sts2
  mdf[mdf$stockid == "SARDMEDGSA7" & mdf$year %in% 1993:2012, "Bdiv"] <- sts3

  rm(sts1, sts2, sts3)
}
mdf <- mdf[mdf$stockid %in% pred.att$stockid, ]
mdf <- mdf[mdf$year >= (fy - 1), ]  # allow for 1 year lag
mdf <- mdf[mdf$year <= ly, ]
mdf <- merge(x = mdf, y = pred.att, by = "stockid",
             all.x = TRUE, all.y = FALSE, sort = FALSE)
mdf <- mdf[order(mdf$stockid, mdf$year), ]


## MERGE PRICE DATA =========================================================

mdf <- merge(x = mdf, y = pdat[, c("stockid", "year", "pred_real_price",
                                   "obs_real_price")],
  by = c("stockid", "year"), all.x = TRUE, all.y = FALSE, sort = FALSE)
names(mdf)[names(mdf) == "pred_real_price"] <- "price.pred"
names(mdf)[names(mdf) == "obs_real_price"] <- "price.obs"

#. calculate mean predicted price 2001-2010 for each stock
prices <- mdf[mdf$year >= 2001 & mdf$year <= 2010, c("stockid", "price.pred")]
prices <- aggregate(x = prices$price.pred, by = list(prices$stockid),
                    FUN = "mean", na.rm = TRUE)
names(prices) <- c("stockid", "mprice")
mdf <- merge(x = mdf, y = prices, by = "stockid",
             all.x = TRUE, all.y = FALSE, sort = FALSE)

rm(prices)

#. calculate MSLV for each stock, based on mean predicted price 2001-2010 and MSY
mdf$mslv <- mdf$msymcmt * mdf$mprice


## MERGE TIME SERIES OF 'UNDER REBUILDING' BOOLEAN VARIABLE =================

names(rmat)[1] <- "stockid"
names(rmat)[2:length(rmat)] <- seq(from = fy, by = 1, length.out = length(rmat) - 1)
for (i in 2:length(rmat)) {
  if (as.numeric(names(rmat)[i]) < fy)  rmat[, i] <- NULL
  if (as.numeric(names(rmat)[i]) > ly)  rmat[, i] <- NULL
}
rmatprev <- rmat
for (i in 1:nrow(rmatprev)) {
  for (j in 2:ncol(rmatprev)) {
    rmatprev[i, j] <- max(rmatprev[i, 2:j])
  }
}
rmatl <- melt(data = rmat, id.vars = "stockid", variable.name = "year",
              value.name = "underreb")
rmatprevl <- melt(data = rmatprev, id.vars = "stockid", variable.name = "year",
              value.name = "prevreb")
mdf <- merge(x = mdf, y = rmatl, by = c("stockid", "year"), all.x = TRUE,
             all.y = FALSE, sort = FALSE)
mdf <- merge(x = mdf, y = rmatprevl, by = c("stockid", "year"), all.x = TRUE,
             all.y = FALSE, sort = FALSE)
mdf[mdf$year < fy & is.na(mdf$underreb), "underreb"] <- 0
mdf[mdf$year < fy & is.na(mdf$prevreb), "prevreb"] <- 0


## MERGE TIME SERIES OF MANAGEMENT INTENSITY VARIABLES ======================

#. stock-level management intensity
yof.vars <- c("yof_survey", "yof_assess", "yof_hcr", "yof_quota", "yof_iq")
inuse.vars <- c("survey", "assess", "hcr", "quota", "iq")
yof.tab <- mdat[, yof.vars]
rownames(yof.tab) <- mdat[, "stockid"]
yof.tab$yof_mgtint <- NA
for (i in 1:nrow(yof.tab)) {
  yof.tab[i, "yof_mgtint"] <- min(yof.tab[i, 1:5], na.rm = TRUE)
}
mdf <- merge(x = mdf, y = yof.tab, by.x = "stockid", by.y = "row.names",
             all.x = TRUE, all.y = FALSE, sort = FALSE)
names(mdf)[(length(mdf) - length(yof.vars)):(length(mdf) - 1)] <- inuse.vars
mdf <- mdf[order(mdf$stockid, mdf$year), ]
for (i in (length(mdf) - length(yof.vars)):(length(mdf) - 1)) {
  mdf[(!is.na(mdf[, i]) & (mdf[, "year"] >= mdf[, i]) & mdf[, i] != 0), i] <- 1
  mdf[(!is.na(mdf[, i]) & (mdf[, "year"] < mdf[, i])), i] <- 0
  mdf[is.na(mdf[, i]), i] <- 0
}
mdf$mgtint <- (mdf$survey + mdf$assess + mdf$hcr + mdf$quota + mdf$iq) / 5

#. national- and international-level policy interventions
nat.vars <- c("year_eez", "year_fao", "year_nat")
inuse.vars <- c("eez", "fao", "nat")
ndat <- ndat[!is.na(ndat$stockid), ]
nat.tab <- ndat[, nat.vars]
rownames(nat.tab) <- ndat[, "stockid"]
nat.tab$yof_natint <- NA
for (i in 1:nrow(nat.tab)) {
  nat.tab[i, "yof_natint"] <- suppressWarnings(min(nat.tab[i, 1:3], na.rm = TRUE))
}
nat.tab[is.na(nat.tab[1]) & is.na(nat.tab[2]) & is.na(nat.tab[3]), 4] <- NA
mdf <- merge(x = mdf, y = nat.tab, by.x = "stockid", by.y = "row.names",
             all.x = TRUE, all.y = FALSE, sort = FALSE)
names(mdf)[(length(mdf) - length(nat.vars)):(length(mdf) - 1)] <- inuse.vars
mdf <- mdf[order(mdf$stockid, mdf$year), ]
for (i in (length(mdf) - length(nat.vars)):(length(mdf) - 1)) {
  mdf[(!is.na(mdf[, i]) & (mdf[, "year"] >= mdf[, i])), i] <- 1
  mdf[(!is.na(mdf[, i]) & (mdf[, "year"] < mdf[, i])), i] <- 0
  mdf[is.na(mdf[, i]), i] <- 0
}
mdf$natint <- (mdf$eez + mdf$fao + mdf$nat) / 3
mdf$stockid <- as.factor(mdf$stockid)



# CREATE MATRICES OF IMPLEMENTATION COUNTS OVER TIME, BY REGION ----------------

ivars <- c("prevreb", "survey", "assess", "hcr", "quota", "iq", "eez", "fao", "nat")
yofvars <- c("yof_reb", "yof_survey", "yof_assess", "yof_hcr", "yof_quota",
             "yof_iq", "year_eez", "year_fao", "year_nat")
impl_list <- list()
impl.tab <- mdat[, c("stockid", "reg2")]
nstocks <- table(impl.tab$reg2)
impl.tab <- merge(x = impl.tab, y = nat.tab[, 1:3], by.x = "stockid",
                  by.y = "row.names", all.x = TRUE, all.y = FALSE, sort = FALSE)
impl.tab <- merge(x = impl.tab, y = yof.tab[, 1:5], by.x = "stockid",
                  by.y = "row.names", all.x = TRUE, all.y = FALSE, sort = FALSE)
rmatprev$yof_reb <- NA
rmatp <- rmatprev[, 2:(ncol(rmatprev) - 1)]
for (i in 1:nrow(rmatp)) {
  if (length(colnames(rmatp)[cumsum(as.numeric(rmatp[i, ])) == 1]) == 1) {
    rmatprev[i, "yof_reb"] <- as.numeric(
      colnames(rmatp)[cumsum(as.numeric(rmatp[i, ])) == 1])
  } else {
    NA
  }
}
impl.tab <- merge(x = impl.tab, y = rmatprev[, c("stockid", "yof_reb")],
                  by = "stockid", all.x = TRUE, all.y = FALSE, sort = FALSE)
impl.tab <- impl.tab[, c("stockid", "reg2", yofvars)]
for (i in 1:length(ivars)) {
  imat <- matrix(0, nrow = ly - fy + 1, ncol = length(levels(impl.tab$reg2)))
  imat <- as.data.frame(imat, row.names = fy:ly)
  colnames(imat) <- levels(impl.tab$reg2)
  for (j in 1:ncol(imat)) {
    for (k in 1:nrow(imat)) {
      imat[k, j] <- sum(nrow(
        impl.tab[(impl.tab$reg2 == colnames(imat)[j] &
                  !is.na(impl.tab[, i + 2]) &
                  impl.tab[, i + 2] <= as.numeric(row.names(imat)[k])), ]),
        na.rm = TRUE)
    }
  }
  impl_list[[i]] <- imat
}
names(impl_list) <- ivars

#. add on current rebuilding
rmatl <- merge(x = rmatl, y = impl.tab[, c("stockid", "reg2")], by = "stockid",
               all.x = TRUE, all.y = FALSE, sort = FALSE)
imat <- matrix(0, nrow = ly - fy + 1, ncol = length(levels(impl.tab$reg2)))
imat <- as.data.frame(imat, row.names = fy:ly)
colnames(imat) <- levels(impl.tab$reg2)
for (j in 1:ncol(imat)) {
  for (k in 1:nrow(imat)) {
    imat[k, j] <- sum(rmatl[rmatl$reg2 == colnames(imat)[j] &
                              rmatl$year == rownames(imat)[k], "underreb"], na.rm = TRUE)
  }
}
impl_list[[length(impl_list) + 1]] <- imat
names(impl_list)[[length(impl_list)]] <- "underreb"



# CREATE LAGGED PREDICTOR FOR REBUILDING PLANS ---------------------------------

ApplyLags <- function(d2 = mdf) {
  d2 <- mdf
  rawv <- c("underreb")
  lag1v <- c("lag1underreb")
  xtrav <- c(lag1v)
  xtra <- as.data.frame(matrix(data = 0, nrow = nrow(d2), ncol = length(xtrav)))
  names(xtra) <- xtrav
  d2 <- data.frame(d2, xtra, stringsAsFactors = FALSE)
  for (i in unique(d2$stockid)) {
    minyr <- min(d2[d2$stockid == i, "year"], na.rm = TRUE)
    maxyr <- max(d2[d2$stockid == i, "year"], na.rm = TRUE)
    if (nrow(d2[d2$stockid == i, ]) > 1) {
      for (j in 1:length(lag1v)) {
        d2[d2$stockid == i & d2$year %in% seq((minyr + 1), maxyr, by = 1), lag1v[j]] <-
        d2[d2$stockid == i & d2$year %in% seq(minyr, (maxyr - 1), by = 1), rawv[j]]
      }
    }
  }
  d2 <- d2[d2$year >= fy, ]
  assign("mdf", d2, envir = .GlobalEnv)
}
mdf <- mdf[order(mdf$stockid, mdf$year), ]
ApplyLags(d2 = mdf)

rm(ApplyLags)



# EXCLUDE STOCKS THAT HAVE NO Udiv AND NO Bdiv DATA AVAILABLE ------------------

for (i in unique(mdf$stockid)) {
  if (nrow(mdf[mdf$stockid == i & (!is.na(mdf$Bdiv) | !is.na(mdf$Udiv)), ]) == 0) {
     mdf <- mdf[mdf$stockid != i, ]
  }
}
mdf$stockid <- factor(mdf$stockid)



# CREATE MATRICES OF U OR B VALUES CENTERED ON INDIVIDUAL INTERVENTIONS --------

svars <- c("underreb", "survey", "assess", "hcr", "quota", "iq", "eez", "fao", "nat")
spU_list <- list()
spB_list <- list()
smat_blank <- matrix(data = NA, nrow = length(unique(mdf$stockid)), ncol = 20,
                     dimnames = list(unique(mdf$stockid), -9:10))
for (i in 1:length(svars)) {
  smatU <- smatB <- smat_blank
  for (j in 1:nrow(smat_blank)) {
    ylastreb <- yfirstpre <- y0 <- Uafter <- Bafter <- Ubefore <- Bbefore <- NULL
    nreb <- nprereb <- nUafter <- nBafter <- nUbefore <- nBbefore <- NULL
    if (i == 1) {
      nreb <- 0
      ylastreb <- suppressWarnings(
        max(mdf[mdf$stockid == row.names(smat_blank)[j] &
                mdf[, svars[i]] == 1, "year"], na.rm = TRUE))
      if (ylastreb < 0)  next
      while (mdf[mdf$stockid == row.names(smat_blank)[j] &
                 mdf$year == (ylastreb - nreb), svars[i]] == 1) {
        nreb <- nreb + 1
        if (length(mdf[mdf$stockid == row.names(smat_blank)[j] &
                     mdf$year == (ylastreb - nreb), svars[i]]) == 0)  break
      }
      y0 <- ylastreb - nreb + 1
      nprereb <- 0
      if (length(mdf[mdf$stockid == row.names(smat_blank)[j] &
                     mdf$year == (y0 - 1 - nprereb), svars[i]]) == 1) {
        while (mdf[mdf$stockid == row.names(smat_blank)[j] &
                   mdf$year == (y0 - 1 - nprereb), svars[i]] == 0) {
          nprereb <- nprereb + 1
          if (length(mdf[mdf$stockid == row.names(smat_blank)[j] &
                       mdf$year == (y0 - 1 - nprereb), svars[i]]) == 0)  break
        }
      }
      yfirstpre <- y0 - nprereb
      Uafter <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                      mdf$year %in% y0:ylastreb, "Udiv"]
      Bafter <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                      mdf$year %in% y0:ylastreb, "Bdiv"]
      Ubefore <- mdf[mdf$stockid == row.names(smat_blank)[j] & mdf$year < y0 &
                       mdf$year >= yfirstpre & mdf[, svars[i]] == 0, "Udiv"]
      Bbefore <- mdf[mdf$stockid == row.names(smat_blank)[j] & mdf$year < y0 &
                       mdf$year >= yfirstpre & mdf[, svars[i]] == 0, "Bdiv"]
    }
    if (i > 1) {
      y0 <- suppressWarnings(min(mdf[mdf$stockid == row.names(smat_blank)[j] &
                                       mdf[, svars[i]] == 1, "year"], na.rm = TRUE))
      Uafter <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                      mdf[, svars[i]] == 1, "Udiv"]
      Bafter <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                      mdf[, svars[i]] == 1, "Bdiv"]
      Ubefore <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                       mdf[, svars[i]] == 0, "Udiv"]
      Bbefore <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                       mdf[, svars[i]] == 0, "Bdiv"]
    }
    nUafter <- min(sum(!is.na(Uafter)), 11, na.rm = TRUE)
    nBafter <- min(sum(!is.na(Bafter)), 11, na.rm = TRUE)
    nUbefore <- min(sum(!is.na(Ubefore)), 9, na.rm = TRUE)
    nBbefore <- min(sum(!is.na(Bbefore)), 9, na.rm = TRUE)
    if (nUbefore >= 5 & nUafter >= 6) {
      smatU[j, 10:(9 + nUafter)] <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                                        mdf$year %in% y0:(y0 + nUafter - 1), "Udiv"]
      smatU[j, (9 - nUbefore + 1):9] <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                                        mdf$year %in% (y0 - nUbefore):(y0 - 1), "Udiv"]
    }
    if (nBbefore >= 5 & nBafter >= 6) {
      smatB[j, 10:(9 + nBafter)] <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                                        mdf$year %in% y0:(y0 + nBafter - 1), "Bdiv"]
      smatB[j, (9 - nBbefore + 1):9] <- mdf[mdf$stockid == row.names(smat_blank)[j] &
                                        mdf$year %in% (y0 - nBbefore):(y0 - 1), "Bdiv"]
    }
  }
  spU_list[[i]] <- smatU
  spB_list[[i]] <- smatB
}
names(spU_list) <- svars
names(spB_list) <- svars



# EXPORT SUMMARIES -------------------------------------------------------------

#. for ordering regions by U/Uref
medianU_stock <- aggregate(x = mdf$Udiv, by = list(mdf$stockid, mdf$reg2),
                           FUN = "median", na.rm = TRUE)
names(medianU_stock) <- c("stockid", "reg2", "medianU_all.2steps")
medianU_stock$medianU_last1 <- NA
medianU_stock$medianU_last5 <- NA
medianU_stock$medianU_last10 <- NA
for (i in 1:nrow(medianU_stock)) {
  if (is.na(medianU_stock[i, "medianU_last1"])) {
    for (y in ly:fy) {
      Uval <- mdf[mdf$stockid == medianU_stock[i, "stockid"] & mdf$year == y, "Udiv"]
      if (length(Uval) == 0) {
        next
      } else {
        if (!is.na(Uval)) {
          medianU_stock[i, "medianU_last1"] <- Uval
          medianU_stock[i, "medianU_last5"] <- median(
            mdf[mdf$stockid == medianU_stock[i, "stockid"] &
                  mdf$year %in% seq(y - 4, y, 1), "Udiv"],
            na.rm = TRUE)
          medianU_stock[i, "medianU_last10"] <- median(
            mdf[mdf$stockid == medianU_stock[i, "stockid"] &
                  mdf$year %in% seq(y - 9, y, 1), "Udiv"],
            na.rm = TRUE)
          break
        }
      }
    }
  }
}
medianU_reg <- aggregate(x = medianU_stock[, 3:length(medianU_stock)],
                       by = list(medianU_stock$reg2), FUN = "median", na.rm = TRUE)
medianU_reg[2:length(medianU_reg)] <- medianU_reg[2:length(medianU_reg)]
names(medianU_reg)[1] <- "reg2"
write.csv(x = medianU_reg, row.names = FALSE, file = paste0(
  "./out-data/medianU-by-region_RAM-", ramtype, "_", vtype, ".csv"))


## FILTER AND RE-ARRANGE DATAFRAME ==========================================

mdf <- mdf[, c("stockid", "stocklong", "reg2", "txg2", "txg3", "single_mix",
               "age50mat", "Lmax", "msymcmt", "mprice", "mslv", "year", "tcmt",
               "tcdivmsymc", "CdivMSY", "CdivMEANC", "price.pred", "price.obs",
               "underreb", "lag1underreb", "prevreb", "mgtint", "natint", "survey",
               "assess", "hcr", "quota", "iq", "eez", "fao", "nat", "Udiv", "Bdiv")]

rm(pred.att, pdat, nat.tab, nat.vars, inuse.vars, yof.vars, yofvars, ivars, imat,
   impl.tab, rmat, rmatl, rmatprev, rmatprevl, rmatp, timeseries_values_views,
   timeseries_ids_views, medianU_reg, medianU_stock, y, Uval, smatU, smatB,
   smat_blank, svars, y0, ylastreb, yfirstpre, Uafter, Bafter, Ubefore, Bbefore,
   nreb, nprereb, nUafter, nBafter, nUbefore, nBbefore)



# CREATE SUBSETTED DATASETS WITH RESPECT TO B AND U THRESHOLDS -----------------

Bthr.hi <- 1
Bthr.med <- 0.8
Bthr.lo <- 0.5
Uthr.hi <- 1.5
Uthr.med <- 1
Uthr.lo <- 1
Urecovthr <- 1
Cthr.hi <- 1.25
Cthr.med <- 1
Cthr.prev <- 1.25
mdf <- mdf[order(mdf$stockid, mdf$year), ]


## 1) FULL TIME SERIES ======================================================

mdf.full <- mdf


## 2) DEVELOPING FISHERY PHASE ==============================================

#.    from start to when any of the following first reached:
#.      i) B first < Bthr.med (0.8)
#.      ii) U first > Uthr.med (1)
#.      iii) (catch / MSY) first > Cthr.med (1)
#.      iv) (catch / meanC) first > Cthr.hi (1.25)
#.      v) rebuilding plan in place (including in any previous year)
#.    or, considering only first year of ts, in case of truncation:
#.      vi) if first year U > Uthr.lo, assume truncated ts, not developing (1)
#.      vii) if first year (catch / MSY) < Uthr.lo, assume truncated ts, not developing (1)
#       viii) if first year B < Bthr.hi, assume truncated ts, not developing (1)
#.      ix) if catch in the first year when both B and U available is <
#.           (Cthr.prev * mean catch in previous 10 years), assume truncated ts,
#.            not developing. (1.25)

mdf.devBU <- mdf[!is.na(mdf$Bdiv) | !is.na(mdf$Udiv) | !is.na(mdf$tcdivmsymc), ]
rownames(mdf.devBU) <- seq(from = 1, to = length(mdf.devBU$stockid), by = 1)
mdf.devBU$keep.dev <- 0
mdf.devBU$keep.res <- 0
mdf.devBU$dep <- 0
for (i in unique(mdf.devBU$stockid)) {
  jmin <- min(as.numeric(row.names(mdf.devBU[mdf.devBU$stockid == i, ])))
  j <- jmin
  while (is.na(mdf.devBU[j, "Bdiv"]) & is.na(mdf.devBU[j, "Udiv"]) &
         is.na(mdf.devBU[j, "tcdivmsymc"])) {
    j <- j + 1
  }
  if (!is.na(mdf.devBU[j, "Udiv"]) & mdf.devBU[j, "Udiv"] > Uthr.lo)  next
  if (!is.na(mdf.devBU[j, "Bdiv"]) & mdf.devBU[j, "Bdiv"] < Bthr.hi)  next
  if (!is.na(mdf.devBU[j, "CdivMSY"]) & mdf.devBU[j, "CdivMSY"] > Uthr.lo)  next
  while (!is.na(mdf.devBU[j, "Bdiv"]) | !is.na(mdf.devBU[j, "Udiv"]) |
         !is.na(mdf.devBU[j, "tcdivmsymc"])) {
    if (!is.na(mdf.devBU[j, "Bdiv"]) & mdf.devBU[j, "Bdiv"] < Bthr.med)  break
    if (!is.na(mdf.devBU[j, "Udiv"]) & mdf.devBU[j, "Udiv"] > Uthr.med)  break
    if (!is.na(mdf.devBU[j, "CdivMSY"]) & mdf.devBU[j, "CdivMSY"] > Cthr.med)  break
    if (!is.na(mdf.devBU[j, "CdivMEANC"]) & mdf.devBU[j, "CdivMEANC"] > Cthr.hi)  break
    if (!is.na(mdf.devBU[j, "Bdiv"]) & mdf.devBU[j, "Bdiv"] < Bthr.hi &
         !is.na(mdf.devBU[j, "Udiv"]) & mdf.devBU[j, "Udiv"] > Uthr.lo)  break
    if (is.na(mdf.devBU[j, "Udiv"])) {
      z <- j
      while (is.na(mdf.devBU[z, "Udiv"]) & (mdf.devBU[z, "stockid"] == i)) {
        if (!is.na(mdf.devBU[z, "Udiv"]) & mdf.devBU[z, "Udiv"] > Uthr.med)  break
        if (!is.na(mdf.devBU[z, "CdivMSY"]) & mdf.devBU[z, "CdivMSY"] > Cthr.med)  break
        if (!is.na(mdf.devBU[z, "CdivMEANC"]) & mdf.devBU[z, "CdivMEANC"] > Cthr.hi)  break
        if (!is.na(mdf.devBU[z, "Bdiv"]) & mdf.devBU[z, "Bdiv"] < Bthr.hi &
            !is.na(mdf.devBU[z, "Udiv"]) & mdf.devBU[z, "Udiv"] > Uthr.lo)  break
        z <- z + 1
      }
    }
    if (!is.na(mdf.devBU[j, "underreb"]) & mdf.devBU[j, "underreb"] == 1)  break
    if (!is.na(mdf.devBU[j, "prevreb"]) & mdf.devBU[j, "prevreb"] == 1)  break
    if (!is.na(mdf.devBU[j, "Udiv"]) &
        !is.na(mdf.devBU[j, "Bdiv"]) &
        !is.na(mdf.devBU[j, "tcdivmsymc"]) &
        (is.na(mdf.devBU[max(j - 1, jmin), "Udiv"]) |
         is.na(mdf.devBU[max(j - 1, jmin), "Bdiv"])) &
        sum(!is.na(mdf.devBU[max(j - 10, jmin):max(j - 1, jmin),
                             "tcdivmsymc"])) >= 5) {
          if (sum(!is.na(mdf.devBU[max(j - 10, jmin):max(j - 1, jmin),
                                   "tcdivmsymc"])) > 0) {
            if (mdf.devBU[j, "tcdivmsymc"] < Cthr.prev *
                mean(mdf.devBU[max(j - 10, jmin):max(j - 1, jmin), "tcdivmsymc"],
                     na.rm = TRUE))  break
          }
    }
    mdf.devBU[j, "keep.dev"] <- 1
    j <- j + 1
    if (mdf.devBU[j, "stockid"] != i)  break
    if (j > length(mdf.devBU$stockid))  break
  }
}

for (i in unique(mdf.devBU$stockid)) {
  if (sum(!is.na(mdf.devBU[mdf.devBU$stockid == i, "Udiv"])) == 0)  next
  if (sum(!is.na(mdf.devBU[mdf.devBU$stockid == i, "Bdiv"])) == 0)  next
  j <- min(as.numeric(row.names(mdf.devBU[mdf.devBU$stockid == i, ])))
  for (k in j:(j - 1 + nrow(mdf.devBU[mdf.devBU$stockid == i, ]))) {
    if (!is.na(mdf.devBU[k, "Bdiv"]) & mdf.devBU[k, "Bdiv"] < Bthr.lo) {
      mdf.devBU[k, "dep"] <- 1
    }
    if (!is.na(mdf.devBU[k, "Bdiv"]) & mdf.devBU[k, "Bdiv"] < Bthr.med &
        !is.na(mdf.devBU[k, "Udiv"]) & mdf.devBU[k, "Udiv"] > Uthr.med) {
      mdf.devBU[k, "dep"] <- 1
    }
    if (!is.na(mdf.devBU[k, "Bdiv"]) & mdf.devBU[k, "Bdiv"] < Bthr.hi &
        !is.na(mdf.devBU[k, "Udiv"]) & mdf.devBU[k, "Udiv"] > Uthr.hi) {
      mdf.devBU[k, "dep"] <- 1
    }
    k <- k + 1
  }
  k <- max(as.numeric(row.names(
    mdf.devBU[mdf.devBU$stockid == i &
                (!is.na(mdf.devBU$Bdiv) | !is.na(mdf.devBU$Udiv)), ])))
  while (!is.na(mdf.devBU[k, "Bdiv"]) | !is.na(mdf.devBU[k, "Udiv"])) {
    if (!is.na(mdf.devBU[k, "Udiv"]) & mdf.devBU[k, "Udiv"] > Urecovthr)  break
    if (is.na(mdf.devBU[k, "Udiv"])) {
      z <- k
      while (is.na(mdf.devBU[z, "Udiv"]))  z <- z - 1
      if (!is.na(mdf.devBU[z, "Udiv"]) & mdf.devBU[z, "Udiv"] > Urecovthr)  break
    }
    if (sum(mdf.devBU[j:k, "dep"], na.rm = TRUE) > 0) {
      if (!is.na(mdf.devBU[k, "Udiv"]) |
          (is.na(mdf.devBU[k, "Udiv"]) & mdf.devBU[z, "Udiv"] <= Urecovthr)) {
        mdf.devBU[k, "keep.res"] <- 1
      }
    }
    k <- k - 1
    if (mdf.devBU[k, "stockid"] != i)  break
    if (k < 1)  break
  }
}

## 3) MATURE FISHERY PHASE (ALL YEARS FOLLOWING DEVELOPING PHASE) ===========

mdf.devBU <- mdf.devBU[!is.na(mdf.devBU$Bdiv) | !is.na(mdf.devBU$Udiv), ]
mdf.matBU <- mdf.devBU[mdf.devBU$keep.dev == 0, ]
mdf.devBU <- mdf.devBU[mdf.devBU$keep.dev == 1, ]
mdf.devBU$keep.dev <- NULL
mdf.matBU$keep.dev <- NULL
mdf.devBU$keep.res <- NULL
mdf.matBU$keep.res <- NULL
mdf.devBU$dep <- NULL
mdf.matBU$dep <- NULL


## PRINT SUMMARIES ==========================================================

mdf_list <- list(mdf.full, mdf.matBU, mdf.devBU)
labs <- c("mdf.full", "mdf.matBU", "mdf.devBU")
fnames <- c("mdf_fullts", "mdf_matBU", "mdf_devBU")
names(mdf_list) <- labs
for (i in 1:length(mdf_list)) {
    write.csv(x = mdf_list[[i]], row.names = FALSE, file = paste0(
      "./out-data/", fnames[i], "_RAM-", ramtype, "_", vtype, ".csv"))
}
for (i in 1:length(mdf_list)) {
  print.noquote(paste0(i, ") ", labs[i], ":   n stocks = ",
                       length(unique(mdf_list[[i]]$stockid)),
                       ",   mean n years = ",
                       round(nrow(mdf_list[[i]]) /
                               length(unique(mdf_list[[i]]$stockid)), digits = 1)))
}
reg2n <- NULL
reg2n <- table(mdat[mdat$stockid %in% unique(mdf_list[[1]]$stockid), "reg2"])
for (i in 2:length(mdf_list)) {
  reg2n <- cbind(reg2n, table(mdat[mdat$stockid %in% unique(mdf_list[[i]]$stockid),
                                   "reg2"]))
}
colnames(reg2n) <- labs
print(reg2n)

rm(labs, fnames, reg2n, i, j, k, z, jmin, mdf.full, mdf.devBU, mdf.matBU,
   Bthr.hi, Bthr.lo, Bthr.med, Uthr.hi, Uthr.lo, Uthr.med, Urecovthr,
   Cthr.hi, Cthr.med, Cthr.prev)



# SUMMARY COUNTS OF MANAGEMENT VARIABLES BY REBUILDING STATUS ------------------

CountManByReb <- function(mdf_list = mdf_list, sel_phase = "mdf.matBU") {

  pn_m <- c(0, 0.2, 0.4, 0.6, 0.8, 1)
  pn_n <- seq(0, 1, by = 1/3)
  nobs <- as.data.frame(expand.grid(pn_n, pn_m))
  nobs_vars <- c("natint", "mgtint")
  names(nobs) <- nobs_vars
  nobs$n <- 0
  vars <- c("survey", "assess", "hcr", "quota", "iq", "eez", "fao", "nat")
  d <- mdf_list[names(mdf_list) == sel_phase][[1]]
  d <- d[, c("stockid", "year", "underreb", "mgtint", "natint", vars)]
  cases <- c("hist-noreb_yrs-all", "hist-reb_yrs-all", "hist-reb_yrs-onlyreb",
             "hist-reb_yrs-firstreb")
  d1 <- d[d$stockid %in% unique(mdat[mdat$rebuild_his == "never", "stockid"]), ]
  d2 <- d[d$stockid %in% unique(mdat[mdat$rebuild_his != "never", "stockid"]), ]
  d3 <- d2[d2$underreb == 1, ]
  firstreb <- aggregate(x = d3$year, by = list(d3$stockid), FUN = "min")
  names(firstreb) <- c("stockid", "year")
  firstreb$first <- 1
  d4 <- merge(x = d3, y = firstreb, by = c("stockid", "year"),
              all = TRUE, sort = FALSE)
  d4 <- d4[d4$first == 1 & !is.na(d4$first), -length(d4)]
  d_list <- list(d1, d2, d3, d4)
  case_index_list <- list(nobs, nobs, nobs, nobs)
  names(case_index_list) <- cases
  case_comp_list <- case_index_list
  for (i in 1:length(d_list)) {
    for (j in 1:nrow(nobs)) {
      case_index_list[[i]][j, "n"] <- nrow(
        d_list[[i]][d_list[[i]][, "mgtint"] == case_index_list[[i]][j, "mgtint"] &
                    d_list[[i]][, "natint"] == case_index_list[[i]][j, "natint"], ]
      )
    }
    counts <- apply(X = d_list[[i]][vars], MARGIN = 2, FUN = "sum")
    case_comp_list[[i]] <- counts
  }
  assign("case_index_list", case_index_list, envir = .GlobalEnv)
  assign("case_comp_list", case_comp_list, envir = .GlobalEnv)

}
CountManByReb(mdf_list = mdf_list, sel_phase = "mdf.matBU")

rm(CountManByReb)


print.noquote("s3_wrangle.R complete")
