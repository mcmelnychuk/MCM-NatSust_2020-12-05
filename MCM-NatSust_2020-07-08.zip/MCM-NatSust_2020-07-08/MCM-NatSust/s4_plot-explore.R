###############################
### Plot exploratory figures
###############################
### Plots time series by stock, and summaries of management attribute use
### dependencies: "s1_main.R", "s2_filter.R", "s3_wrangle.R"
### calls: none
###############################


rcol <- "#9a36a9"  # rebuilding color
scol <- "#2172b4"  # stock-level management color
ncol <- "#d2691e"  # national-level management color


# LIFE-HISTORY PAIR PLOTS ------------------------------------------------------

#. for Fig S7
PlotPairsLifeHistory <- function(lh = lh) {
  cairo_pdf(filename = "./out-plots/life-history-coplots.pdf",
            width = 8, height = 8)  # 9
    pp <- ggpairs(lh[, lhpars], lower = list(
      continuous = wrap("points", color = "red", alpha = 0.1)),
      columnLabels = columnLabels, labeller = "label_parsed") +
      theme(panel.background = element_rect(fill = "white", colour = grey(0.8)))
    suppressMessages(print(pp))
  dev.off()
}

lh <- mdat[, c("stockid", "natM", "age50mat", "len50mat",
                 "longevity", "Lmax", "vbK",  "troph")]
lhpars <- c("natM", "age50mat", "len50mat", "longevity", "Lmax", "vbK", "troph")
columnLabels <- as.character(c("M", expression("A[M50]"), expression("L[M50]"),
                               expression("A[MAX]"), expression("L[MAX]"),
                               expression(kappa), "TL"))
suppressWarnings(PlotPairsLifeHistory(lh = lh))



# TIME SERIES LENGTH PER STOCK PER PHASE ---------------------------------------

PlotTsLengthPerStock <- function(mdf_list = mdf_list) {

  cairo_pdf(filename = paste0("./out-plots/years-per-phase_minyts-", minyts,
                              "_RAM-", ramtype, "_", vtype, ".pdf"),
            width = 6.5, height = 8)
    par(mfrow = c(2, 1), oma = c(2, 2, 0, 0), las = 1)

    d3 <- mdf_list$mdf.full
    d3 <- d3[(!is.na(d3$Udiv) | !is.na(d3$Bdiv)), ]
    d3 <- aggregate(formula = year ~ stockid, data = d3, FUN = "length")
    hist(d3$year, breaks = seq(0, 67, by = 1), right = FALSE,
         main = "Full time series", ylab = "", xlab = "", border = grey(0.4),
         col = c(rep("red", minyts), rep(grey(0.5), 67 - minyts + 1)))
    mtext(paste("minyts =", minyts, "excludes", length(d3[d3$year < minyts, "year"]),
                "of", length(d3$year), "stocks"), side = 3, line = 0, cex = 0.8)

    d3 <- mdf_list$mdf.matBU
    d3 <- d3[(!is.na(d3$Udiv) | !is.na(d3$Bdiv)), ]
    d3 <- aggregate(formula = year ~ stockid, data = d3, FUN = "length")
    hist(d3$year, breaks = seq(0, 67, by = 1), right = FALSE,
         main = "Mature fishery phase", ylab = "", xlab = "", border = grey(0.4),
         col = c(rep("red", minyts), rep(grey(0.5), 67 - minyts + 1)))
    mtext(paste("minyts =", minyts, "excludes", length(d3[d3$year < minyts, "year"]),
                "of", length(d3$year), "stocks"), side = 3, line = 0, cex = 0.8)

    mtext("Time series length per stock in phase", side = 1, outer = TRUE)
    mtext("Frequency", side = 2, outer = TRUE, las = 0)

  dev.off()
}
PlotTsLengthPerStock(mdf_list = mdf_list)



# STOCK PLOTS OF TIME SERIES AND IMPLEMENTATIONS -------------------------------

mdf$reg2 <- factor(as.character(mdf$reg2))

#. for Fig S1
PlotStockImplementations <- function(mdf = mdf) {

  par(mfrow = c(5, 1), mar = c(0.5, 4, 0.5, 4), oma = c(3.5, 2, 10.5, 7), las = 1,
      mgp = c(1, 0.4, 0), tcl = -0.2, cex = 1, xaxs = "i", yaxs = "r", xpd = NA)

  iyrs <- merge(x = ndat, y = yof.tab, by.x = "stockid", by.y = "row.names",
                all = TRUE, sort = FALSE)
  iyrs <- merge(x = iyrs, y = unique(mdf[, c("stockid", "reg2")]),
                all.x = TRUE, all.y = FALSE, sort = FALSE)
  iyrs <- iyrs[iyrs$stockid %in% unique(mdf$stockid), ]
  iyrs <- iyrs[order(iyrs$reg2, iyrs$stockid), ]
  ylo <- -4.95
  yvars <- c("Bdiv", "Udiv", "tcmt", "price.pred")

  for (i in iyrs$stockid) {

    mdf[(mdf$stockid == i & mdf$Udiv == 0 & !is.na(mdf$Udiv)), "Udiv"] <- 0.001
    mdf[(mdf$stockid == i & mdf$tcmt == 0 & !is.na(mdf$tcmt)), "tcmt"] <- 0.1
    syof <- NULL
    nyof <- NULL
    syof <- yof.tab[row.names(yof.tab) == i, 1:5]
    names(syof) <- c("Surveys", "Assessments", "HCR", "TACs", "IQs")
    syof <- syof[, order(syof[1, ])]
    nyof <- ndat[ndat$stockid == i, c("year_eez", "year_fao", "year_nat")]
    names(nyof) <- c("EEZ declaration", "UN CA/FSA ratification",
                     ndat[ndat$stockid == i, "policy_nat"])
    nyof <- nyof[, order(nyof[1, ])]
    primary_country <- ndat[ndat$stockid == i, "primary_country"]
    taxon <- unique(mdf[mdf$stockid == i, "txg3"])
    if (taxon == "demfish")  taxon <- "demersal fish"
    if (taxon == "pelfish")  taxon <- "pelagic fish"
    if (taxon == "invert")  taxon <- "invertebrate"
    subtaxon <- unique(mdf[mdf$stockid == i, "txg2"])
    fishery_type <- unique(mdf[mdf$stockid == i, "single_mix"])

    if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      dev.lo <- NULL
      dev.hi <- NULL
      mat.lo <- NULL
      mat.hi <- NULL
      dev.lo <- as.integer(min(
        mdf_list$mdf.devBU[mdf_list$mdf.devBU$stockid == i &
                             (!is.na(mdf_list$mdf.devBU$Udiv) |
                                !is.na(mdf_list$mdf.devBU$Bdiv)), "year"],
        na.rm = TRUE))
      if (isTRUE(dev.lo > 0)) {
        dev.lo <- min(dev.lo, min(mdf[mdf$stockid == i & !is.na(mdf$tcmt), "year"]),
                      na.rm = TRUE)
      }
      dev.hi <- as.integer(max(
        mdf_list$mdf.devBU[mdf_list$mdf.devBU$stockid == i &
                             (!is.na(mdf_list$mdf.devBU$Udiv) |
                                !is.na(mdf_list$mdf.devBU$Bdiv)), "year"],
        na.rm = TRUE))
      mat.lo <- as.integer(min(
        mdf_list$mdf.matBU[mdf_list$mdf.matBU$stockid == i &
                             (!is.na(mdf_list$mdf.matBU$Udiv) |
                                !is.na(mdf_list$mdf.matBU$Bdiv)), "year"],
        na.rm = TRUE))
      mat.hi <- as.integer(max(
        mdf_list$mdf.matBU[mdf_list$mdf.matBU$stockid == i &
                             (!is.na(mdf_list$mdf.matBU$Udiv) |
                                !is.na(mdf_list$mdf.matBU$Bdiv)), "year"],
        na.rm = TRUE))
    if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

    preglab <- NULL
    preg_labs <- ppreds[ppreds$stockid == i, c("p_reg", "prop_p_reg")]
    preg_labs <- preg_labs[preg_labs$prop_p_reg > 0.001, ]
    preg_labs$prop_p_reg <- as.character(round(preg_labs$prop_p_reg * 100, digits = 1))
    preg_labs$preg_lab <- paste0(preg_labs$p_reg, " (", preg_labs$prop_p_reg, "%)")
    preglab <- as.character(paste(preg_labs$preg_lab, collapse = ", "))
    preglab <- strwrap(preglab, indent = 2, exdent = 2, width = 36, simplify = FALSE)

    plot(x = c(fy, ly), y = c(0, 1), type = "n", bty = "n",
         xaxt = "n", yaxt = "n", xlab = "", ylab = "")
    for (k in 1:5) {
      if (syof[, k] < 1950 & !is.na(syof[, k])) {
        segments(x0 = 1950, y0 = ylo, y1 = 0.9 - k * 0.15,
                 col = scol, lty = 2, lwd = 1)
        text(x = 1950, y = 0.9 - k * 0.15,
             pos = 4, offset = 0.2, adj = 0, cex = 0.7, col = scol,
             labels = paste0(names(syof)[k], " (", as.character(syof[, k]), ")"))
      }
      else {
        segments(x0 = syof[, k], y0 = ylo, y1 = 0.9 - k * 0.15,
                 col = scol, lty = 2, lwd = 1)
        text(x = syof[, k], y = 0.9 - k * 0.15, labels = names(syof)[k],
             pos = 4, offset = 0.2, adj = 0, cex = 0.7, col = scol)
      }
    }
    for (k in 1:3) {
      if (nyof[, k] < 1950 & !is.na(nyof[, k])) {
        segments(x0 = 1950, y0 = ylo, y1 = 1.4 - k * 0.15,
                 col = ncol, lty = 4, lwd = 1)
        text(x = 1950, y = 1.4 - k * 0.15,
             pos = 4, offset = 0.2, adj = 0, cex = 0.7, col = ncol,
             labels = paste0(names(nyof)[k], " (", as.character(nyof[, k]), ")"))
      }
      else {
        segments(x0 = nyof[, k], y0 = ylo, y1 = 1.4 - k * 0.15,
                 col = ncol, lty = 4, lwd = 1)
        text(x = nyof[, k], y = 1.4 - k * 0.15, pos = 4, offset = 0.2, adj = 0,
             labels = names(nyof)[k], cex = 0.7, col = ncol)
      }
    }
    rect(xleft = dev.lo - 0.5, xright = dev.hi + 0.5,
         ybottom = c(1.62, -1.27, -2.5, -3.73, -4.96),
         ytop = c(1.85, -0.1875, -1.4175, -2.6475, -3.8775),
         border = NA, col = rgb(0, 1, 0, alpha = 0.075))
    arrows(x0 = dev.lo - 0.5, x1 = dev.hi + 0.5, y0 = 1.68, length = 0.05, code = 3,
           lwd = 1.5, col = "green3")
    arrows(x0 = mat.lo - 0.5, x1 = mat.hi + 0.5, y0 = 1.48, length = 0.05, code = 3,
           lwd = 1.5, col = "green3")
    text(x = dev.lo - 0.5, y = 1.76, labels = "Developing", adj = 0, cex = 0.7)
    text(x = mat.lo - 0.5, y = 1.56, labels = "Mature", adj = 0, cex = 0.7)
    segments(x0 = 2029, y0 = 1.42, y1 = 1.85, col = "green3", lty = 1, lwd = 5)
    text(x = 2030, y = 1.635, adj = 0, cex = 0.8, col = "green3", labels = "Phase")

    if (length(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"]) > 0) {
      rect(xleft = mdf[(mdf$stockid == i & mdf$underreb == 1), "year"] - 0.25,
           xright = mdf[(mdf$stockid == i & mdf$underreb == 1), "year"] + 0.75,
           ybottom = -4.96, ytop = 0.1,
           border = NA,  col = rgb(0.75, 0.26, 0.83, alpha = 0.1))
      segments(x0 = 2029, y0 = 0.07, y1 = 0.78, col = scol, lty = 1, lwd = 5)
      segments(x0 = 2029, y0 = -0.06, y1 = 0.07, col = rcol, lty = 1, lwd = 5)
      segments(x0 = 2029, y0 = 0.04, y1 = 0.1, col = rcol, lty = 1, lwd = 5, lend = 2)
    } else {
      segments(x0 = 2029, y0 = -0.06, y1 = 0.78, col = scol, lty = 1, lwd = 5)
    }
    segments(x0 = 2029, y0 = 0.92, y1 = 1.28, col = ncol, lty = 1, lwd = 5)
    text(x = 2030, y = 1.1, adj = 0, cex = 0.8, col = ncol,
         labels = str_wrap("National/ international level", width = 12))
    text(x = 2030, y = 0.42, adj = 0, cex = 0.8, col = scol,
         labels = str_wrap("Stock level", width = 12))
    mtext(paste0(iyrs[iyrs$stockid == i, "reg2"], " -- ",
                iyrs[iyrs$stockid == i, "stockid"], " -- ",
                iyrs[iyrs$stockid == i, "stocklong"]),
          side = 3, outer = TRUE, line = 6.5, at = 0.01,  adj = 0, cex = 0.8)
    mtext(paste0("taxonomic group: ", taxon, " (", subtaxon,
                 "),   predominant fishery type: ", fishery_type,
                 "-species,   primary country: ", primary_country),
          side = 3, outer = TRUE, line = 5.5, at = 0.05,  adj = 0, cex = 0.7)
    mtext(paste("Fig. S1, page", which(iyrs$stockid == i) + 2, "of", nrow(iyrs) + 2),
          side = 1, outer = TRUE, at = 0.96, adj = 0, line = 0.5, cex = 0.7)

    for (j in yvars) {

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
        ymin <- 1
        ymax <- 1
        if (j == "Udiv" | j == "Bdiv") {
          ymin <- max(0.005, min(0.5, min(mdf[mdf$stockid == i, j], na.rm = TRUE)))
          ymax <- max(2, max(mdf[mdf$stockid == i, j], na.rm = TRUE))
          if (is.na(ymin) | ymin == "Inf" | ymin == "-Inf")  ymin <- 0.5
          if (is.na(ymax) | ymax == "Inf" | ymax == "-Inf")  ymax <- 2
        }
        if (j == "tcmt") {
          ymin <- 0
          ymax <- max(msymc[msymc$stockid == i, "msymcmt"], mdf[mdf$stockid == i, j],
                      na.rm = TRUE) * 1.05
          if (is.na(ymax) | ymax == "Inf" | ymax == "-Inf")  ymax <- 1000
        }
        if (j == "price.pred") {
          ymin <- 0
          ymax <- max(mdf[mdf$stockid == i, j], mdf[mdf$stockid == i, "price.obs"],
                      na.rm = TRUE) * 1.05
          if (is.na(ymax) | ymax == "Inf" | ymax == "-Inf")  ymax <- 1000
        }
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

      pcol <- "black"
      if (j == "price.pred")  pcol = "darkorange"
      if (j == "Bdiv" | j == "Udiv") {
        plot(x = mdf[mdf$stockid == i, "year"], y = mdf[mdf$stockid == i, j],
             xlim = c(fy, ly), ylim = c(ymin, ymax), log = "y",
             bty = "n", xpd = FALSE, main = "",
             xlab = "", ylab = "", xaxt = "n", yaxt = "n", cex.axis = 0.8,
             type = "o", lty = 1, lwd = 2.5, pch = 16, cex = 0.7, col = pcol)
      }
      if (j == "tcmt" | j == "price.pred") {
        plot(x = mdf[mdf$stockid == i, "year"], y = mdf[mdf$stockid == i, j],
             xlim = c(fy, ly), ylim = c(ymin, ymax), yaxs = "i",
             bty = "n", xpd = FALSE, main = "",
             xlab = "", ylab = "", xaxt = "n", yaxt = "n", cex.axis = 0.8,
             type = "o", lty = 1, lwd = 2.5, pch = 16, cex = 0.7, col = pcol)
      }
      axis(side = 2, lwd = 0.25, lwd.ticks = 0.5, cex.axis = 0.8,
           col.axis = "black", col = grey(0.5), col.ticks = grey(0.5), xpd = FALSE)
      box(lty = 1, lwd = 0.5, col = grey(0.5))

      if (j == "Bdiv") {
        abline(h = 1, lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        abline(h = c(1/512, 1/256, 1/128, 1/64, 1/32, 1/16, 1/8, 1/4, 1/2,
                     2, 4, 8, 16, 32, 64, 128),
               lty = 3, lwd = 1, col = grey(0.7), xpd = FALSE)
        mtext(expression(B/B[ REF]), side = 2, las = 0, line = 3, cex = 0.8)
        if (vtype == "msy") {
          if (is.na(BUids[BUids$stockid == i, "BdivBmsypref"])) {
            mtext("NA", side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          } else {
            mtext(paste(BUids[BUids$stockid == i, "BdivBmsypref"], "= 1"),
                  side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          }
        }
        if (vtype == "mgt") {
            if (is.na(BUids[BUids$stockid == i, "BdivBmgtpref"])) {
            mtext("NA", side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          } else {
            mtext(paste(BUids[BUids$stockid == i, "BdivBmgtpref"], "= 1"),
                  side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          }
        }
        if (length(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"]) > 0) {
          mtext("Rebuilding plan", side = 3, line = 1, adj = 0,
                cex = 0.7, font = 1, col = rcol,
                at = min(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"],
                         na.rm = TRUE) + 0.2)
        }
      }
      if (j == "Udiv") {
        abline(h = 1, lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        abline(h = c(1/512, 1/256, 1/128, 1/64, 1/32, 1/16, 1/8, 1/4, 1/2,
                     2, 4, 8, 16, 32, 64, 128),
               lty = 3, lwd = 1, col = grey(0.7), xpd = FALSE)
        mtext(expression(U/U[ REF]), side = 2, las = 0, line = 3, cex = 0.8)
        if (vtype == "msy") {
          if (is.na(BUids[BUids$stockid == i, "UdivUmsypref"])) {
            mtext("NA", side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          } else {
            mtext(paste(BUids[BUids$stockid == i, "UdivUmsypref"], "= 1"),
                  side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          }
        }
        if (vtype == "mgt") {
          if (is.na(BUids[BUids$stockid == i, "UdivUmgtpref"])) {
            mtext("NA", side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          } else {
            mtext(paste(BUids[BUids$stockid == i, "UdivUmgtpref"], "= 1"),
                  side = 4, outer = FALSE, line = 0.5, adj = 0, at = 1, cex = 0.6)
          }
        }
      }
      if (j == "tcmt") {
        mtext("Catch (t)", side = 2, las = 0, line = 3, cex = 0.8)
        if (!is.na(msymc[msymc$stockid == i, "msymcmt"])) {
          abline(h = msymc[msymc$stockid == i, "MSYbest"],
                 lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
          abline(h = msymc[msymc$stockid == i, "meancmt"],
                 lty = 3, lwd = 1.5, col = grey(0.5), xpd = FALSE)
          if (!is.na(msymc[msymc$stockid == i, "MSYbest"]) &
              !is.na(msymc[msymc$stockid == i, "meancmt"])) {
            if (msymc[msymc$stockid == i, "MSYbest"] >
                msymc[msymc$stockid == i, "meancmt"]) {
              mtext(paste("MSY:", msymc[msymc$stockid == i, "MSYbest_id"]),
                    at = msymc[msymc$stockid == i, "MSYbest"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 0)
              mtext("mean catch: MT", at = msymc[msymc$stockid == i, "meancmt"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 1)
            } else {
              mtext(paste("MSY:", msymc[msymc$stockid == i, "MSYbest_id"]),
                    at = msymc[msymc$stockid == i, "MSYbest"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 1)
              mtext("mean catch: MT", at = msymc[msymc$stockid == i, "meancmt"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 0)
            }
          } else {
            if (!is.na(msymc[msymc$stockid == i, "MSYbest"])) {
              mtext(paste("MSY:", msymc[msymc$stockid == i, "MSYbest_id"]),
                    at = msymc[msymc$stockid == i, "MSYbest"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 0.5)
            }
            if (!is.na(msymc[msymc$stockid == i, "meancmt"])) {
              mtext("mean catch: MT", at = msymc[msymc$stockid == i, "meancmt"],
                    side = 4, outer = FALSE, line = 0.5, adj = 0, cex = 0.6, padj = 0.5)
            }
          }
        }
      }
      if (j == "price.pred") {
        abline(h = mean(mdf[mdf$stockid == i, "mprice"], na.rm = TRUE),
               lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        text(x = 1972, y = mean(mdf[mdf$stockid == i, "mprice"], na.rm = TRUE),
             labels = "Mean predicted price 2001-2010", pos = 3, offset = 0.2, cex = 0.6)
        mtext("Real price (2015 $USD/t)", side = 2, las = 0, line = 3, cex = 0.8)
        axis(side = 1, xaxt = "s", at = seq(1950, 2015, by = 5),
             labels = c("1950", "", "1960", "", "1970", "", "1980", "",
                        "1990", "", "2000", "", "2010", ""),
             lwd = 0.25, lwd.ticks = 0.5, cex.axis = 0.8,
             col = grey(0.5), col.ticks = "black", col.axis = "black")
        lines(x = mdf[mdf$stockid == i, "year"], y = mdf[mdf$stockid == i, "price.obs"],
           type = "o", lty = 1, lwd = 2.5, pch = 16, cex = 0.7, col = "black")
        legend(x = "topleft", legend = c("Observed", "Predicted"),
               col = c("black", "darkorange"), lty = 1, lwd = 2.5, pch = 16,
               cex = 0.7, inset = c(0.001, 0.005),
               bty = "o", box.lty = 1, box.lwd = 0.5, box.col = grey(0.8))
        mtext("predictions for taxon:", side = 4, outer = TRUE,
              at = 0.185, line = -3.5, adj = 0, cex = 0.6)
        mtext(paste0("  ", ppreds[ppreds$stockid == i, "isscaap"][1]),
              side = 4, outer = TRUE, at = 0.17, line = -3.5, adj = 0, cex = 0.6)
        mtext(paste0("  > ", ppreds[ppreds$stockid == i, "tF"][1]),
              side = 4, outer = TRUE, at = 0.155, line = -3.5, adj = 0, cex = 0.6)
        mtext(paste0("    > ", ppreds[ppreds$stockid == i, "tG"][1]),
              side = 4, outer = TRUE, at = 0.14, line = -3.5, adj = 0, cex = 0.6)
        mtext(paste0("      > ", ppreds[ppreds$stockid == i, "tS"][1]),
              side = 4, outer = TRUE, at = 0.125, line = -3.5, adj = 0, cex = 0.6)
        mtext("from regions:",
              side = 4, outer = TRUE, at = 0.11, line = -3.5, adj = 0, cex = 0.6)
        for (k in 1:length(preglab[[1]])) {
          mtext(preglab[[1]][k], side = 4, outer = TRUE,
                at = 0.11 - 0.015 * k, line = -3.5, adj = 0, cex = 0.6)
        }
      }
    }
  }
}
cairo_pdf(filename = paste0("./out-plots/stock-implementations_RAM-",
                            ramtype, "-", vtype, ".pdf"),
          onefile = TRUE, width = 8.5, height = 11)
PlotStockImplementations(mdf = mdf)
dev.off()


#. similar to Fig 2
ShortPlotStockImplementations <- function(mdf = mdf) {

  par(mfrow = c(4, 1), mar = c(0.3, 4, 0.4, 4), oma = c(1, 0, 6, 3), las = 1,
      mgp = c(1, 0.4, 0), tcl = -0.2, cex = 1, xaxs = "i", yaxs = "r", xpd = NA)

  iyrs <- merge(x = ndat, y = yof.tab, by.x = "stockid", by.y = "row.names",
                all = TRUE, sort = FALSE)
  iyrs <- merge(x = iyrs, y = unique(mdf[, c("stockid", "reg2")]),
                all.x = TRUE, all.y = FALSE, sort = FALSE)
  iyrs <- iyrs[iyrs$stockid %in% unique(mdf$stockid), ]
  iyrs <- iyrs[order(iyrs$reg2, iyrs$stockid), ]
  ylo <- -3.79
  yvars <- c("Bdiv", "Udiv", "tcmt")

  for (i in iyrs$stockid) {

    mdf[(mdf$stockid == i & mdf$Udiv == 0 & !is.na(mdf$Udiv)), "Udiv"] <- 0.001
    mdf[(mdf$stockid == i & mdf$tcmt == 0 & !is.na(mdf$tcmt)), "tcmt"] <- 0.1
    syof <- NULL
    nyof <- NULL
    syof <- yof.tab[row.names(yof.tab) == i, 1:5]
    names(syof) <- c("Surveys", "Assessments", "HCR", "TACs", "IQs")

    syof <- syof[, order(syof[1, ])]
    nyof <- ndat[ndat$stockid == i, c("year_eez", "year_fao", "year_nat")]
    names(nyof) <- c("EEZ declaration", "UN CA/FSA ratification",
                     ndat[ndat$stockid == i, "policy_nat"])
    nyof <- nyof[, order(nyof[1, ])]

    if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      dev.lo <- NULL
      dev.hi <- NULL
      mat.lo <- NULL
      mat.hi <- NULL
      dev.lo <- as.integer(min(
        mdf_list$mdf.devBU[mdf_list$mdf.devBU$stockid == i &
                             (!is.na(mdf_list$mdf.devBU$Udiv) |
                                !is.na(mdf_list$mdf.devBU$Bdiv)), "year"],
        na.rm = TRUE))
      if (isTRUE(dev.lo > 0)) {
        dev.lo <- min(dev.lo, min(mdf[mdf$stockid == i & !is.na(mdf$tcmt), "year"]),
                      na.rm = TRUE)
      }
      dev.hi <- as.integer(max(
        mdf_list$mdf.devBU[mdf_list$mdf.devBU$stockid == i &
                             (!is.na(mdf_list$mdf.devBU$Udiv) |
                                !is.na(mdf_list$mdf.devBU$Bdiv)), "year"],
        na.rm = TRUE))
      mat.lo <- as.integer(min(
        mdf_list$mdf.matBU[mdf_list$mdf.matBU$stockid == i &
                             (!is.na(mdf_list$mdf.matBU$Udiv) |
                                !is.na(mdf_list$mdf.matBU$Bdiv)), "year"],
        na.rm = TRUE))
      mat.hi <- as.integer(max(
        mdf_list$mdf.matBU[mdf_list$mdf.matBU$stockid == i &
                             (!is.na(mdf_list$mdf.matBU$Udiv) |
                                !is.na(mdf_list$mdf.matBU$Bdiv)), "year"],
        na.rm = TRUE))
    if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

    plot(x = c(fy, ly), y = c(0, 1), type = "n", bty = "n",
         xaxt = "n", yaxt = "n", xlab = "", ylab = "")
    for (k in 1:5) {
      if (syof[, k] < 1950 & !is.na(syof[, k])) {
        segments(x0 = 1950, y0 = ylo, y1 = 0.9 - k * 0.15,
                 col = scol, lty = 2, lwd = 1)
        text(x = 1950, y = 0.9 - k * 0.15,
             pos = 4, offset = 0.1, adj = 0, cex = 0.7, col = scol,
             labels = paste0(names(syof)[k], " (", as.character(syof[, k]), ")"))
      }
      else {
        segments(x0 = syof[, k], y0 = ylo, y1 = 0.9 - k * 0.15,
                 col = scol, lty = 2, lwd = 1)
        text(x = syof[, k], y = 0.9 - k * 0.15, labels = names(syof)[k],
             pos = 4, offset = 0.1, adj = 0, cex = 0.7, col = scol)
      }
    }
    for (k in 1:3) {
      if (nyof[, k] < 1950 & !is.na(nyof[, k])) {
        segments(x0 = 1950, y0 = ylo, y1 = 1.4 - k * 0.15,
                 col = ncol, lty = 4, lwd = 1)
        text(x = 1950, y = 1.4 - k * 0.15,
             pos = 4, offset = 0.1, adj = 0, cex = 0.7, col = ncol,
             labels = paste0(names(nyof)[k], " (", as.character(nyof[, k]), ")"))
      }
      else {
        segments(x0 = nyof[, k], y0 = ylo, y1 = 1.4 - k * 0.15,
                 col = ncol, lty = 4, lwd = 1)
        text(x = nyof[, k], y = 1.4 - k * 0.15, pos = 4, offset = 0.1, adj = 0,
             labels = names(nyof)[k], cex = 0.7, col = ncol)
      }
    }
    rect(xleft = dev.lo - 0.5, xright = dev.hi + 0.5,
         ybottom = c(1.62, -1.29, -2.54, -3.79),
         ytop = c(1.85, -0.21, -1.46, -2.71),
         border = NA, col = rgb(0, 1, 0, alpha = 0.075))
    arrows(x0 = dev.lo - 0.5, x1 = dev.hi + 0.5, y0 = 1.68, length = 0.05, code = 3,
           lwd = 1.5, col = "green3")
    arrows(x0 = mat.lo - 0.5, x1 = mat.hi + 0.5, y0 = 1.48, length = 0.05, code = 3,
           lwd = 1.5, col = "green3")
    text(x = dev.lo - 0.5, y = 1.77, labels = "Developing", adj = 0, cex = 0.7)
    text(x = mat.lo - 0.5, y = 1.58, labels = "Mature", adj = 0, cex = 0.7)
    segments(x0 = 2025, y0 = 1.42, y1 = 1.85, col = "green3", lty = 1, lwd = 5)
    text(x = 2026, y = 1.635, adj = 0, cex = 0.8, col = "green3", labels = "Phase")

    if (length(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"]) > 0) {
      rect(xleft = mdf[(mdf$stockid == i & mdf$underreb == 1), "year"] - 0.25,
           xright = mdf[(mdf$stockid == i & mdf$underreb == 1), "year"] + 0.75,
           ybottom = ylo, ytop = 0.05,
           border = NA,  col = rgb(0.75, 0.26, 0.83, alpha = 0.1))
      segments(x0 = 2025, y0 = 0.03, y1 = 0.78, col = scol, lty = 1, lwd = 5)
      segments(x0 = 2025, y0 = -0.12, y1 = 0.03, col = rcol, lty = 1, lwd = 5)
      segments(x0 = 2025, y0 = 0, y1 = 0.06, col = rcol, lty = 1, lwd = 5, lend = 2)
    } else {
      segments(x0 = 2025, y0 = -0.12, y1 = 0.78, col = scol, lty = 1, lwd = 5)
    }
    segments(x0 = 2025, y0 = 0.92, y1 = 1.28, col = ncol, lty = 1, lwd = 5)
    text(x = 2026, y = 1.1, adj = 0, cex = 0.8, col = ncol,
         labels = str_wrap("National/ international level", width = 12))
    text(x = 2026, y = 0.42, adj = 0, cex = 0.8, col = scol,
         labels = str_wrap("Stock level", width = 12))
    mtext(paste0(iyrs[iyrs$stockid == i, "reg2"], " -- ",
                iyrs[iyrs$stockid == i, "stockid"], " -- ",
                iyrs[iyrs$stockid == i, "stocklong"]),
          side = 3, outer = TRUE, line = 5, at = 0.01,  adj = 0, cex = 0.8)

    for (j in yvars) {

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
        ymin <- 1
        ymax <- 1
        if (j == "Udiv" | j == "Bdiv") {
          ymin <- max(0.01, min(0.5, min(mdf[mdf$stockid == i, j], na.rm = TRUE)))
          ymax <- max(2, max(mdf[mdf$stockid == i, j], na.rm = TRUE))
          if (is.na(ymin) | ymin == "Inf" | ymin == "-Inf")  ymin <- 0.5
          if (is.na(ymax) | ymax == "Inf" | ymax == "-Inf")  ymax <- 2
        }
        if (j == "tcmt") {
          ymin <- 0
          ymax <- max(msymc[msymc$stockid == i, "msymcmt"], mdf[mdf$stockid == i, j],
                      na.rm = TRUE) * 1.05
          if (is.na(ymax) | ymax == "Inf" | ymax == "-Inf")  ymax <- 1000
        }
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

      pcol <- "black"
      if (j == "Bdiv" | j == "Udiv") {
        plot(x = mdf[mdf$stockid == i, "year"], y = mdf[mdf$stockid == i, j],
             xlim = c(fy, ly), ylim = c(ymin, ymax), log = "y",
             bty = "n", xpd = FALSE, main = "",
             xlab = "", ylab = "", xaxt = "n", yaxt = "n", cex.axis = 0.8,
             type = "o", lty = 1, lwd = 2.5, pch = 16, cex = 0.7, col = pcol)
      }
      if (j == "tcmt") {
        plot(x = mdf[mdf$stockid == i, "year"], y = mdf[mdf$stockid == i, j],
             xlim = c(fy, ly), ylim = c(ymin, ymax), yaxs = "i",
             bty = "n", xpd = FALSE, main = "",
             xlab = "", ylab = "", xaxt = "n", yaxt = "n", cex.axis = 0.8,
             type = "o", lty = 1, lwd = 2.5, pch = 16, cex = 0.7, col = pcol)
      }
      axis(side = 2, lwd = 0.25, lwd.ticks = 0.5, cex.axis = 0.8,
           col.axis = "black", col = grey(0.5), col.ticks = grey(0.5), xpd = FALSE)
      box(lty = 1, lwd = 0.5, col = grey(0.5))

      if (j == "Bdiv") {
        abline(h = 1, lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        mtext(expression(B/B[ REF]), side = 2, las = 0, line = 3, cex = 0.8)
        if (length(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"]) > 0) {
          mtext("Rebuilding plan", side = 3, line = 0.25, adj = 0, col = rcol,
                cex = 0.7, font = 1,
                at = min(mdf[(mdf$stockid == i & mdf$underreb == 1), "year"],
                         na.rm = TRUE) + 0.2)
        }
      }
      if (j == "Udiv") {
        abline(h = 1, lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        mtext(expression(U/U[ REF]), side = 2, las = 0, line = 3, cex = 0.8)
      }
      if (j == "tcmt") {
        mtext("Catch (t)", side = 2, las = 0, line = 3, cex = 0.8)
        axis(side = 1, xaxt = "s", at = seq(1950, 2015, by = 5),
             labels = c("1950", "", "1960", "", "1970", "", "1980", "",
                        "1990", "", "2000", "", "2010", ""),
             lwd = 0.25, lwd.ticks = 0.5, cex.axis = 0.8,
             col = grey(0.5), col.ticks = "black", col.axis = "black")
        if (!is.na(msymc[msymc$stockid == i, "msymcmt"])) {
          abline(h = msymc[msymc$stockid == i, "MSYbest"],
                 lty = 2, lwd = 1.5, col = grey(0.5), xpd = FALSE)
          abline(h = msymc[msymc$stockid == i, "meancmt"],
                 lty = 3, lwd = 1.5, col = grey(0.5), xpd = FALSE)
        }
      }
    }
  }
}
cairo_pdf(filename = paste0("./out-plots/short-stock-implementations_RAM-",
                            ramtype, "-", vtype, ".pdf"),
          onefile = TRUE, width = 6.5, height = 5.5)
ShortPlotStockImplementations(mdf = mdf)
dev.off()



# PLOT IMPLEMENTATION OF MANAGEMENT MEASURES OVER TIME -------------------------

#. by region, for Fig S2

PlotRegionImplementation <- function(ilist = impl_list) {
  ilist <- list(ilist$underreb, ilist$survey, ilist$assess, ilist$hcr, ilist$quota,
                ilist$iq, ilist$eez, ilist$fao, ilist$nat)
  names(ilist) <- c("underreb", "survey", "assess", "hcr", "quota", "iq",
                    "eez", "fao", "nat")
  iilist <- list((ilist$survey + ilist$assess + ilist$hcr + ilist$quota + ilist$iq) / 5,
                 (ilist$eez + ilist$fao + ilist$nat) / 3)
  icols <- c(rcol, rep(scol, 5), rep(ncol, 3))
  ilty <- c(1, 3, 2, 4, 5, 6, 3, 2, 4)
  ilwd <- c(2.5, rep(1.25, 8))
  inames <- c("Rebuilding plan", "Scientific survey", "Stock assessment",
              "Harvest control rule", "Fleet-wide catch limit", "Individual quotas",
              "EEZ declaration", "UN CA/FSA ratification",
              "National/international policy")

  par(mfrow = c(5, 4), mar = c(0.25, 0.25, 2, 0.25), oma = c(1.5, 3, 0, 0),
      las = 1, mgp = c(1.5, 0.5, 0), tcl = -0.2, cex.main = 0.9, font.main = 1,
      xaxs = "i", yaxs = "i")
  ymax <- max(nstocks)
  for (i in 1:ncol(ilist[[1]])) {
    plot(x = fy:ly, y = ilist[[1]][1:nrow(ilist[[1]]), i],
         ylim = c(0, ymax + 1), xaxt = "n", yaxt = "n", bty = "n", type = "n",
         ylab = "", xlab = "", main = "")
    abline(h = nstocks[i], lty = "longdash", lwd = 0.5, col = grey(0.5))
    if (i %in% c(1, 5, 9, 13, 17)) {
      axis(side = 2, lwd = 0.25, cex = 0.8, col.axis = "black", col = grey(1),
           col.ticks = grey(0.5))
    } else {
      axis(side = 2, labels = FALSE, lwd = 0.25, cex = 0.8, col = grey(1),
           col.ticks = grey(0.5))
    }
    if (i %in% c(14:17)) {
      axis(side = 1, at = c(1960, 1980, 2000), lwd = 0.25, cex = 0.8,
           col.axis = "black", col = grey(1), col.ticks = grey(0.5))
    } else {
      axis(side = 1, labels = FALSE, lwd = 0.25, cex = 0.8, col = grey(1),
           col.ticks = grey(0.5))
    }
    box(col = grey(0.5), lwd = 0.5)
    mtext(colnames(ilist[[1]][i]), side = 3, cex = 0.8)
    for (j in rev(1:length(ilist))) {
      lines(x = fy:ly, y = ilist[[j]][1:nrow(ilist[[j]]), i],
            col = icols[j], lty = ilty[j], lwd = ilwd[j])
    }
    lines(x = fy:ly, y = iilist[[2]][1:nrow(iilist[[2]]), i], col = ncol,
          lwd = 2.5, lty = 1)
    lines(x = fy:ly, y = iilist[[1]][1:nrow(iilist[[1]]), i], col = scol,
          lwd = 2.5, lty = 1)
  }
  legend(x = ly + 10, y = ymax / 2.2, legend = inames, col = icols, lty = ilty,
         lwd = ilwd, bty = "n", xjust = 0, yjust = 0.5, cex = 1.15, seg.len = 3,
         y.intersp = 0.95, title = "Management measure:", xpd = NA)
  CurlyBraces(x0 = 2124, x1 = 2124, y0 = 9, y1 = 25, pos = 1, depth = 5,
              col = scol, lwd = 1.25)
  CurlyBraces(x0 = 2124, x1 = 2124, y0 = -1.5, y1 = 7.5, pos = 1, depth = 5,
              col = ncol, lwd = 1.25)
  segments(x0 = 2206, x1 = 2220, y0 = 16.5, col = scol, lwd = 2.5, lty = 1, xpd = NA)
  segments(x0 = 2206, x1 = 2220, y0 = 3, col = ncol, lwd = 2.5, lty = 1, xpd = NA)
  mtext("Stock-level \n management intensity index", side = 4, outer = FALSE,
        line = 19.2, at = 16.5, adj = 0, cex = 0.75)
  mtext("National/international-level \n management intensity index",
        side = 4,  outer = FALSE, line = 19.2, at = 3, adj = 0, cex = 0.75)
  mtext("Number of stocks with management measure implemented, or sum across stocks of aggregate index",
        side = 2, outer = TRUE, line = 2, cex = 0.8, las = 0)
}
cairo_pdf(filename = paste0("./out-plots/region-implementations.pdf"),
          width = 6.5, height = 8.75)
PlotRegionImplementation(ilist = impl_list)
dev.off()


#. all regions combined, for Fig 1A

PlotAllImplementation <- function(ilist = impl_list) {
  ilist <- list(ilist$underreb, ilist$survey, ilist$assess, ilist$hcr, ilist$quota,
                ilist$iq, ilist$eez, ilist$fao, ilist$nat)
  names(ilist) <- c("underreb", "survey", "assess", "hcr", "quota", "iq",
                    "eez", "fao", "nat")
  for (i in 1:length(ilist)) {
    ilist[[i]]$all <- rowSums(ilist[[i]])
  }
  iilist <- list((ilist$survey + ilist$assess + ilist$hcr + ilist$quota + ilist$iq) / 5,
                 (ilist$eez + ilist$fao + ilist$nat) / 3)

  icols_s <- c(rcol, rep(scol, 5))
  icols_n <- rep(ncol, 3)
  icols <- c(icols_s, icols_n)
  ilty_s <- c(1, 3, 2, 4, 5, 6, 3, 2, 4)
  ilty_n <- c(3, 2, 4)
  ilty <- c(ilty_s, ilty_n)
  ilwd_s <- c(3, rep(1.5, 5))
  ilwd_n <- rep(1.5, 3)
  ilwd <- c(ilwd_s, ilwd_n)

  inames_s <- c("Rebuilding plan", "Scientific survey", "Stock assessment",
                "Harvest control rule", "Fleet-wide catch limit", "Individual quotas")
  inames_n <- c("EEZ declaration", "UN CA/FSA ratification",
                "National/international policy")

  par(mfrow = c(1, 1), mar = c(0.25, 0.25, 0.25, 0.25), oma = c(1, 2.5, 0, 11), las = 1,
      mgp = c(1.5, 0.25, 0), tcl = -0.2, font.main = 1, xaxs = "i", yaxs = "i")
  ymax <- sum(nstocks)

  plot(x = fy:ly, y = ilist[[1]][, length(ilist[[1]])] / ymax,
       ylim = c(0, 1.01), xaxt = "n", yaxt = "n", bty = "n", type = "n",
       ylab = "", xlab = "", main = "")
  abline(h = 1, lty = 3)
  axis(side = 2, lwd = 0.25, cex.axis = 0.75, col.axis = "black", col = grey(1),
       col.ticks = grey(0.5), at = seq(0, 1, by = 0.2),
       labels = c("0.0", "0.2", "0.4", "0.6", "0.8", "1.0"))
  axis(side = 1, lwd = 0.25, cex.axis = 0.75, col.axis = "black", col = grey(1),
       col.ticks = grey(0.5))
  box(col = grey(0.5), lwd = 0.5)
  for (j in rev(1:length(ilist))) {
    lines(x = fy:ly, y = ilist[[j]][, length(ilist[[j]])] / ymax,
          col = icols[j], lwd = ilwd[j], lty = ilty[j])
  }
  lines(x = fy:ly, y = iilist[[2]][, length(ilist[[2]])] / ymax,
        col = ncol, lwd = 3, lty = 1)
  lines(x = fy:ly, y = iilist[[1]][, length(ilist[[1]])] / ymax,
        col = scol, lwd = 3, lty = 1)

  mtext("Stock-level measures:", side = 4, outer = FALSE,
        line = 0.4, at = 0.975, adj = 0, cex = 0.85)
  mtext("National-level measures:", side = 4, outer = FALSE,
        line = 0.4, at = 0.38, adj = 0, cex = 0.85)
  legend(x = ly + 1, y = 0.95, legend = inames_s, col = icols_s, lty = ilty_s,
         lwd = ilwd_s, bty = "n", xjust = 0, yjust = 1, cex = 0.75, seg.len = 2.7,
         y.intersp = 1, xpd = NA)
  legend(x = ly + 1, y = 0.35, legend = inames_n, col = icols_n, lty = ilty_n,
         lwd = ilwd_n, bty = "n", xjust = 0, yjust = 1, cex = 0.75, seg.len = 2.7,
         y.intersp = 1, xpd = NA)
  CurlyBraces(x0 = 2054.25, x1 = 2054.25, y0 = 0.645, y1 = 0.865,
              pos = 1, depth = 2, col = scol, lwd = 1.25)
  CurlyBraces(x0 = 2054.25, x1 = 2054.25, y0 = 0.185, y1 = 0.315,
              pos = 1, depth = 2, col = ncol, lwd = 1.25)
  arrows(x0 = 2054, x1 = 2052.5, y0 = 0.635, y1 = 0.59, code = 2, length = 0.03,
           col = scol, lwd = 1.25, lty = 1, xpd = NA)
  arrows(x0 = 2054, x1 = 2052.5, y0 = 0.175, y1 = 0.13, code = 2, length = 0.03,
           col = ncol, lwd = 1.25, lty = 1, xpd = NA)
  segments(x0 = 2019, x1 = 2024, y0 = 0.56,
           col = scol, lwd = 3, lty = 1, xpd = NA)
  segments(x0 = 2019, x1 = 2024, y0 = 0.10,
           col = ncol, lwd = 3, lty = 1, xpd = NA)
  mtext("Stock-level \nmanagement intensity index", side = 4,
        outer = FALSE, line = 2.95, at = 0.54, adj = 0, cex = 0.75)
  mtext("National/international-level \nmanagement intensity index", side = 4,
        outer = FALSE, line = 2.95, at = 0.08, adj = 0, cex = 0.75)
  mtext("Proportion of stocks with measure implemented",
        side = 2, outer = TRUE, line = 1.74, cex = 0.85, las = 0)
  text(x = 1975, y = 1, labels = "n = 288 stocks", pos = 1, offset = 0.2, cex = 0.75)
}
cairo_pdf(filename = paste0("./out-plots/all-regions-implementations.pdf"),
          width = 6.5, height = 3.5)
PlotAllImplementation(ilist = impl_list)
dev.off()



# PLOT UU AND BB TIME SERIES CENTERED ON INDIVIDUAL INTERVENTIONS --------------

#. for Fig S9
PlotCenteredInterventions <- function(sp = spU_list, yvar = "U") {
  sp <- list(sp$underreb, sp$survey, sp$assess, sp$hcr, sp$quota,
                sp$iq, sp$eez, sp$fao, sp$nat)
  names(sp) <- c("underreb", "survey", "assess", "hcr", "quota", "iq",
                 "eez", "fao", "nat")
  snames <- c("Rebuilding plan", "Scientific survey", "Stock assessment",
              "Harvest control rule", "Fleet-wide catch limit", "Individual quotas",
              "EEZ declaration", "UN CA/FSA ratification",
              "National/international policy")
  scols <- c(rcol, rep(scol, 5), rep(ncol, 3))

  cairo_pdf(filename = paste0("./out-plots/centered-", yvar,
                            "_RAM-", ramtype, "-", vtype, ".pdf"),
            width = 6.5, height = 8.5)

    par(mfrow = c(3, 3), mar = c(0, 0.85, 2.5, 0.1), oma = c(3, 3.2, 1, 0.35), las = 1,
        mgp = c(1.5, 0.25, 0), tcl = -0.2, font.main = 1, xaxs = "i", yaxs = "i")
    ymax <- 20

    for (i in 1:length(sp)) {
      plot(x = -9:10, y = sp[[1]][1, ], log = "y", ylim = c(0.05, ymax), type = "n",
           xaxt = "n", yaxt = "n", bty = "n", ylab = "", xlab = "", main = "")
      abline(v = 0, lty = 3, col = grey(0.5))
      abline(h = 1, lty = 2, col = grey(0.5))
      if (i %in% c(1, 4, 7)) {
        axis(side = 2, lwd = 0.25, cex.axis = 1,
             col.axis = "black", col = grey(1),col.ticks = grey(0.5))
      }
      if (i %in% 7:9) {
        axis(side = 1, lwd = 0.25, cex.axis = 1,
             col.axis = "black", col = grey(1),col.ticks = grey(0.5))
      }
      if (i == 2) {
        legend(x = "top", inset = -0.24, horiz = TRUE, bty = "n", cex = 1.25,
           legend = c("  Stock-level measures  ",
                      "  National/international-level measures  "),
           col = c(rcol, "white"), text.col = "white",
           pch = 0, pt.cex = 2, pt.lwd = 1.5, xpd = NA)
        legend(x = "top", inset = -0.24, horiz = TRUE, bty = "n", cex = 1.25,
           legend = c("Stock-level measures",
                      "National/international-level measures"),
           col = c(scol, ncol),
           pch = 0, pt.cex = 2, pt.lwd = 1.5, xpd = NA)
      }
      for (j in 1:nrow(sp[[i]])) {
        if (sum(!is.na(sp[[i]][j, ])) > 0) {
          sp_stock <- sp[[i]][j, ]
          sp_stock[!is.na(sp_stock) & sp_stock == 0] <- 0.001
          lines(x = -9:10, y = sp_stock, lwd = 2, lty = 1,
                col = rgb(0, 1, 0, alpha = 0.08))
        }
      }
      q50 <- apply(sp[[i]], 2, FUN = "quantile", probs = 0.5, na.rm = TRUE)
      q25 <- apply(sp[[i]], 2, FUN = "quantile", probs = 0.25, na.rm = TRUE)
      q75 <- apply(sp[[i]], 2, FUN = "quantile", probs = 0.75, na.rm = TRUE)
      lines(x = -9:10, y = q50, lwd = 2, lty = 1, col = "black")
      lines(x = -9:10, y = q25, lwd = 1, lty = 5, col = "black")
      lines(x = -9:10, y = q75, lwd = 1, lty = 5, col = "black")
      box(col = scols[i], lwd = 1.5)
      mtext(snames[i], side = 3, outer = FALSE, line = 0, cex = 0.85)
      nstocks <- sum(!is.na(rowSums(x = sp[[i]], na.rm = FALSE)))
      mtext(paste("n =", nstocks, "stocks"), side = 3, outer = FALSE,
            line = -1, at = -8.5, adj = 0, cex = 0.75, font = 3)
    }
    mtext("Years after implementation", side = 1, outer = TRUE, line = 1.9, cex = 0.85)
    if (yvar == "U") {
      mtext(expression(U/U[REF]), side = 2, outer = TRUE,
            line = 1.95, cex = 0.85, las = 0)
      mtext("A", side = 3, outer = TRUE,
            line = -0.2, at = -0.07, adj = 0, font = 2, cex = 1)
    }
    if (yvar == "B") {
      mtext(expression(B/B[REF]), side = 2, outer = TRUE,
            line = 1.95, cex = 0.85, las = 0)
      mtext("B", side = 3, outer = TRUE,
            line = -0.2, at = -0.07, adj = 0, font = 2, cex = 1)
    }
  dev.off()
}
PlotCenteredInterventions(sp = spU_list, yvar = "U")
PlotCenteredInterventions(sp = spB_list, yvar = "B")



# PLOT USE OF MANAGEMENT MEASURES WHILE UNDER AND NOT UNDER REBUILDING ---------

mars <- c(0.25, 0.25, 0.25, 0.25)
mgps <- c(1.4, 0.3, 0)
cols <- c(grey(0.5), rep(rgb(0.75, 0.26, 0.83), 3))
bgs <- c(rgb(0, 0, 0, alpha = 0.1), rep(rgb(0.75, 0.26, 0.83, alpha = 0.1), 3))

#. for Fig S4A
PlotManIndexByRebuild <- function(d = case_index_list, sel_phase = "mdf.matBU",
                                  pscale = 10) {

  if (sel_phase == "mdf.matBU")  phase <- "matBU"
  if (sel_phase == "mdf.fullts")  phase <- "fullts"
  cairo_pdf(filename = paste0("./out-plots/management-index-by-reb_", phase, ".pdf"),
            onefile = TRUE, width = 6.5, height = 2.5,
            antialias = "none", fallback_resolution = 600)
  par(mfrow = c(1, length(d)), mar = mars, oma = c(3, 12, 7, 0), mgp = mgps,
      tcl = -0.2, yaxs = "r", xaxs = "r", las = 1)

  mains <- c("All stock:years",
             "All stock:years",
             "Stock:years while\nunder rebuilding",
             "Only first year\nunder rebuilding")

  for (i in 1:length(d)) {
    df <- d[[i]]
    plot(x = df$mgtint, y = df$natint, type = "p", pch = 21,
         xlim = c(-0.1, 1.1), ylim = c(-0.1, 1.1),
         col = cols[i], bg = bgs[i], cex = sqrt(df$n / 1000 / pi) * pscale,
         main = "", xlab = "", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
    mtext(mains[i], side = 3, line = 1.5, outer = FALSE, cex = 0.75)
    axis(side = 1, at = seq(0, 1, by = 0.2),
         labels = c("0", "0.2", "0.4", "0.6", "0.8", "1"), gap.axis = 0.5,
         cex.axis = 0.8, col.axis = "black", col = grey(0.5),
         col.ticks = grey(0.5), lwd = 0.5)
    box(lwd = 0.5, col = grey(0.5))
    if (i == 1) {
      axis(side = 2, at = c(0, 1/3, 2/3, 1), labels = c(0, 0.33, 0.67, 1),
           cex.axis = 0.8, col.axis = "black", col = grey(0.5),
           col.ticks = grey(0.5), lwd = 0.5)
      mtext("National management intensity", side = 2, outer = FALSE, line = 1.8,
            las = 0, cex = 0.8)
      segments(x0 = 0, x1 = 1, y0 = 1.87, col = "black", lwd = 0.5, xpd = NA)
      points(x = -1.67, y = 0.46, xpd = NA, pch = 21, col = cols[i], bg = bgs[i],
             cex = sqrt(848 / 1000 / pi) * pscale)
      points(x = -1.67, y = 0.13, xpd = NA, pch = 21, col = cols[i], bg = bgs[i],
             cex = sqrt(100 / 1000 / pi) * pscale)
      points(x = -1.67, y = 0, xpd = NA, pch = 21, col = cols[i], bg = bgs[i],
             cex = sqrt(10 / 1000 / pi) * pscale)
      mtext("Number of \nstock:years", side = 3, outer = TRUE, line = -3,
            cex = 0.75, at = -0.32, adj = 0)
      mtext(c(848, 100, 10), side = 3, outer = TRUE, line = c(-5.2, -7.4, -8.2),
            cex = 0.75, at = -0.225, adj = 0)
    }
  }
  mtext("Stock management intensity", side = 1, outer = TRUE, line = 1.8,
        las = 0, cex = 0.8, at = 0.5, adj = 0.5)
  mtext("Stocks never under\n rebuilding plan", side = 3,
        line = 4.7, outer = TRUE, cex = 0.8, at = 0.125, adj = 0.5)
  mtext("Stocks at some point under rebuilding plan", side = 3,
        line = 5.2, outer = TRUE, cex = 0.8, at = 0.375, adj = 0)
  segments(x0 = -2.75, x1 = 1, y0 = 1.87, col = "black", lwd = 0.5, xpd = NA)
  dev.off()
}
PlotManIndexByRebuild(d = case_index_list, sel_phase = "mdf.matBU", pscale = 15)

#. for Fig S4B
PlotManComponentByRebuild <- function(d = case_comp_list, d2 = case_index_list,
                                      sel_phase = "mdf.matBU") {

  if (sel_phase == "mdf.matBU")  phase <- "matBU"
  if (sel_phase == "mdf.fullts")  phase <- "fullts"
  cairo_pdf(filename = paste0("./out-plots/management-components-by-reb_", phase, ".pdf"),
            onefile = TRUE, width = 6.5, height = 2,
            antialias = "none", fallback_resolution = 600)
  par(mfrow = c(1, length(d)), mar = mars, oma = c(3, 12, 1, 0), mgp = mgps,
      tcl = -0.2, yaxs = "r", xaxs = "r", las = 1)
  ylabs <- list(rev(sapply(X = names(d[[1]]), FUN = "SwitchLabs")), "", "", "")

  for (i in 1:length(d)) {
    df <- d[[i]]
    d2max <- sum(d2[[i]]$n)
    barplot(height = rev(df), horiz = TRUE, xlim = c(0, 1.04 * d2max), axes = FALSE,
            names.arg = ylabs[[i]], cex.names = 1.15, border = cols[i], col = bgs[i],
            main = "", xlab = "", ylab = "", bty = "n")
    abline(v = d2max, col = grey(0.5), lty = 3, lwd = 1)
    axis(side = 1, cex.axis = 0.95, col.axis = "black", col = grey(0.5),
         col.ticks = grey(0.5), lwd = 0.5)
    box(lwd = 0.5, col = grey(0.5))

    if (i == 1) {
      mtext("Number of stock:years with management measure in use", side = 1,
            outer = TRUE, line = 1.9, las = 0, cex = 0.8, at = 0.5, adj = 0.5)
    }
  }
  dev.off()
}
PlotManComponentByRebuild(d = case_comp_list, sel_phase = "mdf.matBU")

rm(rcol, scol, ncol, mdf, mdat, lh, lhpars, columnLabels, nstocks,
   PlotPairsLifeHistory, PlotTsLengthPerStock, PlotStockImplementations,
   ShortPlotStockImplementations, PlotAllImplementation, PlotRegionImplementation,
   PlotCenteredInterventions, PlotManComponentByRebuild, PlotManIndexByRebuild)


print.noquote("s4_plot-explore.R complete")
