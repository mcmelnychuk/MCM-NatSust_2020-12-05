###############################
### Hierarchical time series intervention analysis
###############################
### Relates stock status to management attributes, using ARIMA time series models
### dependencies: "s1_main.R", "s2_filter.R", "s3_wrangle.R", "s5_plot-arima.R"
### calls: none
###############################



# PREPARE DATASET --------------------------------------------------------------

SetDatasetOptions <- function() {
  if (dn == "fullts") {
    d <- mdf_list$mdf.full
    outputU <- outputB <- TRUE
    dlab <- "Full time series"
    dif_yr <- "end"  # differences align with end-of-year values, use only for
                     # equilibrium analyses in which U and B are coupled, and
                     # using full time series
  }
  if (dn == "matBU") {
    d <- mdf_list$mdf.matBU
    outputU <- outputB <- TRUE
    dlab <- "Mature fishery time series"
    dif_yr <- "start"  # differences align with start-of-year values, use for
                       # all other (non-coupled) intervention analyses, and
                       # using mature fishery phase
  }
  d <- d[order(d$stockid, d$year), ]
  rownames(d) <- seq(from = 1, to = length(d$stockid), by = 1)
  assign("d", d, envir = .GlobalEnv)
  assign("outputU", outputU, envir = .GlobalEnv)
  assign("outputB", outputB, envir = .GlobalEnv)
  assign("dlab", dlab, envir = .GlobalEnv)
  assign("dif_yr", dif_yr, envir = .GlobalEnv)
}

## REMOVE VALUES OR ROWS WITH FEWER THAN minyts IN PHASE ====================

RemoveShortTimeSeries <- function(d2 = d) {
  for (i in unique(d2$stockid)) {
    nyrU <- length(d2[d2$stockid == i & !is.na(d2$Udiv), "Udiv"])
    nyrB <- length(d2[d2$stockid == i & !is.na(d2$Bdiv), "Bdiv"])
    if (nyrU < minyts)  d2[d2$stockid == i & !is.na(d2$Udiv), "Udiv"] <- NA
    if (nyrB < minyts)  d2[d2$stockid == i & !is.na(d2$Bdiv), "Bdiv"] <- NA
  }
  assign("d", d2, envir = .GlobalEnv)
}

## TRANSFORM RESPONSE AND PREDICTOR VARIABLES ===============================

TransformVars <- function(d2 = d) {
  d2$logUdiv <- log(d2$Udiv + 0.001)
  d2$logBdiv <- log(d2$Bdiv + 0.001)
  assign("d", d2, envir = .GlobalEnv)
}

## APPLY FIRST AND OPTIONALLY SECOND ORDER DIFFERENCING =====================

DiffOrder1 <- function(d2 = d) {
  rawv <- c("Udiv", "Bdiv", "logUdiv", "logBdiv", "underreb")
  dif1v <- c("Udiv1", "Bdiv1", "logUdiv1", "logBdiv1", "underreb1")
  xtra <- as.data.frame(matrix(data = NA, nrow = nrow(d2), ncol = length(dif1v)))
  names(xtra) <- dif1v
  d2 <- data.frame(d2, xtra, stringsAsFactors = FALSE)
  for (i in unique(d2$stockid)) {
    if (nrow(d2[d2$stockid == i, ]) > 1) {
      for (j in 1:length(rawv)) {
        if (dif_yr == "start") {
          d2[d2$stockid == i, dif1v[j]] <- c(
            diff(x = d2[d2$stockid == i, rawv[j]], lag = 1, differences = 1),
            NA)
        }
        if (dif_yr == "end") {
          d2[d2$stockid == i, dif1v[j]] <- c(
            NA,
            diff(x = d2[d2$stockid == i, rawv[j]], lag = 1, differences = 1))
        }
      }
    }
  }
  assign("d", d2, envir = .GlobalEnv)
}

DiffOrder2 <- function(d2 = d) {
  d2$Udiv2 <- NA
  d2$Bdiv2 <- NA
  d2$s.logUdiv2 <- NA
  d2$s.logBdiv2 <- NA
  rawv <- c("Udiv", "Bdiv", "logUdiv", "logBdiv")
  dif2v <- c("Udiv2", "Bdiv2", "logUdiv2", "logBdiv2")
  for (i in unique(d2$stockid)) {
    if (nrow(d2[d2$stockid == i, ]) > 2) {
      for (j in 1:length(rawv)) {
        d2[d2$stockid == i, dif2v[j]] <- c(
          NA, NA,
          diff(x = d2[d2$stockid == i, rawv[j]], lag = 1, differences = 2))
      }
    }
  }
  assign("d", d2, envir = .GlobalEnv)
}

## RESCALE VARIANCE OF RESPONSE AND PREDICTORS; CENTER PREDICTORS ===========

RescaleVars <- function(d2 = d) {
  upvars <- c("age50mat", "Lmax", "mslv")
  spvars <- c("s.age50mat", "s.Lmax", "s.mslv")
  for (i in 1:length(upvars)) {
    d2[, spvars[i]] <- scale(d2[, upvars[i]], center = TRUE, scale = TRUE)[, 1]
  }
  urvars <- c("Udiv", "Bdiv", "logUdiv", "logBdiv",
              "Udiv1", "Bdiv1", "logUdiv1", "logBdiv1")
  srvars <- c("s.Udiv", "s.Bdiv", "s.logUdiv", "s.logBdiv",
              "s.Udiv1", "s.Bdiv1", "s.logUdiv1", "s.logBdiv1")
  for (i in 1:length(urvars)) {
    d2[, srvars[i]] <- scale(d2[, urvars[i]], center = FALSE, scale = TRUE)[, 1]
  }
  assign("d", d2, envir = .GlobalEnv)
}



# EVALUATE BEST ARIMA ORDER FOR EACH STOCK -------------------------------------

EvalBestARIMA <- function(d2 = d) {
  #. first pass (aadf) to identify best d
  #. second pass (aadfd1) after forcing d = 1 to identify best p, q
  #. third pass (aadf.ps1) to verify d after passing 1st-differenced ts
  #. fourth pass (aadfd0.ps1) to identify best p, q after forcing d = 0, and
  #.   after passing 1st-differenced ts
  yvars <- c("logUdiv", "logBdiv")
  yvars1 <- c("logUdiv1", "logBdiv1")
  cols <- c("stockid", "U.ndiffs", "U.bestp", "U.bestd", "U.bestq", "U.r2",
            "U.nobs", "U.nxtra", "U.convg", "B.ndiffs", "B.bestp", "B.bestd",
            "B.bestq", "B.r2", "B.nobs", "B.nxtra", "B.convg")
  aadf <- as.data.frame(matrix(data = NA, nrow = length(unique(d2$stockid)),
                               ncol = length(cols)))
  names(aadf) <- cols
  aadf$stockid <- unique(d2$stockid)
  aadfd1 <- aadf
  aadf.ps1 <- aadf
  aadfd0.ps1 <- aadf

  for (i in unique(d2$stockid)) {
    dfs <- d2[d2$stockid == i, yvars]
    if (nrow(dfs) >= minyts) {
      for (j in 1:length(yvars)) {
        ds <- dfs[, yvars[j]]
        if (sum(!is.na(ds), na.rm = TRUE) >= minyts) {
          aa <- auto.arima(y = ds,
                           stepwise = FALSE, parallel = TRUE,
                           approximation = FALSE, seasonal = FALSE)
          aad1 <- auto.arima(y = ds, d = 1,
                             stepwise = FALSE, parallel = TRUE,
                             approximation = FALSE, seasonal = FALSE)
          r2 <-  1 -
            (sum((aa$x - aa$fitted)^2, na.rm = TRUE) /
               sum((aa$x - mean(aa$x, na.rm = TRUE))^2, na.rm = TRUE))
          r2d1 <-  1 -
            (sum((aad1$x - aad1$fitted)^2, na.rm = TRUE) /
               sum((aad1$x - mean(aad1$x, na.rm = TRUE))^2, na.rm = TRUE))
          ndif <- ndiffs(x = ds)
          aadf[aadf$stockid == i, ((j - 1) * 8 + 2)] <- ndif
          aadf[aadf$stockid == i, ((j - 1) * 8 + 3)] <- aa$arma[1]
          aadf[aadf$stockid == i, ((j - 1) * 8 + 4)] <- aa$arma[6]
          aadf[aadf$stockid == i, ((j - 1) * 8 + 5)] <- aa$arma[2]
          aadf[aadf$stockid == i, ((j - 1) * 8 + 6)] <- r2
          aadf[aadf$stockid == i, ((j - 1) * 8 + 7)] <- aa$nobs
          aadf[aadf$stockid == i, ((j - 1) * 8 + 8)] <- aa$n.cond
          aadf[aadf$stockid == i, ((j - 1) * 8 + 9)] <- aa$code
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 2)] <- ndif
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 3)] <- aad1$arma[1]
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 4)] <- aad1$arma[6]
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 5)] <- aad1$arma[2]
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 6)] <- r2d1
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 7)] <- aad1$nobs
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 8)] <- aad1$n.cond
          aadfd1[aadfd1$stockid == i, ((j - 1) * 8 + 9)] <- aad1$code
        }
      }
    }
    dfs <- d2[d2$stockid == i, yvars1]
    if (nrow(dfs) >= minyts) {
      for (j in 1:length(yvars1)) {
        ds <- dfs[, yvars1[j]]
        if (sum(!is.na(ds), na.rm = TRUE) >= minyts) {
          aa.ps1 <- auto.arima(y = ds,
                               stepwise = FALSE, parallel = TRUE,
                               approximation = FALSE, seasonal = FALSE)
          aad0.ps1 <- auto.arima(y = ds, d = 0,
                                 stepwise = FALSE, parallel = TRUE,
                                 approximation = FALSE, seasonal = FALSE)
          r2.ps1 <-  1 -
            (sum((aa.ps1$x - aa.ps1$fitted)^2, na.rm = TRUE) /
               sum((aa.ps1$x - mean(aa.ps1$x, na.rm = TRUE))^2, na.rm = TRUE))
          r2d1.ps1 <-  1 -
            (sum((aad0.ps1$x - aad0.ps1$fitted)^2, na.rm = TRUE) /
               sum((aad0.ps1$x - mean(aad0.ps1$x, na.rm = TRUE))^2, na.rm = TRUE))
          ndif.ps1 <- ndiffs(x = ds)
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 2)] <- ndif.ps1
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 3)] <- aa.ps1$arma[1]
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 4)] <- aa.ps1$arma[6]
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 5)] <- aa.ps1$arma[2]
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 6)] <- r2.ps1
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 7)] <- aa.ps1$nobs
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 8)] <- aa.ps1$n.cond
          aadf.ps1[aadf.ps1$stockid == i, ((j - 1) * 8 + 9)] <- aa.ps1$code
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 2)] <- ndif.ps1
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 3)] <- aad0.ps1$arma[1]
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 4)] <- aad0.ps1$arma[6]
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 5)] <- aad0.ps1$arma[2]
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 6)] <- r2d1.ps1
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 7)] <- aad0.ps1$nobs
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 8)] <- aad0.ps1$n.cond
          aadfd0.ps1[aadfd0.ps1$stockid == i, ((j - 1) * 8 + 9)] <- aad0.ps1$code
        }
      }
    }
  }
  write.csv(x = aadf, row.names = FALSE, file = paste0(
    "./out-data/auto-arima_d-free_", dn,
    "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".csv"))
  write.csv(x = aadfd1, row.names = FALSE, file = paste0(
    "./out-data/auto-arima_d-fixed1_", dn,
    "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".csv"))
  write.csv(x = aadf.ps1, row.names = FALSE, file = paste0(
    "./out-data/auto-arima_d-free_passed1_", dn,
    "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".csv"))
  write.csv(x = aadfd0.ps1, row.names = FALSE, file = paste0(
    "./out-data/auto-arima_d-fixed1_passed1_", dn,
    "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".csv"))

  aa_list <- list(aadf, aadfd1, aadf.ps1, aadfd0.ps1)
  names(aa_list) <- c("aadf", "aadfd1", "aadf.ps1", "aadfd0.ps1")
  assign("aa_list", aa_list, envir = .GlobalEnv)

  dcol <- c(2, 10, 18, 26)
  mcol <- list()
  mcol[[1]] <- c(3, 4, 5)
  mcol[[2]] <- c(11, 12, 13)
  mcol[[3]] <- c(19, 20, 21)
  mcol[[4]] <- c(27, 28, 29)

  sink(file = paste0("./out-data/auto-arima-summary_", dn, "_minyts-", minyts,
                     "_RAM-", ramtype, "-", vtype, ".txt"))

  for (i in 1:length(yvars)) {
    print.noquote(paste0(dn, ", ", yvars[i], " -- ndiffs required:"))
    print(table(aadf[, dcol[i]]))
  }
  for (i in 1:length(yvars)) {
    cat("\n")
    print.noquote(paste0(dn, ", ", yvars[i], " -- best set of p, d, q:"))
    print(table(paste(aadf[, mcol[[i]][1]],
                      aadf[, mcol[[i]][2]],
                      aadf[, mcol[[i]][3]])))
    cat("\n")
    print.noquote(paste0(dn, ", ", yvars[i], " -- mean p, mean d, mean q:"))
    print.noquote(paste(
      round(mean(aadf[, mcol[[i]][1]], na.rm = TRUE), 2), " ; ",
      round(mean(aadf[, mcol[[i]][2]], na.rm = TRUE), 2), " ; ",
      round(mean(aadf[, mcol[[i]][3]], na.rm = TRUE), 2)))
  }
  for (i in 1:length(yvars)) {
    cat("\n")
    print.noquote(paste0(
      dn, ", ", yvars[i], " (d = 1) -- best set of p (rows), q (cols):"))
    print(table(paste(aadfd1[, mcol[[i]][1]],
                      aadfd1[, mcol[[i]][3]]), exclude = NA, useNA = "no"))
    print(table(aadfd1[, mcol[[i]][1]],
                aadfd1[, mcol[[i]][3]]), exclude = NA, useNA = "no")
    cat("\n")
    print.noquote(paste0(dn, ", ", yvars[i], " (d = 1) -- mean p, mean q:"))
    print.noquote(paste(
      round(mean(aadfd1[, mcol[[i]][1]], na.rm = TRUE), 2), " ; ",
      round(mean(aadfd1[, mcol[[i]][3]], na.rm = TRUE), 2)))
  }
  cat("\n")
  cat("\n")
  for (i in 1:length(yvars1)) {
    print.noquote(paste0(
      dn, ", passed 1st diffs ", yvars1[i], " -- ndiffs required:"))
    print(table(aadf.ps1[, dcol[i]]))
  }
  for (i in 1:length(yvars1)) {
    cat("\n")
    print.noquote(paste0(
      dn, ", passed 1st diffs ", yvars1[i], " -- best set of p, d, q:"))
    print(table(paste(aadf.ps1[, mcol[[i]][1]],
                      aadf.ps1[, mcol[[i]][2]],
                      aadf.ps1[, mcol[[i]][3]])))
    cat("\n")
    print.noquote(paste0(
      dn, ", passed 1st diffs ", yvars1[i], " -- mean p, mean d, mean q:"))
    print.noquote(paste(
      round(mean(aadf.ps1[, mcol[[i]][1]], na.rm = TRUE), 2), " ; ",
      round(mean(aadf.ps1[, mcol[[i]][2]], na.rm = TRUE), 2), " ; ",
      round(mean(aadf.ps1[, mcol[[i]][3]], na.rm = TRUE), 2)))
  }
  for (i in 1:length(yvars1)) {
    cat("\n")
    print.noquote(paste0(dn, ", passed 1st diffs ", yvars1[i],
                         " (d = 0) -- best set of p (rows), q (cols):"))
    print(table(paste(aadfd0.ps1[, mcol[[i]][1]],
                      aadfd0.ps1[, mcol[[i]][3]]), exclude = NA, useNA = "no"))
    print(table(aadfd0.ps1[, mcol[[i]][1]],
                aadfd0.ps1[, mcol[[i]][3]]), exclude = NA, useNA = "no")
    cat("\n")
    print.noquote(paste0(
      dn, ", passed 1st diffs ", yvars1[i], " (d = 0) -- mean p, mean q:"))
    print.noquote(paste(
      round(mean(aadfd0.ps1[, mcol[[i]][1]], na.rm = TRUE), 2), " ; ",
      round(mean(aadfd0.ps1[, mcol[[i]][3]], na.rm = TRUE), 2)))
  }
  sink()
  print("....EvalBestARIMA complete")
}



# SET UP CORRELATION STRUCTURE -------------------------------------------------

SetCorStructure = function() {
  if (corlab == "ARMA(0,0)") {
    cor_s <- NULL
    corl <- NULL
  }
  if (corlab == "ARMA(0,1)") {
    cor_s <- corARMA(value = 0.2,
                     form = (~ year | stockid), p = 0, q = 1)
    corl <- "arma01"
  }
  if (corlab == "ARMA(1,0)") {
    cor_s <- corAR1(value = 0.2,
                    form = (~ year | stockid))
    corl <- "arma10"
  }
  if (corlab == "ARMA(1,1)") {
    cor_s <- corARMA(value = rep(0.2, 2),
                     form = (~ year | stockid), p = 1, q = 1)
    corl <- "arma11"
  }
  if (corlab == "ARMA(2,0)") {
    cor_s <- corARMA(value = rep(0.2, 2),
                     form = (~ year | stockid), p = 2, q = 0)
    corl <- "arma20"
  }
  # cor_s <- Initialize(cor_s, data = d)
  assign("cor_s", cor_s, envir = .GlobalEnv)
  assign("corl", corl, envir = .GlobalEnv)
}



# FIT MODEL WITH SPECIFIED CORRELATION STRUCTURE ON DIFFERENCED RESPONSES ------

Fit_nlmeModels <- function(d) {

  control_list <- list(maxIter = 5000, msMaxIter = 5000, tolerance = 1e-6,
                       niterEM = 2500, msMaxEval = 20000, returnObject = TRUE)

  fix_linp_lv_ag <- c("-1", "txg3", "s.age50mat", "s.Lmax", "single_mix",
                      "s.mslv", "natint", "mgtint", "lag1underreb", "underreb1")
  fix_linp_lv_sep <- c("-1", "txg3", "s.age50mat", "s.Lmax", "single_mix",
                       "s.mslv", "nat", "fao", "eez", "iq", "quota", "hcr",
                       "assess", "survey", "lag1underreb", "underreb1")
  fix_linp_lv_ag <- paste(fix_linp_lv_ag, collapse = " + ")
  fix_linp_lv_sep <- paste(fix_linp_lv_sep, collapse = " + ")

  #. Aggregated management variables, equal weighting
  mU1_linp_lv_nw_ag <- lme(
    fixed = as.formula(noquote(paste("logUdiv1 ~", fix_linp_lv_ag))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list)
  mB1_linp_lv_nw_ag <- lme(
    fixed = as.formula(noquote(paste("logBdiv1 ~", fix_linp_lv_ag))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list)

  #. Aggregated management variables, weighted by MSLV
  mU1_linp_lv_w_ag <- lme(
    fixed = as.formula(noquote(paste("logUdiv1 ~", fix_linp_lv_ag))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list,
    weights = ~ 1 / (mslv / 1000000))
  mB1_linp_lv_w_ag <- lme(
    fixed = as.formula(noquote(paste("logBdiv1 ~", fix_linp_lv_ag))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list,
    weights = ~ 1 / (mslv / 1000000))

  #. Separated management variables, equal weighting
  mU1_linp_lv_nw_sep <- lme(
    fixed = as.formula(noquote(paste("logUdiv1 ~", fix_linp_lv_sep))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list)
  mB1_linp_lv_nw_sep <- lme(
    fixed = as.formula(noquote(paste("logBdiv1 ~", fix_linp_lv_sep))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list)

  #. Separated management variables, weighted by MSLV
  mU1_linp_lv_w_sep <- lme(
    fixed = as.formula(noquote(paste("logUdiv1 ~", fix_linp_lv_sep))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list,
    weights = ~ 1 / (mslv / 1000000))
  mB1_linp_lv_w_sep <- lme(
    fixed = as.formula(noquote(paste("logBdiv1 ~", fix_linp_lv_sep))),
    random = (~ 1 | stockid), correlation = cor_s, method = "REML",
    data = d, na.action = na.omit, control = control_list,
    weights = ~ 1 / (mslv / 1000000))

  if (outputU == TRUE) {
    Umods <- list(mU1_linp_lv_nw_ag, mU1_linp_lv_w_ag,
                  mU1_linp_lv_nw_sep, mU1_linp_lv_w_sep)
    Umodlabs <- c("mU1_linp_lv_nw_ag", "mU1_linp_lv_w_ag",
                  "mU1_linp_lv_nw_sep", "mU1_linp_lv_w_sep")
    names(Umods) <- Umodlabs
    Umodnames <- sapply(X = Umodlabs, FUN = "SwitchLabs", simplify = TRUE)
  }
  if (outputB == TRUE) {
    Bmods <- list(mB1_linp_lv_nw_ag, mB1_linp_lv_w_ag,
                  mB1_linp_lv_nw_sep, mB1_linp_lv_w_sep)
    Bmodlabs <- c("mB1_linp_lv_nw_ag", "mB1_linp_lv_w_ag",
                  "mB1_linp_lv_nw_sep", "mB1_linp_lv_w_sep")
    names(Bmods) <- Bmodlabs
    Bmodnames <- sapply(X = Bmodlabs, FUN = "SwitchLabs", simplify = TRUE)
  }
  if (outputB == TRUE & outputU == TRUE) {
    mods <- c(Umods, Bmods)
    modlabs <- c(Umodlabs, Bmodlabs)
    modnames <- c(Umodnames, Bmodnames)
  }
  if (outputB == TRUE & outputU == FALSE) {
    mods <- Bmods
    modlabs <- Bmodlabs
    modnames <- Bmodnames
  }
  if (outputB == FALSE & outputU == TRUE) {
    mods <- Umods
    modlabs <- Umodlabs
    modnames <- Umodnames
  }
  assign("mods", mods, envir = .GlobalEnv)
  assign("modnames", modnames, envir = .GlobalEnv)
  cols <- c("mod", "nobs", "nreg", "ntax", "nstk", "nfix", "loglik", "aic", "bic",
            "sd_reg", "sd_tax", "sd_stk", "sd_resid", "max_abs_r_fix", "method",
            names(coef(mods[[1]]$modelStruct$corStruct, unconstrained = FALSE)))

  #. print summaries
  mtab <- as.data.frame(matrix(data = NA,
                               nrow = length(modlabs), ncol = length(cols)))
  names(mtab) <- cols
  mtab$mod <- modlabs
  for (i in 1:length(mods)) {
    mtab[i, "nobs"] <- mods[[i]]$dims$N
    mtab[i, "nstk"] <- mods[[i]]$dims$ngrps[1]
    mtab[i, "nfix"] <- mods[[i]]$dims$ncol[2]
    mtab[i, "loglik"] <- round(mods[[i]]$logLik, 1)
    mtab[i, "aic"] <- round(AIC(mods[[i]]), 1)
    mtab[i, "bic"] <- round(BIC(mods[[i]]), 1)
    mtab[i, "sd_stk"] <- sqrt(mods[[i]]$modelStruct$reStruct$stockid[1])
    mtab[i, "sd_resid"] <- mods[[i]]$sigma
    mtab[i, "max_abs_r_fix"] <- max(abs(summary(
      mods[[i]])$corFixed[-1, -1][upper.tri(summary(
        mods[[i]])$corFixed[-1, -1])]))
    mtab[i, "method"] <- mods[[i]]$method
    for (j in 1:length(coef(mods[[i]]$modelStruct$corStruct,
                            unconstrained = FALSE))) {
      mtab[i, names(coef(mods[[i]]$modelStruct$corStruct,
                         unconstrained = FALSE))[j]] <-
        coef(mods[[i]]$modelStruct$corStruct, unconstrained = FALSE)[j]
    }
  }
  write.csv(x = mtab, row.names = FALSE, file = paste0(
    "./out-data/arima-model-table_", corl, "_", dn,
    "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".csv"))
  sink(file = paste0("./out-data/arima-fits-summary_", corl, "_", dn,
                     "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".txt"))

  if (outputU == TRUE) {
    for (i in 1:length(Umods)) {
      print.noquote(paste(Umodlabs[i], ",", corlab,
                          "- AIC, var(stock), var(resid):"))
      if (names(Umods[[i]]$dims$ngrps)[2] == "X") {
        print(paste(
          round(AIC(Umods[[i]]), digits = 2), ",  NA ,  NA , ",
          round(as.numeric(VarCorr(Umods[[i]])[1, 1]), digits = 5), ", ",
          round(as.numeric(VarCorr(Umods[[i]])[2, 1]), digits = 5)), quote = FALSE)
      }
      cat("\n")
    }
  }
  if (outputB == TRUE) {
    for (i in 1:length(Bmods)) {
      print.noquote(paste(Bmodlabs[i], ",", corlab,
                          "- AIC, var(stock), var(resid):"))
      if (names(Bmods[[i]]$dims$ngrps)[2] == "X") {
        print(paste(
          round(AIC(Bmods[[i]]), digits = 2), ",  NA ,  NA , ",
          round(as.numeric(VarCorr(Bmods[[i]])[1, 1]), digits = 5), ", ",
          round(as.numeric(VarCorr(Bmods[[i]])[2, 1]), digits = 5)), quote = FALSE)
      }
      cat("\n")
    }
  }
    if (outputU == TRUE) {
      for (i in 1:length(Umods)) {
        cat(paste("\n", Umodlabs[i], "\n", sep = "\n"))
        print(summary(Umods[[i]]))
        cat("\n")
      }
    }
    if (outputB == TRUE) {
      for (i in 1:length(Bmods)) {
        cat(paste("\n", Bmodlabs[i], "\n", sep = "\n"))
        print(summary(Bmods[[i]]))
        cat("\n")
      }
    }
  sink()
  print.noquote("....Fit_nlmeModels complete")
}



# PREDICT MARGINAL EFFECTS OF MANAGEMENT INTERVENTIONS -------------------------

PredictIntervention <- function(d, fig_type = "main") {

  mfits <- c("mUr", "mBr", "mUnr", "mBnr")
  mfit_list <- list()
  if (fig_type == "main")  xir <- c("1col")
  if (fig_type == "SM")  xir <- c("low", "med", "high")
  r_pred <- c("s.Lmax", "s.age50mat", "s.mslv", "natint", "mgtint", "underreb1",
              "lag1underreb")
  if (wt == "eq") {
    mfit_list[[1]] <- lme(
      fixed = logUdiv1 ~ s.Lmax + s.age50mat + s.mslv + natint + mgtint +
        underreb1 + lag1underreb,
      random = (~ 1 | stockid), correlation = cor_s,
      method = "REML", data = d, na.action = na.omit)
    mfit_list[[2]] <- lme(
      fixed = logBdiv1 ~ s.Lmax + s.age50mat + s.mslv + natint + mgtint +
        underreb1 + lag1underreb,
      random = (~ 1 | stockid), correlation = cor_s,
      method = "REML", data = d, na.action = na.omit)
  }
  if (wt == "lv") {
    mfit_list[[1]] <- lme(
      fixed = logUdiv1 ~ s.Lmax + s.age50mat + s.mslv + natint + mgtint +
        underreb1 + lag1underreb,
      random = (~ 1 | stockid), correlation = cor_s,
      method = "REML", data = d, na.action = na.omit,
      weights = ~ 1 / (mslv / 1000000))
    mfit_list[[2]] <- lme(
      fixed = logBdiv1 ~ s.Lmax + s.age50mat + s.mslv + natint + mgtint +
        underreb1 + lag1underreb,
      random = (~ 1 | stockid), correlation = cor_s,
      method = "REML", data = d, na.action = na.omit,
      weights = ~ 1 / (mslv / 1000000))
  }

  mfit_list[[3]] <- mfit_list[[1]]
  mfit_list[[4]] <- mfit_list[[2]]
  names(mfit_list) <- mfits
  pred_list <- list(r_pred, r_pred, r_pred, r_pred)

  #. mean values during years under rebuilding, matBU (first means within stocks, then across)
  # . dr=d[d$underreb==1, c("stockid", "Udiv", "Bdiv")]
  # . mean(aggregate(dr, by = list(dr$stockid), FUN = "mean",
  #                  na.action = na.omit)$Udiv, na.rm = T)
  # . mean(aggregate(dr, by = list(dr$stockid), FUN = "mean",
  #                  na.action = na.omit)$Bdiv, na.rm = T)
  start_val <- c(1.445445, 0.6455969, 1.445445, 0.6455969)

  #. pick new par values, sampling from multivariate normal dist based on fit
  nresamp <- 1000
  pars_list <- list()
  for (i in 1:length(mfit_list)) {
    pars_list[[i]] <- mvrnorm(nresamp, mu = fixef(mfit_list[[i]]),
                                       Sigma = vcov(mfit_list[[i]]))
  }
  names(pars_list) <- mfits

  #. utility function
  get_CI <- function(y, pref = "") {
      r1 <- t(apply(y, MARGIN = 1, FUN = "quantile", c(0.025, 0.975)))
      setNames(as.data.frame(r1), paste0(pref, c("lwr", "upr")))
  }

  #. generate predictions with CI for interventions in year 11 of 21
  mi_list <- pars_list
  for (i in 1:length(mfit_list)) {
    mi_list[[i]] <- list()
    for (j in 1:length(xir)) {
      dfx <- as.data.frame(matrix(0, nrow = 21, ncol = length(pred_list[[i]])))
      names(dfx) <- pred_list[[i]]

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
        if (xir[j] == "1col") {
          if (sum(names(dfx) %in% c("natint", "mgtint", "underreb1")) == 3) {
            dfx$natint[11:21] <- 1
            dfx$mgtint[11:21] <- 1
            k <- 4:7
            if (mfits[i] == "mUr" | mfits[i] == "mBr") {
              dfx$underreb1[11] <- 1
              if (is.numeric(dfx$lag1underreb))  dfx$lag1underreb[12:21] <- 1
            }
            if (mfits[i] == "mUnr" | mfits[i] == "mBnr") {
              dfx$underreb1[11] <- 0
              if (is.numeric(dfx$lag1underreb))  dfx$lag1underreb[12:21] <- 0
            }
          }
        }
        if (xir[j] == "low" | xir[j] == "med" | xir[j] == "high") {
          if (xir[j] == "low") {
            mfrac <- 1/5
            nfrac <- 1/3
          }
          if (xir[j] == "med") {
            mfrac <- 3/5
            nfrac <- 2/3
          }
          if (xir[j] == "high") {
            mfrac <- 5/5
            nfrac <- 3/3
          }
          if (sum(names(dfx) %in% c("natint", "mgtint", "underreb1")) == 3) {
            dfx$natint[11:21] <- nfrac
            dfx$mgtint[11:21] <- mfrac
            k <- 4:7
            if (mfits[i] == "mUr" | mfits[i] == "mBr") {
              dfx$underreb1[11] <- 1
              if (is.numeric(dfx$lag1underreb))  dfx$lag1underreb[12:21] <- 1
            }
            if (mfits[i] == "mUnr" | mfits[i] == "mBnr") {
              dfx$underreb1[11] <- 0
              if (is.numeric(dfx$lag1underreb))  dfx$lag1underreb[12:21] <- 0
            }
          }
        }
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////

      dfi <- xvar <- data.frame(dfx[k])
      dfi$logy1 <- predict(mfit_list[[i]], newdata = dfx, level = 0)
      yvals <- apply(pars_list[[i]], MARGIN = 1, FUN = function(x) {
        as.matrix(x[1] + x[k[1]] * xvar[1] +
                         x[k[2]] * xvar[2] +
                         x[k[3]] * xvar[3] +
                         x[k[4]] * xvar[4] )
      })
      dfi$varyvals <- apply(yvals, MARGIN = 1, FUN = "var")
      ciyvals <- get_CI(yvals, pref = "logy1")
      dfi <- data.frame(dfi, ciyvals)
      dfi$logy <- log(start_val[i])
      dfi$logy[2:21] <- dfi$logy[1] + cumsum(dfi$logy1[2:21])
      dfi$ranefvarlogy <- sum(as.numeric(VarCorr(
        mfit_list[[i]])[row.names(VarCorr(mfit_list[[i]])) == "(Intercept)", 1]),
        na.rm = TRUE)
      dfi$staticfevarlogy[11:21] <- sum(
        mfit_list[[i]]$varFix[c(1:4, (k + 1)), c(1:4, (k + 1))][upper.tri(
          mfit_list[[i]]$varFix[c(1:4, (k + 1)), c(1:4, (k + 1))], diag = TRUE)])
      dfi$staticfevarlogy[1:10] <- sum(
        mfit_list[[i]]$varFix[c(1:4), c(1:4)][upper.tri(
        mfit_list[[i]]$varFix[c(1:4), c(1:4)], diag = TRUE)])
      dfi$interceptvar <- mfit_list[[i]]$varFix[1, 1]
      dfi$xintvar <- mfit_list[[i]]$varFix[k[1] + 1, k[1] + 1] +
                     mfit_list[[i]]$varFix[1, k[1] + 1] +
                     mfit_list[[i]]$varFix[k[2] + 1, k[2] + 1] +
                     mfit_list[[i]]$varFix[1, k[2] + 1] +
                     mfit_list[[i]]$varFix[k[3] + 1, k[3] + 1] +
                     mfit_list[[i]]$varFix[1, k[3] + 1] +
                     mfit_list[[i]]$varFix[k[4] + 1, k[4] + 1] +
                     mfit_list[[i]]$varFix[1, k[4] + 1]
      dfi$incvarlogy <- 0
      dfi$incvarlogy[2:10] <- dfi$incvarlogy[1] +
                              cumsum(dfi$interceptvar[2:10])
      dfi$incvarlogy[11:21] <- dfi$incvarlogy[10] +
                               cumsum(dfi$interceptvar[11:21]) +
                               cumsum(dfi$xintvar[11:21])
      dfi$totvarlogy <- dfi$varyvals +
                        dfi$ranefvarlogy +
                        dfi$staticfevarlogy +
                        dfi$incvarlogy
      dfi$lwrlogy <- qnorm(p = 0.025, mean = dfi$logy, sd = sqrt(dfi$totvarlogy))
      dfi$uprlogy <- qnorm(p = 0.975, mean = dfi$logy, sd = sqrt(dfi$totvarlogy))
      dfi$y <- exp(dfi$logy)
      dfi$lwry <- exp(dfi$lwrlogy)
      dfi$upry <- exp(dfi$uprlogy)
      mi_list[[i]][[j]] <- dfi
    }
    names(mi_list[[i]]) <- xir
  }
  assign("intvn_list", mi_list, envir = .GlobalEnv)
  if (fig_type == "main")  assign("intvn_list_main", mi_list, envir = .GlobalEnv)
  if (fig_type == "SM")  assign("intvn_list_SM", mi_list, envir = .GlobalEnv)

  print.noquote("....PredictIntervention complete")
}



# EQUILIBRIUM PREDICTIONS UNDER MANAGEMENT REGIMES -----------------------------

# #. Estimate rmax:
# if (dn == "fullts" & wt == "eq") {
#   rmaxmod <- lme(
#     fixed = logBdiv1 ~ s.Lmax + s.age50mat + s.mslv + Udiv + I((Udiv)^2),
#     random = (~ 1 | stockid), correlation = cor_s,
#     method = "REML", data = d, na.action = na.omit)
#   rmaxdat <- as.data.frame(matrix(data = 0, nrow = 1, ncol = 4))
#   names(rmaxdat) <- c("s.Lmax", "s.age50mat", "s.mslv", "Udiv")
#   rmax <- exp(predict(rmaxmod, newdata = rmaxdat, level = 0) - 0) - 1
#   print.noquote(paste("rmax =", rmax))
# }

PredictEqStates <- function(d, nyrs = 1000, ntake = 500,
                            ustart = 1, bstart = 1, rebstart = 0.5, rebend = 1,
                            mint = seq(0, 1, by = 0.2), rmax = 0.04365006) {
  uumod <- lme(
    fixed = logUdiv1 ~ s.Lmax + s.age50mat + s.mslv + mgtint + natint +
      underreb1 + lag1underreb + logBdiv + I((logBdiv)^2) + mgtint:natint,
    random = (~ 1 | stockid), correlation = cor_s,
    method = "REML", data = d, na.action = na.omit)
  bbmod <- lme(
    fixed = logBdiv1 ~ s.Lmax + s.age50mat + s.mslv + mgtint + natint +
      underreb1 + lag1underreb + logUdiv + I((logUdiv)^2) + mgtint:natint,
    random = (~ 1 | stockid), correlation = cor_s,
    method = "REML", data = d, na.action = na.omit)
  eqdf <- as.data.frame(matrix(data = NA, nrow = 1, ncol = 5))
  names(eqdf) <- c("mgtint", "natint", "uu", "bb", "preb")
  eqts <- list()
  eqts[[1]] <- as.data.frame(matrix(data = NA, nrow = 1,
                                    ncol = length((nyrs - ntake / 2 + 1):nyrs) + 1))
  eqts[[2]] <- eqts[[1]]
  names(eqts) <- c("uu", "bb")

  for (i in 1:length(mint)) {  # mgtint values
    # if (mint[i] %in% seq(0, 1, 0.1))  print(mint[i])
    for (j in 1:length(mint)) {  # natint values
      uudat <- as.data.frame(matrix(data = 0, nrow = 4, ncol = 8))
      names(uudat) <- c("s.Lmax", "s.age50mat", "s.mslv", "mgtint", "natint",
                        "underreb1", "lag1underreb", "logBdiv")
      uudat$mgtint <- mint[i]
      uudat$natint <- mint[j]
      uudat[1, "underreb1"] <- 0  # neither year under RP
      uudat[1, "lag1underreb"] <- 0
      uudat[2, "underreb1"] <- 0  # still under, or exiting RP
      uudat[2, "lag1underreb"] <- 1
      uudat[3, "underreb1"] <- 1  # entering RP
      uudat[3, "lag1underreb"] <- 0
      uudat[4, "underreb1"] <- 1  # both years under RP
      uudat[4, "lag1underreb"] <- 1
      bbdat <- uudat
      names(bbdat)[names(bbdat) == "logBdiv"] <- "logUdiv"
      uudat$logBdiv <- log(bstart)
      bbdat$logUdiv <- log(ustart)

      eqtab <- as.data.frame(matrix(data = 0, nrow = nyrs, ncol = 6))
      names(eqtab) <- c("reb", "deltauu", "deltabb", "uu", "bb", "cm")
      eqtab[1, "uu"] <- max(log(0.001), log(ustart), na.rm = TRUE)
      eqtab[1, "bb"] <- max(log(0.001), log(bstart), na.rm = TRUE)
      eqtab[2, "uu"] <- max(log(0.001), log(ustart), na.rm = TRUE)
      eqtab[2, "bb"] <- max(log(0.001), log(bstart), na.rm = TRUE)

      for (y in 3:nyrs) {
        deltauu <- predict(uumod, newdata = uudat, level = 0)
        deltabb <- predict(bbmod, newdata = bbdat, level = 0)
        if (eqtab[y - 1, "reb"] == 0) {
          if (eqtab[y - 2, "reb"] == 0) {
            deltauu_use <- deltauu[1]  # neither year under RP
            deltabb_use <- deltabb[1]
          } else {
            deltauu_use <- deltauu[2]  # last year under RP
            deltabb_use <- deltabb[2]
          }
        }
        if (eqtab[y - 1, "reb"] == 1) {
          if (eqtab[y - 2, "reb"] == 1) {
            if (eqtab[y - 1, "uu"] > 0) {
              deltauu_use <- deltauu[4]  # maintain initial RB drop in U until U/Uref < 1
              deltabb_use <- deltabb[4]
            } else {
              deltauu_use <- deltauu[2]  # still under RP
              deltabb_use <- deltabb[2]
            }
          } else {
            deltauu_use <- deltauu[3]  # first year under RP
            deltabb_use <- deltabb[3]
          }
        }
        eqtab[y, "deltauu"] <- deltauu_use
        eqtab[y, "deltabb"] <- deltabb_use
        eqtab[y, "uu"] <- eqtab[y - 1, "uu"] + deltauu_use

        eqtab[y, "bb"] <- exp(eqtab[y - 1, "bb"] + deltabb_use) +
          rmax * exp(eqtab[y - 1, "bb"]) * (1 - exp(eqtab[y - 1, "bb"]) / 2)
        eqtab[y, "bb"] <- log(eqtab[y, "bb"])

        uudat[1:4, "logBdiv"] <- eqtab[y, "bb"]
        bbdat[1:4, "logUdiv"] <- eqtab[y, "uu"]
        eqtab[y, "reb"] <- eqtab[y - 1, "reb"]
        if (eqtab[y, "bb"] < log(rebstart) & eqtab[y - 1, "reb"] == 0) {
          eqtab[y, "reb"] <- 1  # begin RP
        }
        if (eqtab[y, "bb"] >= log(rebend) & eqtab[y - 1, "reb"] == 1) {
          eqtab[y, "reb"] <- 0  # exit RP
        }
      }
      eqrow <- c(mint[i], mint[j],
                 mean(eqtab$uu[(nyrs - ntake + 1):nyrs], na.rm = TRUE),
                 mean(eqtab$bb[(nyrs - ntake + 1):nyrs], na.rm = TRUE),
                 mean(eqtab$reb[(nyrs - ntake + 1):nyrs], na.rm = TRUE))
      eqdf <- rbind(eqdf, eqrow)

      #. extract specific rows for time series plots
      if ((mint[i] == mint[j]) & (mint[i] %in% seq(0, 1, by = 0.2))) {
        for (k in 1:length(eqts)) {
          eqtsrow <- c(mint[i], exp(eqtab[(nyrs - ntake / 2 + 1):nyrs,
                                          names(eqts)[k]]))
          eqts[[k]] <- rbind(eqts[[k]], eqtsrow)
        }
      }
    }
  }
  for (k in 1:length(eqts)) {
    eqts[[k]] <- eqts[[k]][-1, ]
  }
  eqts$cm <- eqts$bb
  eqts$s_bb <- eqts$bb
  eqts$s_cm <- eqts$bb

  eqdf <- eqdf[-1, ]
  eqdf$uu <- exp(eqdf$uu)
  eqdf$bb <- exp(eqdf$bb)
  eqdf$cm <- eqdf$uu * eqdf$bb

  sc <- max(eqdf$uu, na.rm = TRUE) * min(eqdf$bb, na.rm = TRUE) *
        (min(eqdf$uu, na.rm = TRUE) * max(eqdf$bb, na.rm = TRUE))

  if (max(eqdf$cm, na.rm = TRUE) > 1) {
    if (sc > 1) {
      eqdf$s_bb <- eqdf$bb / sc
      eqts$s_bb[, 2:ncol(eqts$s_bb)] <- eqts$s_bb[, 2:ncol(eqts$s_bb)] / sc
    }
    if (sc <= 1) {
      eqdf$s_bb <- eqdf$bb * sc
      eqts$s_bb[, 2:ncol(eqts$s_bb)] <- eqts$s_bb[, 2:ncol(eqts$s_bb)] * sc
    }
  } else {
    if (sc > 1) {
      eqdf$s_bb <- eqdf$bb * sc
      eqts$s_bb[, 2:ncol(eqts$s_bb)] <- eqts$s_bb[, 2:ncol(eqts$s_bb)] * sc
    }
    if (sc <= 1) {
      eqdf$s_bb <- eqdf$bb / sc
      eqts$s_bb[, 2:ncol(eqts$s_bb)] <- eqts$s_bb[, 2:ncol(eqts$s_bb)] / sc
    }
  }
  eqdf$s_cm <- eqdf$uu * eqdf$s_bb
  eqts$s_cm[, 2:ncol(eqts$s_cm)] <- eqts$uu[, 2:ncol(eqts$uu)] *
    eqts$s_bb[, 2:ncol(eqts$s_bb)]
  eqts$cm[, 2:ncol(eqts$cm)] <- eqts$uu[, 2:ncol(eqts$uu)] *
    eqts$bb[, 2:ncol(eqts$bb)]

  assign("eqdf", eqdf, envir = .GlobalEnv)
  assign("eqts", eqts, envir = .GlobalEnv)
  write.csv(x = eqdf, row.names = FALSE, file = paste0(
      "./out-data/eqdf_wt-", wt, "_", corl, "_", dn, "_minyts-", minyts,
      "_RAM-", ramtype, "-", vtype, ".csv"))

  print.noquote("....PredictEqStates complete")
}



# RUN FUNCTIONS FOR ANALYSIS, DEPENDING ON SPECIFIED OPTIONS -------------------

for (dn in dns) {
  for (wt in wts) {
    #. clear unneeded objects and previous runs of looper
      suppressWarnings(graphics.off())
      suppressWarnings(rm(
        d, dlab, outputU, outputB, mods, modnames, cor_r, cor_t, cor_s, corl,
        eqdf, aadf, aadfd1, aadf.ps1, aadfd0.ps1, aa_list, intvn_list, mfit_list,
        pars_list, intr_list, intr_list_singmix, ip_list, ip_list_singmix, ndat,
        yof.tab, ppreds, BUids, msymc, impl_list, eqdf, eqts, spB_list, spU_list,
        case_comp_list, case_index_list, mars, mgps, cols, bgs))
      print.noquote(paste0(".. starting dn = ", dn, " , wt = ", wt))
    #. set up data
      SetDatasetOptions()
      RemoveShortTimeSeries(d2 = d)
      TransformVars(d2 = d)
      DiffOrder1(d2 = d)
      if (dif == 2)  DiffOrder2(d2 = d)
      RescaleVars(d2 = d)
      SetCorStructure()
      print.noquote(paste("n stocks after filtering with B and/or U: ",
                          length(unique(d[!is.na(d$Bdiv) | !is.na(d$Udiv),
                                          "stockid"]))))
      print.noquote(paste("n stocks after filtering with both B and U: ",
                          length(unique(d[!is.na(d$Bdiv) & !is.na(d$Udiv),
                                          "stockid"]))))
    #. more exploratory analyses
      PlotHistResponse(d2 = d)
      # EvalBestARIMA(d2 = d)  # note long runtime
    if (dn == "matBU") {
      #. run ARIMA models and plot results
        Fit_nlmeModels(d)
        PlotAggFixedCoefs(ml_mat = mods)
        if (wt == "eq")  PlotSepFixedCoefs(ml_mat = mods)
        PlotResids(mlist = mods)
      #. predict effects of interventions
        PredictIntervention(d, fig_type = "main")
        PlotIntvnComposite(mil_mat = intvn_list_main, fig_type = "main")
        PredictIntervention(d, fig_type = "SM")
        PlotIntvnComposite(mil_mat = intvn_list_SM, fig_type = "SM")
    }
    if (dn == "fullts" & wt == "eq") {
      #. equilibrium analysis
      PredictEqStates(d, nyrs = 1000, ntake = 500,
                      mint = seq(0, 1, by = 0.1))  # by = 0.01 for final version (long runtime)
      PlotEqStates(eqdf = eqdf, cap = NULL)
      PlotEqTimeSeries(eqts2 = eqts)
    }
    print.noquote(paste0(".. dn = ", dn, " , wt = ", wt, " complete"))
  }
}


print.noquote("s6_analyze-arima.R complete")
