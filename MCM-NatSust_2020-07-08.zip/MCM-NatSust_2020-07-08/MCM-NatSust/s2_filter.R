###############################
### General data filters
###############################
### Applies filters and manipulations to basic input data
### dependencies: "s1_main.R"
### calls: none
###############################


# FILTER STATIC PREDICTOR VARIABLES --------------------------------------------

w.mdat <- dcast(mdat[, 1:5],  # convert to wide format
                formula = region + stocklong + stockid ~ var, value.var = "val")
with(w.mdat, {

  ## CATEGORICAL VARIABLES ==================================================

  reg2 <- region
  reg2[reg2 %in% c("US Alaska")] <- "US-Alaska"
  reg2[reg2 %in% c("US west")] <- "US-West Coast"
  reg2[reg2 %in% c("US northeast")] <- "US-Northeast"
  reg2[reg2 %in% c("US southeast")] <- "US-Southeast"
  reg2[reg2 %in% c("Canada west")] <- "Canada-West Coast"
  reg2[reg2 %in% c("Canada east")] <- "Canada-East Coast"
  reg2[reg2 %in% c("Europe ICES-nonEU")] <- "Europe(non-EU) NE Atl"
  reg2[reg2 %in% c("Europe ICES-EU")] <- "Europe(EU) NE Atl"
  reg2[reg2 %in% c("Europe Med-BlackS")] <- "Europe-Med/Black Sea"
  reg2[reg2 %in% c("Russia east")] <- "Russia-East Coast"
  reg2[reg2 %in% c("high seas")] <- "Tuna RFMOs"
  reg2 <- factor(reg2, levels = c(  # order based on recent median U/Uref
    "US-West Coast", "Canada-West Coast", "Canada-East Coast", "US-Alaska",
    "South Africa", "Australia", "US-Northeast", "Europe(non-EU) NE Atl", "Japan",
    "Tuna RFMOs", "US-Southeast", "New Zealand", "Europe(EU) NE Atl",
    "Russia-East Coast",  "South America", "West Africa", "Europe-Med/Black Sea"))

  hab2 <- habitat
  hab2[hab2 %in% c("demersal", "bathydemersal")] <- "demersal"
  hab2[hab2 %in% c("pelagic", "bathypelagic",
                   "pelagic-oceanic", "pelagic-neritic")] <- "pelagic"
  hab2[hab2 == "reef-associated"] <- "reef"

  txg2 <- taxGroup
  txg2[taxGroup %in% c("gadids")] <- "Gadids"
  txg2[taxGroup %in% c("pleuronectids")] <- "Pleuronectids"
  txg2[taxGroup %in% c("tuna-billfish")] <- "Tuna and billfish"
  txg2[taxGroup %in% c("carangids-mackerels")] <- "Carangids and mackerels"
  txg2[taxGroup %in% c("other marine percoidids")] <- "Other marine percoidids"
  txg2[taxGroup %in% c("forage fish")] <- "Forage fish"
  txg2[taxGroup %in% c("sebastids", "other scorpaenids")] <- "Scorpaenids"
  txg2[taxGroup %in% c(
    "other marine fish", "elasmobranchs")] <- "Other marine fish"
  txg2[taxGroup %in% c("bivalves-gastropods", "cephalopods")] <- "Molluscs"
  txg2[taxGroup %in% c("crabs-lobsters", "shrimps")] <- "Crustaceans"
  txg3 <- txg2
  txg3[txg2 %in% c("Molluscs", "Crustaceans")] <- "invert"
  txg3[txg2 %in% c("Scorpaenids", "Gadids", "Pleuronectids")] <- "demfish"
  txg3[txg2 %in% c("Other marine fish", "Other marine percoidids") &
              hab2 %in% c("demersal", "reef", "benthopelagic")] <- "demfish"
  txg3[txg2 %in% c(
    "Forage fish", "Tuna and billfish", "Carangids and mackerels")] <- "pelfish"
  txg3[txg2 %in% c("Other marine fish", "Other marine percoidids") &
       hab2 %in% c("pelagic")] <- "pelfish"
  txg3 <- factor(txg3, levels = c("demfish", "pelfish", "invert"))

  single_mix[single_mix == "both"] <- "mixed"
  single_mix <- factor(single_mix, levels = c("single", "mixed"))


  ## NUMERICAL VARIABLES ====================================================

  yof_survey[yof_survey == "no surveys"] <- NA
  yof_survey <- as.numeric(yof_survey)

  yof_assess[yof_assess == "only relative indices"] <- NA
  yof_assess <- as.numeric(yof_assess)

  yof_hcr[yof_hcr == "no HCR"] <- NA
  yof_hcr <- as.numeric(yof_hcr)

  yof_quota[yof_quota == "no quota"] <- NA
  yof_quota <- as.numeric(yof_quota)

  yof_iq[yof_iq == "no IQ"] <- NA
  yof_iq <- as.numeric(yof_iq)

  natM <- as.numeric(natM)
  age50mat <- as.numeric(age50mat)
  len50mat <- as.numeric(len50mat)
  Lmax <- as.numeric(Lmax)
  longevity <- as.numeric(longevity)
  troph <- as.numeric(troph)
  vbK <- as.numeric(vbK)

  # filtered static management attributes data table
  mdat <- data.frame(stockid, stocklong, reg2, txg2, txg3, tS, single_mix,
                     rebuild_his, yof_survey, yof_assess, yof_hcr, yof_quota,
                     yof_iq, natM, age50mat, len50mat, Lmax, longevity, troph, vbK,
                     stringsAsFactors = FALSE)
  assign("mdat", mdat, envir = .GlobalEnv)
  write.csv(x = mdat, file = "./out-data/filtered-attributes.csv",
            row.names = FALSE)
})

rm(w.mdat)


print.noquote("s2_filter.R complete")
