###############################
### Figure functions for hierarchical time series intervention analysis
###############################
### Relates stock status to management attributes, using ARIMA time series models
### dependencies: "s1_main.R", "s2_filter.R", "s3_wrangle.R"
###   (functions do not depend on "s6_analyze-arima.R", they are called later)
### calls: none
###############################



# PLOT HISTOGRAMS OF RESPONSE VARIABLES ----------------------------------------

PlotHistResponse <- function(d2 = d) {
  varsU <- c("Udiv", "logUdiv", "s.Udiv", "s.logUdiv",
             "Udiv1", "logUdiv1", "s.Udiv1", "s.logUdiv1")
  varsB <- c("Bdiv", "logBdiv", "s.Bdiv", "s.logBdiv",
             "Bdiv1", "logBdiv1", "s.Bdiv1", "s.logBdiv1")
  labsU <- c("Udiv, no diff", "logUdiv, no diff",
             "scaled Udiv, no diff", "scaled logUdiv, no diff",
             "Udiv, 1st diff", "logUdiv, 1st diff",
             "scaled Udiv, 1st diff", "scaled logUdiv, 1st diff")
  labsB <- c("Bdiv, no diff", "logBdiv, no diff",
             "scaled Bdiv, no diff", "scaled logBdiv, no diff",
             "Bdiv, 1st diff", "logBdiv, 1st diff",
             "scaled Bdiv, 1st diff", "scaled logBdiv, 1st diff")

  cairo_pdf(filename = paste0("./out-plots/U-B-hist_", dn, "_minyts-", minyts,
                              "_RAM-", ramtype, "-", vtype, ".pdf"),
            onefile = TRUE, width = 8.5, height = 11)

  par(mfrow = c(4, 2), mar = c(3, 1, 4, 1), oma = c(3, 5, 4, 1))

  if (outputU == TRUE) {
    for (i in 1:length(varsU)) {
      hist(d2[, varsU[i]], breaks = 40, col = grey(0.8), border = grey(0.6),
           main = labsU[i], ylab = "", xlab = "")
      if (i == 1) {
        abline(v = 1, col = "red", lwd = 1.5, lty = 1)
      } else {
        abline(v = 0, col = "red", lwd = 1.5, lty = 1)
      }
      abline(v = mean(d2[, varsU[i]], na.rm = TRUE), col = "blue", lwd = 2, lty = 3)
      mtext(paste("mean =", round(mean(d2[, varsU[i]], na.rm = TRUE), digits = 2)),
            side = 3, line = -0, adj = 0.1, col = "blue", cex = 0.7)
      mtext(paste("var =", round(sd(d2[, varsU[i]], na.rm = TRUE)^2, digits = 2)),
            side = 3, line = -0, adj = 0.9, col = "black", cex = 0.7)
    }
    mtext(expression(paste("U/U"["REF"], " response variable value")),
          side = 1, outer = TRUE)
    mtext("Frequency", side = 2, line = 2, outer = TRUE)
    mtext(dlab, side = 3, line = 1, outer = TRUE)
  }
  if (outputB == TRUE) {
    for (i in 1:length(varsB)) {
      hist(d2[, varsB[i]], breaks = 40, col = grey(0.8), border = grey(0.6),
           main = labsB[i], ylab = "", xlab = "")
      if (i == 1) {
        abline(v = 1, col = "red", lwd = 1.5, lty = 1)
      } else {
        abline(v = 0, col = "red", lwd = 1.5, lty = 1)
      }
      abline(v = mean(d2[, varsB[i]], na.rm = TRUE), col = "blue", lwd = 2, lty = 3)
      mtext(paste("mean =", round(mean(d2[, varsB[i]], na.rm = TRUE), digits = 2)),
            side = 3, line = -0, adj = 0.1, col = "blue", cex = 0.7)
      mtext(paste("var =", round(sd(d2[, varsB[i]], na.rm = TRUE)^2, digits = 2)),
            side = 3, line = -0, adj = 0.9, col = "black", cex = 0.7)
    }
    mtext(expression(paste("B/B"["REF"], " response variable value")),
          side = 1, outer = TRUE)
    mtext("Frequency", side = 2, line = 2, outer = TRUE)
    mtext(dlab, side = 3, line = 1, outer = TRUE)
  }
  dev.off()
}



# PLOT FITTED MODEL RESULTS ----------------------------------------------------

#. coefficients for aggregated management intensity indices, for Figs 3 and S6
PlotAggFixedCoefs <- function(ml_mat = mods) {

  if (wt == "eq")  ml_list <- list(ml_mat$mB1_linp_lv_nw_ag, ml_mat$mU1_linp_lv_nw_ag)
  if (wt == "lv")  ml_list <- list(ml_mat$mB1_linp_lv_w_ag, ml_mat$mU1_linp_lv_w_ag)
  ml <- list(ml_list)
  ml_names <- list(
    sapply(X = names(ml_mat$mU1_linp_lv_nw_ag$coefficients$fixed), FUN = "SwitchLabs"),
    rep("", length(names(ml_mat$mU1_linp_lv_nw_ag$coefficients$fixed))))

  cairo_pdf(filename = paste0("./out-plots/UB-agg-fix-coefs_wt-", wt, "_", corl, "_", dn,
                              "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".pdf"),
            onefile = TRUE, width = 6.5, height = 4)
    par(mfrow = c(1, 2), oma = c(3, 16, 3, 0), mar = c(0, 0, 0, 0.25),
        mgp = c(1.2, 0.3, 0), tcl = -0.2, cex = 0.7)
    if (wt == "eq" & dn == "matBU") {
      xlim1 <- c(-0.88, -0.72)
      xlim2 <- c(-0.08, 0.08)
      seg_a_x0 <- xlim1[2] + 0.004
      seg_a_x1 <- xlim1[2] + 0.0155
      seg_b_x0 <- xlim2[1] - 0.0155
      seg_b_x1 <- xlim2[1] - 0.004
      seg_y0 <- 0.35
      seg_y1 <- 0.9
      cb_x <- -0.999
      leg_x <- -0.775
    }
    if (wt == "lv" & dn == "matBU") {
      xlim1 <- c(-0.34, -0.16)
      xlim2 <- c(-0.09, 0.09)
      seg_a_x0 <- xlim1[2] + 0.001
      seg_a_x1 <- xlim1[2] + 0.0125
      seg_b_x0 <- xlim2[1] - 0.0125
      seg_b_x1 <- xlim2[1] - 0.001
      seg_y0 <- 0.35
      seg_y1 <- 0.9
      cb_x <- -0.475
      leg_x <- -0.2
    }
    for (i in 1:length(ml)) {
      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      coefplot2(object = ml[[i]], CI = 2, varnames = ml_names[[i]], xlim = xlim1,
                v.axis = TRUE, top.axis = FALSE, h.axis = FALSE,
                cex.var = (0.8 / 0.7), cex.pts = 0.8, cex.axis = 0.5,
                col.pts = c("magenta2", "green4"), pch.pts = c(16, 16),
                main = "", xlab = "", intercept = TRUE, mar = c(0, 0, 0, 0.25),
                spacing = 0.15, legend = FALSE)
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////
      axis(side = 1, lwd = 0.25, cex.axis = 1, lwd.ticks = 0.5,
           col.axis = "black", col = grey(0.8), col.ticks = grey(0.4))
      box(col = grey(0.8), lwd = 0.5)
      legend(x = leg_x, y = 13.3, horiz = FALSE, xpd = NA,
             legend = c(expression(paste(Delta, "ln(U/U"[REF], ")          ")),
                        expression(paste(Delta, "ln(B/B"[REF], ")"))),
             col = c("green4", "magenta2"), pt.cex = 0.8,
             pch = c(16, 16), lty = 1, lwd = 1, bty = "n", cex = (0.8 / 0.7))
      mtext("Fixed effect coefficient value",
            side = 1, outer = TRUE, line = 2, cex = 0.8)
      mtext("Management\nattributes", side = 2, outer = TRUE,
            line = 13.9, at = 0.82, adj = 0.5, las = 0, cex = 0.8)
      mtext("Fishery\nattributes", side = 2, outer = TRUE,
            line = 13.9, at = 0.54, adj = 0.5, las = 0, cex = 0.8)
      mtext("Life-history and\ntaxonomic attributes", side = 2, outer = TRUE,
            line = 13.9, at = 0.22, adj = 0.5, las = 0, cex = 0.8)
      mtext("Intercepts", side = 2, outer = TRUE,
            line = 11.5, at = 0.135, adj = 0.5, las = 0, cex = 0.8)
      CurlyBraces(x0 = cb_x, x1 = cb_x, y0 = 0.8, y1 = 3.3,
            pos = 1, direction = 2, depth = 0.013, col = "black")
      mtext("|", side = 2, outer = TRUE, line = 13.9, adj = 0.5, las = 2,
            at = c(seq(0.675, 0.98, by = 0.0375),
                   seq(0.49, 0.635, by = 0.0375),
                   seq(0.035, 0.445, by = 0.0375)), cex = 0.8)
      mtext("-", side = 2, outer = TRUE, adj = 0.5, at = 0.64, las = 2, xpd = NA,
            cex = 0.5, col = grey(0.6), line = seq(16, -30, by = -0.4))
      mtext("-", side = 2, outer = TRUE, adj = 0.5, at = 0.45, las = 2, xpd = NA,
            cex = 0.5, col = grey(0.6), line = seq(16, -30, by = -0.4))
      segments(x0 = seg_a_x0, x1 = seg_a_x1, y0 = seg_y0, y1 = seg_y1,
               col = "black", xpd = NA)

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      coefplot2(object = ml[[i]], CI = 2, varnames = rep("", length(ml_names[[i]])),
                xlim = xlim2, v.axis = TRUE, top.axis = FALSE, h.axis = FALSE,
                cex.var = (0.8 / 0.7), cex.pts = 0.8, cex.axis = 0.5,
                col.pts = c("magenta2", "green4"), pch.pts = c(16, 16),
                main = "", xlab = "", intercept = TRUE, mar = c(0, 0, 0, 0.25),
                spacing = 0.15, legend = FALSE)
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////
      axis(side = 1, lwd = 0.25, cex.axis = 1, lwd.ticks = 0.5,
           col.axis = "black", col = grey(0.8), col.ticks = grey(0.4))
      box(col = grey(0.8), lwd = 0.5)
      segments(x0 = seg_b_x0, x1 = seg_b_x1, y0 = seg_y0, y1 = seg_y1,
               col = "black", xpd = NA)
    }
  dev.off()
}


#. coefficients for individual management measures, for Fig S5
PlotSepFixedCoefs <- function(ml_mat = mods) {

  if (wt == "eq")  ml_list <- list(ml_mat$mB1_linp_lv_nw_sep, ml_mat$mU1_linp_lv_nw_sep)
  if (wt == "lv")  ml_list <- list(ml_mat$mB1_linp_lv_w_sep, ml_mat$mU1_linp_lv_w_sep)
  ml <- list(ml_list)
  ml_names <- list(sapply(X = names(ml_mat$mU1_linp_lv_nw_sep$coefficients$fixed),
                          FUN = "SwitchLabs"))

  cairo_pdf(filename = paste0("./out-plots/UB-sep-fix-coefs_wt-", wt, "_", corl, "_", dn,
                              "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".pdf"),
            onefile = TRUE, width = 6.5, height = 5)
    par(mfrow = c(1, 2), oma = c(3, 16, 3, 0), mar = c(0, 0, 0, 0.25),
        mgp = c(1.2, 0.3, 0), tcl = -0.2, cex = 0.7)
    if (wt == "eq" & dn == "matBU") {
      xlim1 <- c(-0.88, -0.72)
      xlim2 <- c(-0.08, 0.08)
      seg_a_x0 <- xlim1[2] + -0.0025
      seg_a_x1 <- xlim1[2] + 0.009
      seg_b_x0 <- xlim2[1] - 0.0115
      seg_b_x1 <- xlim2[1] - 0.000
      seg_y0 <- 0.05
      seg_y1 <- 0.75
      cb_x <- -0.99
      leg_x <- -0.775
    }
    if (wt == "lv" & dn == "matBU") {
      xlim1 <- c(-0.34, -0.16)
      xlim2 <- c(-0.09, 0.09)
      seg_a_x0 <- xlim1[2] + -0.003
      seg_a_x1 <- xlim1[2] + 0.0085
      seg_b_x0 <- xlim2[1] - 0.0125
      seg_b_x1 <- xlim2[1] - 0.001
      seg_y0 <- 0.05
      seg_y1 <- 0.75
      cb_x <- -0.465
      leg_x <- -0.2
    }

    for (i in 1:length(ml)) {

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      coefplot2(object = ml[[i]], CI = 2, varnames = ml_names[[i]], xlim = xlim1,
                v.axis = TRUE, top.axis = FALSE, h.axis = FALSE,
                cex.var = (0.8 / 0.7), cex.pts = 0.8, cex.axis = 0.5,
                col.pts = c("magenta2", "green4"), pch.pts = c(16, 16),
                main = "", xlab = "", mar = c(0, 0, 0, 0),
                intercept = TRUE, spacing = 0.15, legend = FALSE)
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////
      axis(side = 1, lwd = 0.25, cex.axis = 1, lwd.ticks = 0.5,
           col.axis = "black", col = grey(0.8), col.ticks = grey(0.4))
      box(col = grey(0.8), lwd = 0.5)
      legend(x = leg_x, y = 19.9, horiz = FALSE, xpd = NA,
             legend = c(expression(paste(Delta, "ln(U/U"[REF], ")          ")),
                      expression(paste(Delta, "ln(B/B"[REF], ")"))),
           col = c("green4", "magenta2"), pt.cex = 0.7,
           pch = c(16, 16), lty = 1, lwd = 1, bty = "n", cex = (0.8 / 0.7))
      mtext("Fixed effect coefficient value",
            side = 1, outer = TRUE, line = 2, cex = 0.8)
      mtext("Stock", side = 2, outer = TRUE,
            line = 13, at = 0.785, adj = 0.5, las = 0, cex = 0.7)
      mtext("National", side = 2, outer = TRUE,
            line = 13, at = 0.5, adj = 0.5, las = 0, cex = 0.7)
      mtext("Management measures", side = 2, outer = TRUE,
            line = 15, at = 0.7, adj = 0.5, las = 0, cex = 0.7)
      mtext("Fishery\nattri-\nbutes", side = 2, outer = TRUE,
            line = 13, at = 0.3575, adj = 0.5, las = 0, cex = 0.7)
      mtext("Life-history\nand taxonomic\nattributes", side = 2, outer = TRUE,
            line = 13, at = 0.155, adj = 0.5, las = 0, cex = 0.7)
      mtext("Intercepts", side = 2, outer = TRUE,
            line = 10.7, at = 0.1, adj = 0.5, las = 0, cex = 0.7)
      CurlyBraces(x0 = cb_x, x1 = cb_x, y0 = 0.71, y1 = 3.3,
            pos = 1, direction = 2, depth = 0.013, col = "black")
      mtext("|", side = 2, outer = TRUE, line = 12.8, adj = 0.5, las = 2,
            at = c(seq(0.615, 0.975, by = 0.03),
                   seq(0.44, 0.58, by = 0.03)), cex = 0.8)
      mtext("|", side = 2, outer = TRUE, line = 12.8, adj = 0.5, las = 2,
            at = c(seq(0.33, 0.3925, by = 0.03),
                   seq(0.035, 0.285, by = 0.03)), cex = 0.8)
      mtext("|", side = 2, outer = TRUE, line = 14.8, adj = 0.5, las = 2,
            at = c(seq(0.44, 0.98, by = 0.03)), cex = 0.8)
      mtext("-", side = 2, outer = TRUE, adj = 0.5, at = 0.585, las = 2, xpd = NA,
            cex = 0.5, col = grey(0.6), line = seq(16, -30, by = -0.4))
      mtext("-", side = 2, outer = TRUE, adj = 0.5, at = 0.415, las = 2, xpd = NA,
            cex = 0.5, col = grey(0.6), line = seq(16, -30, by = -0.4))
      mtext("-", side = 2, outer = TRUE, adj = 0.5, at = 0.3, las = 2, xpd = NA,
            cex = 0.5, col = grey(0.6), line = seq(16, -30, by = -0.4))
      segments(x0 = seg_a_x0, x1 = seg_a_x1, y0 = seg_y0, y1 = seg_y1,
               col = "black", xpd = NA)

      if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
      coefplot2(object = ml[[i]], CI = 2, varnames = rep("", length(ml_names[[i]])),
                xlim = xlim2, v.axis = TRUE, top.axis = FALSE, h.axis = FALSE,
                cex.var = (0.8 / 0.7), cex.pts = 0.8, cex.axis = 0.5,
                col.pts = c("magenta2", "green4"), pch.pts = c(16, 16),
                main = "", xlab = "", mar = c(0, 0, 0, 0),
                intercept = TRUE, spacing = 0.15, legend = FALSE)
      if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////
      axis(side = 1, lwd = 0.25, cex.axis = 1, lwd.ticks = 0.5,
           col.axis = "black", col = grey(0.8), col.ticks = grey(0.4))
      box(col = grey(0.8), lwd = 0.5)
      segments(x0 = seg_b_x0, x1 = seg_b_x1, y0 = seg_y0, y1 = seg_y1,
               col = "black", xpd = NA)
    }
  dev.off()
}


PlotResids <- function(mlist = mods) {

  if (dis.sel.warn == TRUE)  options(warn = -1)  # \\\\\ DISABLES WARNINGS BELOW \\\\\
    xypan0 <- function(x, y) {
      panel.abline(h = 0, lty = "dotted", col.line = "black", lwd = 1)
      panel.xyplot(x, y, col.pch = "blue", alpha = 0.2, pch = 16, cex = 0.5)
      panel.loess(x, y, col.line = "red", lwd = 1, span = 3 / 4)
    }
      cairo_pdf(filename = paste0("./out-plots/model-residuals_wt-", wt,
                                  "_", corl, "_", dn,"_minyts-", minyts,
                                  "_RAM-", ramtype, "-", vtype, ".pdf"),
                onefile = TRUE, width = 8.5, height = 11)

      par(mfrow = c(1, 1), oma = c(1, 1, 3, 2),
          mgp = c(1.4, 0.3, 0), tcl = -0.2)
      for (i in 1:length(mlist)) {
        if (names(ranef(mlist[[i]]))[1] == "(Intercept)") {
          print(plot(x = mlist[[i]],
                     form = resid(., type = "p") ~ fitted(.),
                     panel = xypan0,
                     # abline = 0,
                     main = list(label = paste(dlab, "; ", modnames[i]),
                                 font = 1, cex = 0.9)))
        }
      }
    dev.off()
  if (dis.sel.warn == TRUE)  options(warn = 0)  # ///// DISABLES WARNINGS ABOVE /////
}



# PLOT U/Umsy AND B/Bmsy FOLLOWING MANAGEMENT INTERVENTIONS --------------------

#. for Figs 4, S8
PlotIntvnComposite <- function(mil_mat = intvn_list_main, fig_type = "main") {

  if (fig_type == "main") {
    cairo_pdf(filename = paste0("./out-plots/main-intrv-composite_wt-", wt,
                                "_", corl, "_", dn, "_minyts-", minyts,
                                "_RAM-", ramtype, "-", vtype, ".pdf"),
              width = 2.9, height = 4)
      par(mfrow = c(2, 1), mar = c(0.25, 0.25, 0.25, 0.25), oma = c(2.5, 3, 2.5, 0),
        mgp = c(1.4, 0.3, 0), tcl = -0.2, yaxs = "i", xaxs = "r", las = 1)
  }
  if (fig_type == "SM") {
    cairo_pdf(filename = paste0("./out-plots/SM-intrv-composite_wt-", wt,
                                "_", corl, "_", dn, "_minyts-", minyts,
                                "_RAM-", ramtype, "-", vtype, ".pdf"),
              width = 6.5, height = 4)
      par(mfrow = c(2, 3), mar = c(0.25, 0.25, 0.25, 0.25), oma = c(3, 3.5, 8, 2.5),
        mgp = c(1.4, 0.3, 0), tcl = -0.2, yaxs = "i", xaxs = "r", las = 1)
  }

  col2 <- rgb(0.75, 0.26, 0.83, alpha = 1)
  col2t <- rgb(0.75, 0.26, 0.83, alpha = 0.2)
  col1 <- grey(0.5)
  col1t <- rgb(0, 0, 0, alpha = 0.2)

  mil_matU <- list(mil_mat[[1]], mil_mat[[3]])
  mil_matB <- list(mil_mat[[2]], mil_mat[[4]])
  mains <- c(
    "Low management intensity:\n1 of 5 stock-level measures, \n1 of 3 national-level measures",
    "Medium management intensity:\n3 of 5 stock-level measures, \n2 of 3 national-level measures",
    "High management intensity:\n5 of 5 stock-level measures, \n3 of 3 national-level measures")
  maxyU <- 2.05
  for (i in 1:length(mil_matU)) {
    for (j in 1:length(mil_matU[[i]])) {
      maxyU <- min(3.95, max(maxyU, max(mil_matU[[i]][[j]], na.rm = TRUE),
                            na.rm = TRUE), na.rm = TRUE)
    }
  }
  maxyB <- 1.99
  for (i in 1:length(mil_matB)) {
    for (j in 1:length(mil_matB[[i]])) {
      maxyB <- min(3.95, max(maxyB, max(mil_matB[[i]][[j]], na.rm = TRUE),
                            na.rm = TRUE), na.rm = TRUE)
    }
  }
  for (j in 1:length(mil_matU[[i]])) {
    diUr <- mil_matU[[1]][[j]]
    diUnr <- mil_matU[[2]][[j]]
    xv <- as.numeric(rownames(diUr)) - 10
    plot(x = xv, y = diUr[, "y"], ylim = c(0, maxyU), xaxt = "n", yaxt = "n",
         type = "l", lwd = 1, col = col1,
         main = "", ylab = "", xlab = "", bty = "n")
    if (j == 1) {
      if (fig_type == "main") {
        mtext("Years after implementation",
              side = 1, outer = TRUE, line = 1.5, cex = 0.8)
        mtext(expression(U/U[REF]),
            side = 2, outer = FALSE, line = 2.3, las = 0, cex = 0.8)
        axis(side = 2, lwd = 0.5, col.axis = "black", col = grey(0.5),
           col.ticks = grey(0.5), cex.axis = 0.8)
        legend(x = "topleft", inset = c(-0.25, -0.45), xpd = NA,
               legend = c(" All measures including rebuilding plan",
                          " All measures except rebuilding plan"),
               col = c(col2t, col1t),
               lwd = 8, bty = "n", cex = 0.8, xjust = 1, seg.len = 2)
        legend(x = "topleft", inset = c(-0.265, -0.45), xpd = NA,
               legend = c("", ""),
               col = c(col2, col1),
               lwd = 1.5, bty = "n", cex = 0.8, xjust = 1, seg.len = 2.5)
      }
      if (fig_type == "SM") {
        mtext("Years after implementation",
              side = 1, outer = TRUE, line = 1.9, cex = 0.8)
        mtext(expression(U/U[REF]),
            side = 2, outer = FALSE, line = 2.6, las = 0, cex = 0.8)
        axis(side = 2, lwd = 0.5, col.axis = "black", col = grey(0.5),
           col.ticks = grey(0.5), cex.axis = 1)
      }
    }
    if (j == 2 & fig_type == "SM") {
      legend(x = "top", horiz = TRUE, inset = c(-0.97), xpd = NA,
             legend = c(" With rebuilding plan        ",
                        " Without rebuilding plan"),
             col = c(col2, col1), text.col = "white",
             lwd = 1.5, bty = "n", cex = 1.2, xjust = 1, seg.len = 2.5)
      legend(x = "top", horiz = TRUE, inset = c(-0.97), xpd = NA,
             legend = c(" With rebuilding plan        ",
                        " Without rebuilding plan"),
             col = c(col2t, col1t),
             lwd = 8, bty = "n", cex = 1.2, xjust = 1, seg.len = 2.5)
    }
    box(col = grey(0.5), lwd = 0.5)
    abline(v = 0, lty = 3, col = grey(0.5))
    abline(h = 1, lty = 2, col = grey(0.5))
    polygon(x = c(xv, rev(xv)), y = c(diUnr[, "lwry"], rev(diUnr[, "upry"])),
            col = col1t, border = NA)
    polygon(x = c(xv, rev(xv)), y = c(diUr[, "lwry"], rev(diUr[, "upry"])),
            col = col2t, border = NA)
    lines(x = xv, diUr[, "y"], col = col2, lwd = 1.5)
    lines(x = xv, diUnr[, "y"], col = col1, lwd = 1.5)
    if (fig_type == "SM") {
      mtext(mains[j], side = 3, outer = FALSE, line = 1.9, cex = 0.8)
    }
  }
  for (j in 1:length(mil_matB[[i]])) {
    diBr <- mil_matB[[1]][[j]]
    diBnr <- mil_matB[[2]][[j]]
    xv <- as.numeric(rownames(diBr)) - 10
    plot(x = xv, y = diBr[, "y"], ylim = c(0, maxyB), xaxt = "n", yaxt = "n",
         type = "l", lwd = 1, col = col1,
         main = "", ylab = "", xlab = "", bty = "n")
    if (j == 1) {
      if (fig_type == "main") {
        mtext(expression(B/B[REF]),
            side = 2, outer = FALSE, line = 2.3, las = 0, cex = 0.8)
        axis(side = 1, lwd = 0.5, col.axis = "black", col = grey(0.5),
             col.ticks = grey(0.5), cex.axis = 0.8)
        axis(side = 2, lwd = 0.5, col.axis = "black", col = grey(0.5),
           col.ticks = grey(0.5), cex.axis = 0.8)
      }
      if (fig_type == "SM") {
        mtext(expression(B/B[REF]),
            side = 2, outer = FALSE, line = 2.6, las = 0, cex = 0.8)
        axis(side = 2, lwd = 0.5, col.axis = "black", col = grey(0.5),
           col.ticks = grey(0.5), cex.axis = 1)
      }
    }
    if (fig_type == "SM") {
      axis(side = 1, lwd = 0.5, col.axis = "black", col = grey(0.5),
             col.ticks = grey(0.5), cex.axis = 1)
    }
    if (j == 3 & fig_type == "SM") {
      if (wt == "eq") {
        mtext("Stocks weighted equally", side = 4, outer = TRUE, line = 1.4,
              las = 0, cex = 0.8)
      }
      if (wt == "lv") {
        mtext("Stocks weighted by MSLV", side = 4, outer = TRUE, line = 1.4,
              las = 0, cex = 0.8)
      }
      CurlyBraces(x0 = 12.5, x1 = 12.5, y0 = 0, y1 = 2 * maxyB + 0.1,
                  pos = 1, direction = 1, depth = 1.5, col = "black")
    }

    box(col = grey(0.5), lwd = 0.5)
    abline(v = 0, lty = 3, col = grey(0.5))
    abline(h = 1, lty = 2, col = grey(0.5))
    polygon(x = c(xv, rev(xv)), y = c(diBnr[, "lwry"], rev(diBnr[, "upry"])),
            col = col1t, border = NA)
    polygon(x = c(xv, rev(xv)), y = c(diBr[, "lwry"], rev(diBr[, "upry"])),
            col = col2t, border = NA)
    lines(x = xv, diBr[, "y"], col = col2, lwd = 1.5)
    lines(x = xv, diBnr[, "y"], col = col1, lwd = 1.5)
  }
  dev.off()
}



# PLOT EQUILIBRIUM PREDICTIONS UNDER MANAGEMENT REGIME -------------------------

#. for Fig 5
PlotEqStates <- function(eqdf_noSM = eqdf_noSM, cap = NULL) {

  cairo_pdf(filename = paste0("./out-plots/eq-pred_wt-", wt, "_", corl, "_", dn,
                              "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".pdf"),
            onefile = TRUE, width = 6.5, height = 2.9,
            antialias = "none", fallback_resolution = 600)

  par(mfcol = c(1, 4), mar = c(0.5, 0.5, 0.5, 0.5), oma = c(3, 4.5, 7.8, 0.4),
    mgp = c(1.4, 0.3, 0), tcl = -0.2, yaxs = "i", xaxs = "i", las = 1)

  pref <- c("s_bb", "uu", "s_cm", "preb")
  for (i in 1:(length(pref) - 1)) {
    lab <- pref[i]
    eqdfp <- eqdf_noSM[, c("mgtint", "natint", lab)]
    if (is.numeric(cap))  eqdfp[, 3] <- pmin(eqdfp[, 3], cap)
    eqdfp <- acast(data = eqdfp, formula = mgtint ~ natint, value.var = lab)
    if (i == 1) {
    image(x = as.numeric(rownames(eqdfp)), y = as.numeric(colnames(eqdfp)),
            z = eqdfp, zlim = c(0, 1.5), breaks = seq(0, 1.5, length.out = 241),
            col = colorRampPalette(colors = c("red", "#FF7F7F", "white", "blue"))(240),
            xlab = "", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
      rect(xleft = seq(0.1, 0.9, length.out = 240),
           xright = seq((0.1 + (0.9 - 0.1) / 240), (0.9 + (0.9 - 0.1) / 240),
                        length.out = 240),
           ybottom = 1.37, ytop = 1.47, border = NA, xpd = NA,
           col = colorRampPalette(colors = c("red", "#FF7F7F", "white", "blue"))(240))
      rect(xleft = 0.1, xright = 0.9 + (0.9 - 0.1) / 240, ybottom = 1.37,
           ytop = 1.47, border = grey(0.5), col = NA, lwd = 0.5, xpd = NA)
      text(x = seq(0.1, 0.9, length.out = 4), y = 1.44, pos = 3, xpd = NA,
           labels = seq(0, 1.5, by = 0.5), cex = 0.9)
      arrows(x0 = seq(0.64, 0.13, length.out = 50),
             x1 = seq(0.63, 0.12, length.out = 50),
             y0 = 1.34, length = 0, lwd = 1.5, xpd = NA,
             col = grey(seq(1, 0, length.out = 50)))
      arrows(x0 = 0.13, x1 = 0.12, y0 = 1.34, code = 2, lwd = 1.5, xpd = NA,
             length = 0.05, col = "black")
      text(x = 0.26, y = 1.24, adj = 0.5, xpd = NA, cex = 0.9,
           labels = "Less \ndesirable", col = "black")
      mtext(expression("Mean B/B"[REF]), side = 3, line = 6.5, cex = 0.8)
      axis(side = 2, cex.axis = 0.9, lwd = 0.5, at = seq(0, 1, by = 0.25),
           labels = c("0", "0.25", "0.5", "0.75", "1"),
           col.axis = "black", col = grey(0.5), col.ticks = grey(0.5))
    }
    if (i == 2) {
      image(x = as.numeric(rownames(eqdfp)), y = as.numeric(colnames(eqdfp)),
            z = eqdfp, zlim = c(0, 2.5), breaks = seq(0, 2.5, length.out = 241),
            col = colorRampPalette(colors = c(
              "blue", "#7F7FFF", "white", "#FFAAAA", "#FF5555", "red"))(240),
            xlab = "", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
      rect(xleft = seq(0.1, 0.9, length.out = 199),
           xright = seq((0.1 + (0.9 - 0.1) / 199), (0.9 + (0.9 - 0.1) / 199),
                        length.out = 199),
           ybottom = 1.37, ytop = 1.47, border = NA, xpd = NA,
           # max U/Uref barely over 2, so restrict legend to barely over 2/3 of range
           col = colorRampPalette(colors = c(
              "blue", "#7F7FFF", "white", "#FFAAAA", "#FF5555", "red"))(240)[1:199])
      rect(xleft = 0.1, xright = 0.9 + (0.9 - 0.1) / 199, ybottom = 1.37,
           ytop = 1.47, border = grey(0.5), col = NA, lwd = 0.5, xpd = NA)
      text(x = seq(0.1, 0.9 * 192/199, length.out = 5), y = 1.44, pos = 3, xpd = NA,
           labels = seq(0, 2, by = 0.5), cex = 0.9)
      arrows(x0 = seq(0.51, 0.90, length.out = 50),
             x1 = seq(0.52, 0.91, length.out = 50),
             y0 = 1.34, length = 0, lwd = 1.5, xpd = NA,
             col = grey(seq(1, 0, length.out = 50)))
      arrows(x0 = 0.90, x1 = 0.91, y0 = 1.34, code = 2, lwd = 1.5, xpd = NA,
             length = 0.05, col = "black")
      text(x = 0.81, y = 1.24, adj = 0.5, xpd = NA, cex = 0.9,
           labels = "Less \ndesirable", col = "black")
      mtext(expression("Mean U/U"[REF]), side = 3, line = 6.5, cex = 0.8)
    }
    if (i == 3) {
     image(x = as.numeric(rownames(eqdfp)), y = as.numeric(colnames(eqdfp)),
            z = eqdfp, zlim = c(0.4, 1.2), breaks = seq(0.4, 1.2, length.out = 241),
            col = colorRampPalette(colors = c("white", "darkseagreen", "darkseagreen4"))(240),
            xlab = "", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
      rect(xleft = seq(0.1, 0.9, length.out = 192),
           xright = seq((0.1 + (0.9 - 0.1) / 192), (0.9 + (0.9 - 0.1) / 192),
                        length.out = 192),
           ybottom = 1.37, ytop = 1.47, border = NA, xpd = NA,
           # max C/MSY barely over 1, so restrict legend to barely over 2/3 of range
           col = colorRampPalette(colors = c("white", "darkseagreen", "darkseagreen4"))(240)[1:192])
      rect(xleft = 0.1, xright = 0.9 + (0.9 - 0.1) / 192, ybottom = 1.37,
           ytop = 1.47, border = grey(0.5), col = NA, lwd = 0.5, xpd = NA)
      text(x = seq(0.1, 0.9 * 180/192, length.out = 4), y = 1.44, pos = 3, xpd = NA,
           labels = seq(0.4, 1, by = 0.2), cex = 0.9)
      arrows(x0 = seq(0.90, 0.10, length.out = 100),
             x1 = seq(0.89, 0.09, length.out = 100),
             y0 = 1.34, length = 0, lwd = 1.5, xpd = NA,
             col = grey(seq(1, 0, length.out = 100)))
      arrows(x0 = 0.10, x1 = 0.09, y0 = 1.34, code = 2, lwd = 1.5, xpd = NA,
             length = 0.05, col = "black")
      text(x = 0.24, y = 1.24, adj = 0.5, xpd = NA, cex = 0.9,
           labels = "Less \ndesirable", col = "black")
      mtext("Mean catch/MSY", side = 3, line = 6.65, cex = 0.8)
    }
    axis(side = 1, cex.axis = 0.9, lwd = 0.5, at = seq(0, 1, by = 0.25),
           labels = c("0", "0.25", "0.5", "0.75", "1"),
           col.axis = "black", col = grey(0.5), col.ticks = grey(0.5))
    box(col = grey(0.5), lwd = 0.5)
    points(x = seq(0, 1, by = 0.2), y = seq(0, 1, by = 0.2), pch = 4,
           col = 'black', lwd = 0.5, cex = 0.8, xpd = NA)
  }
  for (i in length(pref)) {
    lab <- pref[i]
    eqdfp <- eqdf_noSM[, c("mgtint", "natint", lab)]
    eqdfp <- acast(data = eqdfp, formula = mgtint ~ natint, value.var = lab)
    image(x = as.numeric(rownames(eqdfp)), y = as.numeric(colnames(eqdfp)),
          z = eqdfp, zlim = c(0, 0.4), breaks = seq(0, 0.4, length.out = 241),
          col = colorRampPalette(colors = c("white", "black"))(240),
          xlab = "", ylab = "", xaxt = "n", yaxt = "n", bty = "n")
    box(col = grey(0.5), lwd = 0.5)
    axis(side = 1, cex.axis = 0.9, lwd = 0.5, at = seq(0, 1, by = 0.25),
         labels = c("0", "0.25", "0.5", "0.75", "1"),
         col.axis = "black", col = grey(0.5), col.ticks = grey(0.5))
    rect(xleft = seq(0.1, 0.9, length.out = 240),
         xright = seq((0.1 + (0.9 - 0.1) / 240), (0.9 + (0.9 - 0.1) / 240),
                      length.out = 240),
         ybottom = 1.37, ytop = 1.47, border = NA, xpd = NA,
         col = colorRampPalette(colors = c("white", "black"))(240))
    rect(xleft = 0.1, xright = 0.9 + (0.9 - 0.1) / 240, ybottom = 1.37,
         ytop = 1.47, border = grey(0.5), col = NA, lwd = 0.5, xpd = NA)
    text(x = seq(0.1, 0.9, length.out = 3), y = 1.44, pos = 3, xpd = NA,
         labels = c("0", "0.2", "0.4"), cex = 0.9)
    arrows(x0 = seq(0.10, 0.90, length.out = 100),
             x1 = seq(0.11, 0.91, length.out = 100),
             y0 = 1.34, length = 0, lwd = 1.5, xpd = NA,
             col = grey(seq(1, 0, length.out = 100)))
    arrows(x0 = 0.90, x1 = 0.91, y0 = 1.34, code = 2, lwd = 1.5, xpd = NA,
             length = 0.05, col = "black")
    text(x = 0.81, y = 1.24, adj = 0.5, xpd = NA, cex = 0.9,
         labels = "Less \ndesirable", col = "black")
    mtext("Proportion of years\nunder rebuilding plan", side = 3, line = 6.1, cex = 0.8)
  }
  mtext("Stock-level management intensity", side = 1, outer = TRUE,
        line = 1.9, cex = 0.8)
  mtext("National-level \nmanagement intensity", side = 2, outer = TRUE,
        line = 2.3, las = 0, cex = 0.8)
  dev.off()
}

#. for Fig S10
PlotEqTimeSeries <- function(eqts2 = eqts, numy = 160,
                             muse = rev(seq(0, 1, by = 0.2))) {

  cairo_pdf(filename = paste0("./out-plots/eq-ts_wt-", wt, "_", corl, "_", dn,
                              "_minyts-", minyts, "_RAM-", ramtype, "-", vtype, ".pdf"),
            onefile = TRUE, width = 6.5, height = 4,
            antialias = "none", fallback_resolution = 600)

  par(mfcol = c(length(muse), 3), mar = c(0.25, 0.25, 0.25, 0.25),
      oma = c(2.5, 2.5, 4, 5),mgp = c(1.4, 0.3, 0), tcl = -0.2,
      yaxs = "i", xaxs = "i", las = 1)

  if (length(eqts2) == 5) {
    ymax <- 3.25
    pref <- c("s_bb", "uu", "s_cm")

    for (i in pref) {
      for (j in 1:length(muse)) {
        df <- eqts2[[i]][which(eqts2[[i]][, 1] == muse[j]),
                         (ncol(eqts2[[i]]) - numy + 1):ncol(eqts2[[i]])]
        if (i == "s_bb") {
          df2 <- eqts2[["bb"]][which(eqts2[["bb"]][, 1] == muse[j]),
                                 (ncol(eqts2[["bb"]]) - numy + 1):ncol(eqts2[["bb"]])]
          plot(x = 1:numy, y = as.numeric(df), ylim = c(0, ymax), bty = "n",
             xaxt = "n", yaxt = "n",  type = "l", col = "blue", lwd = 1.5)
          lines(x = 1:numy, y = as.numeric(df2), col = "red", lwd = 1.5)
          axis(side = 2, cex = 0.8, at = seq(0, ymax, by = 1), lwd = 0.25)
          if (j == 1) {
            mtext(expression("B/B"["REF"]), side = 3, outer = FALSE,
                  line = 0.5, cex = 0.8)
          }
        }
        if (i == "uu") {
          plot(x = 1:numy, y = as.numeric(df), ylim = c(0, ymax), bty = "n",
             xaxt = "n", yaxt = "n",  type = "l", col = "red", lwd = 1.5)
          if (j == 1) {
            mtext(expression("U/U"["REF"]), side = 3, outer = FALSE,
                  line = 0.5, cex = 0.8)
            legend(x = numy / 2, y = ymax * 2.4, xjust = 0.5,
                 legend = c("Unscaled", "Scaled"),
                 col = c("red", "blue"), lty = 1, lwd = 2, bty = "n",
                 cex = 1 / 0.8, xpd = NA, horiz = TRUE)
          }
        }
        if (i == "s_cm") {
          plot(x = 1:numy, y = as.numeric(df), ylim = c(0, ymax), bty = "n",
             xaxt = "n", yaxt = "n",  type = "l", col = "blue", lwd = 1.5)
          mtext(muse[j], side = 4, line = 2.5, cex = 0.8)
          if (j == 1) {
            mtext("Catch/MSY", side = 3, outer = FALSE, line = 0.5, cex = 0.8)
          }
        }
        abline(h = 1, lty = 2, col = grey(0.6))
        if (j == length(muse))  axis(side = 1, cex = 0.8, lwd = 0.25)
        box(col = grey(0.8), lwd = 1)
      }
    }
    mtext("Year", side = 1, outer = TRUE, line = 1.5, cex = 0.8)
    mtext("Manage-\nment\nintensity", side = 4, outer = TRUE, line = 2.7, at = 1.08,
          adj = 0.5, cex = 0.8)
    mtext(expression(paste("B/B"["REF"], " , U/U"["REF"], " , or catch/MSY")),
          side = 2, outer = TRUE, line = 1.2, las = 0, cex = 0.8)
  }
  dev.off()
}
